<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('provider')->nullable();
            $table->string('provider_id')->nullable();
            $table->string('profile')->default('uploads/profile/profile-img.png');
            $table->enum('role', array('admin', 'user'))->default('user');
            $table->float('total_fund')->default(0);
            $table->float('total_due')->default(0);
            $table->integer('profile_id')->nullable();
            $table->string('father_name')->nullable();
            $table->string('mother_name')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('education_qualification')->nullable();
            $table->string('passport_or_nid_type')->nullable();
            $table->string('passport_or_nid_number')->nullable();
            $table->string('religion')->nullable();
            $table->timestamp('date_of_birth')->nullable();
            $table->string('nationality')->nullable();
            $table->string('blood_group')->nullable();
            $table->string('occupation')->nullable();
            $table->string('village')->nullable();
            $table->string('word_no')->nullable();
            $table->string('post_office')->nullable();
            $table->string('thana')->nullable();
            $table->string('upzilla')->nullable();
            $table->string('district')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
};
