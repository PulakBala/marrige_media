<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('funds', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('getway_id');
            $table->string('sender_number')->nullable();
            $table->float('amount');
            $table->string('trx_id')->nullable();
            $table->string('month');
            $table->string('year');
            $table->enum('type', array('mobile-banking', 'bank-details', 'cash'));
            $table->enum('status', array('pending', 'approved', 'rejected'))->default('pending');
            $table->enum('payment_status', array('due', 'main'))->default('main');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('funds');
    }
};
