<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FeaturedAreaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('featured_areas')->insert([
            [
                'title' => 'সহজ ডিজিটাল প্ল্যাটফর্ম',
                'icon' => 'uploads/featured/featured-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'আপনার প্রতিষ্ঠানের উপযোগী',
                'icon' => 'uploads/featured/featured-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'আনলিমিটেড অ্যাক্সেস',
                'icon' => 'uploads/featured/featured-item-01.png',
                'created_at' => Carbon::now()
            ]
        ]);
    }
}
