<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('settings')->insert([
            [
                'name' => 'title',
                'value' => 'Site Title',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'logo',
                'value' => 'uploads/default/default-logo.png',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'favicon',
                'value' => 'uploads/default/default-favicon.png',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'author_name',
                'value' => 'Admin',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'meta_keyword',
                'value' => 'keyword-1,keyword-2,keyword-3,keyword-4,keyword-5',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'meta_tags',
                'value' => 'tag-1,tag-2,tag-3,tag-4,tag-5',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'meta_description',
                'value' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'facebook',
                'value' => 0,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'twitter',
                'value' => 0,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'google',
                'value' => 0,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'linkedin',
                'value' => 0,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'google_client_id',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'google_client_secret',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'facebook_app_id',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'facebook_client_secret',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'twitter_client_id',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'twitter_client_secret',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'linkedin_client_id',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'linkedin_client_secret',
                'value' => null,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_transport',
                'value' => 'smtp',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_host',
                'value' => 'smtp.mailtrap.io',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_port',
                'value' => 2525,
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_username',
                'value' => '028d59157d3fe0',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_password',
                'value' => '3b06bc96a55072',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_encryption',
                'value' => 'tls',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_from',
                'value' => 'example@test.com',
                'created_at' => Carbon::now()
            ],
            [
                'name' => 'mail_from_name',
                'value' => 'Test',
                'created_at' => Carbon::now()
            ],
        ]);
    }
}
