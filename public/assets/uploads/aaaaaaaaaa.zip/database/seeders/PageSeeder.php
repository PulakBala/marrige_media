<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pages')->insert([
            [
                'title' => 'Privacy Policy',
                'content' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam, quibusdam!',
                'created_at' => Carbon::now()
            ],[
                'title' => 'Trams & Condition',
                'content' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam, quibusdam!',
                'created_at' => Carbon::now()
            ],[
                'title' => 'DMCA',
                'content' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam, quibusdam!',
                'created_at' => Carbon::now()
            ]
        ]);
    }
}
