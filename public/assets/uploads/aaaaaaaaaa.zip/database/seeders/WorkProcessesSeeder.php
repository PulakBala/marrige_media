<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class WorkProcessesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('work_processes')->insert([
            [
                'title' => 'আলোচনা',
                'short_description' => 'Godard pabst prism fam cliche.',
                'icon' => 'uploads/work/work-process-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'সংশোধন',
                'short_description' => 'Godard pabst prism fam cliche.',
                'icon' => 'uploads/work/work-process-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'অনুমোদন',
                'short_description' => 'Godard pabst prism fam cliche.',
                'icon' => 'uploads/work/work-process-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'আরম্ভ',
                'short_description' => 'Godard pabst prism fam cliche.',
                'icon' => 'uploads/work/work-process-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'ডেপলয়',
                'short_description' => 'Godard pabst prism fam cliche.',
                'icon' => 'uploads/work/work-process-item-01.png',
                'created_at' => Carbon::now()
            ],[
                'title' => 'সাপোর্ট',
                'short_description' => 'Godard pabst prism fam cliche.',
                'icon' => 'uploads/work/work-process-item-01.png',
                'created_at' => Carbon::now()
            ]

        ]);
    }
}
