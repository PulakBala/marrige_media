<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AboutSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('abouts')->insert([
            'heading' => 'আমাদের প্রকল্প সম্পর্কে আলোচনা করা যাক',
            'description' => 'ইজি সমিতি হল মাল্টি পারপাস কো-অপারেটিভ সোসাইটি ব্যবস্থাপনা সফটওয়্যার সরবরাহ করে। মাল্টি পারপাস কো-অপারেটিভ সোসাইটি (এমসিএস) সফ্টওয়্যার একধরণের অ্যাপ্লিকেশন সফ্টওয়্যার বর্ণনা করে যা কার্যকরী মডিউলগুলির মধ্যে যেমন একাধিক অ্যাকাউন্টিং সদস্য লেনদেনগুলি যেমন পরিশোধযোগ্য, অ্যাকাউন্টগুলি গ্রহণযোগ্য, মুনাফা প্রাপ্তি, প্রত্যাহার, অ্যাকাউন্টস বন্ধ, ট্রায়াল ব্যালেন্স ইত্যাদি মডিউলগুলির মধ্যে রেকর্ড করে তা রিপোর্ট আকারে প্রদান করে। এটি একটি সমবায় সমিতি (এমসিএস) তথ্য ও হিসাব ডিজিটাল সিস্টেমে হিসাবে স্টোরেজ করে।',
            'image' => 'uploads/about/left-image.png',
            'created_at' => Carbon::now()

        ]);
    }
}
