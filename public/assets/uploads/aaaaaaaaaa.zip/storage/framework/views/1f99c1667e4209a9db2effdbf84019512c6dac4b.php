
<?php $__env->startSection('title'); ?>
    <title>User's Lists</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/datatables/media/css/dataTables.bootstrap5.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>User's Lists</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>User's</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">All User's</h2>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th class="text-nowrap">User</th>
                                    <th class="text-nowrap">Email</th>
                                    <th class="text-nowrap">Share</th>
                                     <th class="text-nowrap">Total Fund</th>
                                    <th class="text-nowrap">Add Fund</th>

                                    <th class="text-nowrap">Total Due</th>
                                    <th class="text-nowrap">Add Due</th>
                                    <th class="text-nowrap">Joined At</th>
                                    <th class="text-nowrap">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <td class="text-nowrap">
                                            <div class=" px-2">
                                                <h4 class="my-0"><?php echo e($user->name); ?></h4>
                                                <span class="d-block"> <b>Profile ID:</b> <?php echo e($user->profile_id); ?></span>
                                            </div>
                                            
                                                
                                            
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-flex justify-content-between align-items-center">
                                                <?php echo e($user->email); ?>

                                                <?php if($user->email_verified_at == NULL): ?>
                                                    <button class="btn btn-primary btn-sm" onclick="return window.location.href='<?php echo e(route('admin.user.emailVerified', $user->id)); ?>'">Verified</button>
                                                <?php else: ?>
                                                    <span class="badge badge-success">Verified</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-nowrap" ><?php echo e(getShare($user->id)); ?></td>
                                         <td class="text-nowrap" >
                                            <div class="d-md-flex justify-content-between align-items-center">
                                                <span><?php echo e($user->total_fund); ?> tk</span>
                                                

                                                  
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-md-flex justify-content-between align-items-center">
                                                
                                                

                                                  <a href="<?php echo e(route('admin.fund.cashPayment')); ?>" class="btn btn-sm btn-primary">Add fund</a>
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="d-block"><?php echo e($user->total_due); ?> tk</span>
                                                
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-flex justify-content-between align-items-center">
                                                
                                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($key); ?>">
                                                    Add Due
                                                  </button>
                                            </div>
                                        </td>
                                        <td class="text-nowrap" ><?php echo e(Carbon\Carbon::parse($user->created_at)->format('d m Y')); ?></td>
                                        <td class="text-nowrap" >
                                            <a href="<?php echo e(route('admin.user.edit', $user->id)); ?>" class="delete-row mx-1"><i class="far fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.user.details', $user->id)); ?>" class="delete-row mx-1"><i class="far fa-eye"></i></a>
                                            <a href="<?php echo e(route('admin.user.delete', $user->id)); ?>" class="delete-row mx-1"><i class="far fa-trash-alt"></i></a>
                                            <a href="<?php echo e(route('admin.user.downloadDetails', $user->id)); ?>" class="mx-1"><i class="fa fa-download"></i></a>
                                        </td>
                                    </tr>


                                    <!-- Modal -->
                                    



                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <form action="<?php echo e(route('admin.user.addDue', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                                            <div class="modal-dialog" role="document">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel<?php echo e($key); ?>">Modal title</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="month<?php echo e($key); ?>">---Select Month---</label>
                                                            <select name="month" id="month<?php echo e($key); ?>" class="form-control">
                                                                <option value="January">January</option>
                                                                <option value="February">February</option>
                                                                <option value="March">March</option>
                                                                <option value="April">April</option>
                                                                <option value="May">May</option>
                                                                <option value="June">June</option>
                                                                <option value="July">July</option>
                                                                <option value="August">August</option>
                                                                <option value="September">September</option>
                                                                <option value="October">October</option>
                                                                <option value="November">November</option>
                                                                <option value="December">December</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group border-0">
                                                            <label for="year<?php echo e($key); ?>">Select Year</label>
                                                            <select name="year" id="year<?php echo e($key); ?>" class="form-control">
                                                                <option value="2024">2024</option>
                                                                <option value="2025">2025</option>
                                                                <option value="2026">2026</option>
                                                                <option value="2027">2027</option>
                                                                <option value="2028">2028</option>
                                                                <option value="2029">2029</option>
                                                                <option value="2030">2030</option>
                                                                <option value="2031">2031</option>
                                                                <option value="2032">2032</option>
                                                                <option value="2033">2033</option>
                                                                <option value="2034">2034</option>
                                                                <option value="2035">2035</option>
                                                                <option value="2036">2036</option>
                                                                <option value="2037">2037</option>
                                                                <option value="2038">2038</option>
                                                                <option value="2039">2039</option>
                                                                <option value="2040">2040</option>
                                                                <option value="2041">2041</option>
                                                                <option value="2042">2042</option>
                                                                <option value="2043">2043</option>
                                                                <option value="2044">2044</option>
                                                                <option value="2045">2045</option>
                                                                <option value="2046">2046</option>
                                                                <option value="2047">2047</option>
                                                                <option value="2048">2048</option>
                                                                <option value="2049">2049</option>
                                                                <option value="2050">2050</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Submit Due</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="<?php echo e(asset('admin')); ?>/js/examples/examples.datatables.tabletools.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/users/index.blade.php ENDPATH**/ ?>