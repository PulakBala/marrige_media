<?php $__env->startSection('title'); ?>
    <title>Payment</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Payment</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Payment</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Payment by (<span class="text-danger"><?php echo e($getway->bank_name ?? $getway->account_name); ?></span>)</h2><br>
                        <?php if($type == 'mobile-banking'): ?>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Account Number</b> : <?php echo e($getway->account_number); ?> (<small class="text-capitalize text-success"><?php echo e($getway->account_type); ?></small>)</p>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Transfer Type</b> : <span class="text-capitalize"><?php echo e($getway->account_type == 'personal' ? 'Send Money' : 'Cash Out'); ?></span></p>
                        <?php else: ?>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Name</b> : <?php echo e($getway->account_name); ?></p>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Account Number</b> : <?php echo e($getway->account_number); ?></p>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Brunch Name</b> : <?php echo e($getway->branch_name); ?></p>
                        <?php endif; ?>
                    </header>
                    <div class="card-body">
                        <form role="form" action="<?php echo e(route('user.payment.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($getway->id); ?>" name="getway_id">
                            <input type="hidden" value="<?php echo e($type); ?>" name="type">
                            <input type="hidden" value="<?php echo e($share); ?>" name="share">
                          <div class="card-body">
                            <div class="row mb-3">
                                <div class="form-group col-md-4 border-0">
                                    <label for="month">Select Month</label>
                                    <select name="month" id="month" class="form-control">
                                        <option value="January">January</option>
                                        <option value="February">February</option>
                                        <option value="March">March</option>
                                        <option value="April">April</option>
                                        <option value="May">May</option>
                                        <option value="June">June</option>
                                        <option value="July">July</option>
                                        <option value="August">August</option>
                                        <option value="September">September</option>
                                        <option value="October">October</option>
                                        <option value="November">November</option>
                                        <option value="December">December</option>
                                    </select>
                                    <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-4 border-0">
                                    <label for="year">Select Year</label>
                                    <select name="year" id="year" class="form-control">
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                        <option value="2026">2026</option>
                                        <option value="2027">2027</option>
                                        <option value="2028">2028</option>
                                        <option value="2029">2029</option>
                                        <option value="2030">2030</option>
                                        <option value="2031">2031</option>
                                        <option value="2032">2032</option>
                                        <option value="2033">2033</option>
                                        <option value="2034">2034</option>
                                        <option value="2035">2035</option>
                                        <option value="2036">2036</option>
                                        <option value="2037">2037</option>
                                        <option value="2038">2038</option>
                                        <option value="2039">2039</option>
                                        <option value="2040">2040</option>
                                        <option value="2041">2041</option>
                                        <option value="2042">2042</option>
                                        <option value="2043">2043</option>
                                        <option value="2044">2044</option>
                                        <option value="2045">2045</option>
                                        <option value="2046">2046</option>
                                        <option value="2047">2047</option>
                                        <option value="2048">2048</option>
                                        <option value="2049">2049</option>
                                        <option value="2050">2050</option>
                                    </select>
                                    <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-4 border-0">
                                    <label for="payment_status">Select Payment Sutatus</label>
                                    <select name="payment_status" id="payment_status" class="form-control">
                                        <option value="main">Main Payment</option>
                                        <option value="due">Due Payment</option>
                                    </select>
                                    <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="form-group">
                                <label for="sender_number">Sender Account Number</label>
                                <input type="text" name="sender_number" class="form-control" id="sender_number" placeholder="Enter sender account number" value="<?php echo e(old('sender_number')); ?>">
                                <?php $__errorArgs = ['sender_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount</label>
                                <input type="text" readonly name="amount" class="form-control" id="amount" placeholder="Enter amount" value="<?php echo e($share * 2000); ?>">
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="transaction_id">Transaction ID</label>
                                <input type="text" name="transaction_id" class="form-control" id="transaction_id" placeholder="Enter transaction id" value="<?php echo e(old('transaction_id')); ?>">
                                <?php $__errorArgs = ['transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Submit </button>
                          </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/fund/create.blade.php ENDPATH**/ ?>