<?php $__env->startSection('title'); ?>
    <title><?php echo e(auth()->user()->name); ?> Profile</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Profile</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Profile</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <!-- start: page -->
        <div class="row">
            <div class="col-lg-4 col-xl-3 mb-4 mb-xl-0">
                <section class="card">
                    <div class="card-body">
                        <div class="thumb-info mb-3">
                            <img src="<?php echo e(asset(auth()->user()->profile)); ?>" class="rounded img-fluid" alt="John Doe">
                            <div class="thumb-info-title">
                                <span class="thumb-info-inner"><?php echo e(auth()->user()->name); ?></span>
                                <span class="thumb-info-type">USER</span>
                            </div>
                        </div>

                        <div class="widget-toggle-expand mb-3">
                            <div class="widget-header">
                                <h5 class="mb-2 font-weight-semibold text-dark">Details</h5>
                            </div>

                            <div class="widget-content-expanded">
                                <ul class="simple-todo-list mt-3">
                                    <li class="completed"><b>Profile ID : </b> <?php echo e(auth()->user()->profile_id); ?></li>
                                    <li class="completed"><b>Name : </b> <?php echo e(auth()->user()->name); ?></li>
                                    <li class="completed"><b>E-mail : </b><?php echo e(auth()->user()->email); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>
            </div>


            <div class="col-lg-8 col-xl-9">
                <div class="tabs">
                    <ul class="nav nav-tabs tabs-primary">
                        <li class="nav-item active">
                            <button class="nav-link" data-bs-target="#edit-profile" data-bs-toggle="tab">Edit Profile</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-target="#security" data-bs-toggle="tab">Security</button>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="edit-profile" class="tab-pane active">
                            <form class="p-3" action="<?php echo e(route('user.profile.update')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <h4 class="mb-3 font-weight-semibold text-dark">Personal Information</h4>
                                <div class="row row mb-4">
                                    <div class="form-group col">
                                        <label for="Name">Name</label>
                                        <input type="text" class="form-control" id="Name" name="name" placeholder="Enter name" value="<?php echo e(old('name') ? old('name') : auth()->user()->name); ?>">
                                        <span class="text-danger">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="row mb-4">
                                            <div class="form-group col">
                                                <label for="Image">Image</label>
                                                <input type="file" class="form-control" id="Image" name="profile">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <img src="<?php echo e(asset(auth()->user()->profile)); ?>" alt="<?php echo e(auth()->user()->name); ?>" class="rounded-circle" data-lock-picture="img/!logged-user.jpg" style="width: 100px; height:100px; border-radius:50%"/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 text-end mt-3">
                                        <button class="btn btn-primary modal-confirm">Update Profile</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                        <div id="security" class="tab-pane">
                            <form class="p-3" id="EmailForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <h4 class="mb-3 font-weight-semibold text-dark">Edit Primary Email</h4>
                                <div class="row row mb-4">
                                    <div class="form-group col">
                                        <label for="email">Email</label>
                                        <input type="text" class="form-control" id="email" placeholder="Enter Email" value="<?php echo e(auth()->user()->email); ?>">
                                        <span id="emailError" class="text-danger"></span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 text-end mt-3">
                                        <button class="btn btn-primary modal-confirm" type="submit">Change Email</button>
                                    </div>
                                </div>
                            </form>

                            <form class="p-3" id="passwordForm" action="" method="POST">
                                <?php echo csrf_field(); ?>
                                <h4 class="mb-3 font-weight-semibold text-dark">Change Password</h4>

                                <div class="form-group">
                                    <label for="newpassword">New Password</label>
                                    <input type="password" class="form-control" id="newpassword" placeholder="Password">
                                    <span id="passError" class="text-danger"></span>
                                </div>
                                <div class="form-group border-top-0 pt-2">
                                    <label for="confirmppassword">Re New Password</label>
                                    <input type="password" class="form-control" id="confirmpassword" placeholder="Confirm Password">
                                    <span id="conPass" class="text-danger"></span>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 text-end mt-3">
                                        <button class="btn btn-primary modal-confirm" type="submit">Update Password</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#EmailForm').submit(function(e)
        {
            e.preventDefault();
            var email = $('#email').val();
            $.ajax({
                type: 'POST',
                data: {email:email},
                url:'<?php echo e(route('user.email.update')); ?>',
                success: function (data){
                    $('#emailError').text('');
                    new PNotify({
                        title: 'Success Alert',
                        text: 'Email Update Successfull.',
                        type: 'success',
                        addclass: 'notification-success',
                        icon: 'fas fa-check'
                    });
                },error:function(error){
                    $('#email').val();
                    $('#emailError').text(error.responseJSON.errors.email);
                }
            });
        });


        function clear(){
            $('#newpassword').val('');
            $('#confirmpassword').val('');

            $('#passError').text('');
            $('#conPass').text('');
        }

        $('#passwordForm').submit(function(e)
        {
            e.preventDefault();
            var newpass = $('#newpassword').val();
            var conpass = $('#confirmpassword').val();
            $.ajax({
                type: 'POST',
                data: {newpass:newpass, conpass:conpass},
                url:'<?php echo e(route('user.password.update')); ?>',
                success: function (data){
                    if(data == 'error')
                    {
                        $('#passError').text('new password and confirm password not match');
                    }else{
                        clear();
                        new PNotify({
                            title: 'Success Alert',
                            text: 'Password Update Succfully.',
                            type: 'success',
                            addclass: 'notification-success',
                            icon: 'fas fa-check'
                        });
                        $('newpassword').val('');
                        $('confirmpassword').val('');
                    }
                },error:function(error){
                    clear();
                    $('newpassword').val();
                    $('confirmpassword').val();

                    $('#passError').text(error.responseJSON.errors.newpass);
                    $('#conPass').text(error.responseJSON.errors.conpass);
                }
            });

        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/profiles/index.blade.php ENDPATH**/ ?>