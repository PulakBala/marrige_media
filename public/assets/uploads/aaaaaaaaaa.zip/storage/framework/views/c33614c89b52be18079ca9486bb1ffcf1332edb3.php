<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <div style="text-align: center; padding: 4px; margin: 8px 0; background-color:#ddd; border-radius: 4px; display:flex; justify-content:center; align-items:center;">
        <img src="<?php echo e(asset('admin/logo-circle.jpg')); ?>" alt="Abosor Logo" style="width: 80px; height:80px; display: inline-block;">
    </div>

# Dear <?php echo e($name); ?>,

We are pleased to inform you that an amount of Tk. <?php echo e($amount); ?>/- has been credited to your account.
<br>
Your Closing Balance is TK. <?php echo e($amount); ?>

Month : <?php echo e($month); ?>

Total Blance Tk. <?php echo e($updated_total_fund); ?>


## Thank you for being a valued Partner  of Abosor.


Sincerely,<br>
Team Abosor
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/emails/payment-mail.blade.php ENDPATH**/ ?>