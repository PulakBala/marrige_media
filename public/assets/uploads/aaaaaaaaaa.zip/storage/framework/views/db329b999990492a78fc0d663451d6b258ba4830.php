<?php $__env->startSection('title'); ?>
    <title>Share Lists</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/datatables/media/css/dataTables.bootstrap5.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Share Lists</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Share</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header d-flex justify-content-between align-items-center">
                        <h2 class="card-title">All Share</h2>
                        <a href="<?php echo e(route('share.create')); ?>" class="btn btn-sm btn-success">Add Share</a>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <td><?php echo e(++$loop->index); ?></td>
                                        <td>
                                            <b><?php echo e($data->name); ?></b>
                                        </td>
                                        <td><?php echo e($data->amount); ?> tk</td>
                                        <td><span class="text-capitalize"><?php echo e($data->status); ?></span></td>
                                        <td>
                                            <form action="<?php echo e(route('share.destroy', $data->id)); ?>"></form>
                                            <a href="<?php echo e(route('share.edit', $data->id)); ?>" class="mx-1 d-inline"><i class="fas fa-pencil-alt"></i></a>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="<?php echo e(asset('admin')); ?>/js/examples/examples.datatables.tabletools.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/share/index.blade.php ENDPATH**/ ?>