<?php $__env->startSection('title'); ?>
    <title>Documents</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/datatables/media/css/dataTables.bootstrap5.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Documents</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Documents</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header d-flex justify-content-between align-items-center">
                        <h2 class="card-title">Documents</h2>
                        <a href="<?php echo e(route('document.create')); ?>" class="btn btn-sm btn-success">Add Document</a>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>User</th>
                                    <th>Title</th>
                                    <th>File</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <td><?php echo e(++$loop->index); ?></td>
                                        <td>
                                            <div class="d-flex jusfify-content-start align-items-center">
                                                <img src="<?php echo e(asset('public/' . $data->documentWithUserRelation->profile)); ?>" alt="" width="60" class="border p-1 mx-1">
                                                <b><?php echo e($data->documentWithUserRelation->name); ?></b>
                                            </div>
                                        </td>
                                        <td><b><?php echo e($data->title); ?></b></td>
                                        <td>
                                                <a href="<?php echo e(asset($data->file)); ?>" download><?php echo e($data->created_at); ?></a>
                                           
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('document.destroy', $data->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="border-0 bg-none text-danger" type="submit"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="<?php echo e(asset('admin')); ?>/js/examples/examples.datatables.tabletools.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/documents/index.blade.php ENDPATH**/ ?>