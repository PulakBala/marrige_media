<!-- ***** Header Area Start ***** -->
<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="<?php echo e(route('frontend.index')); ?>" class="logo">
                        <img src="<?php echo e(asset('public/' . setting('logo'))); ?>" alt="<?php echo e(asset(setting('name'))); ?>" style="width: 147px; height:63px;"/>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        <li><a href="<?php echo e(route('frontend.index')); ?>" class="active">Home</a></li>
                        <li><a href="#features">About</a></li>
                        <li><a href="#work-process">Work Process</a></li>
                        <li><a href="#team">Team</a></li>
                        
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role == 'user'): ?>
                                <li><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></li>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php endif; ?>
                    </ul>
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- ***** Header Area End ***** -->
<?php /**PATH /home/u455025027/domains/abosor-com-570072.hostingersite.com/public_html/resources/views/partials/navbar.blade.php ENDPATH**/ ?>