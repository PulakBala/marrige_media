<?php $__env->startSection('title'); ?>
    <title>Settings</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                <?php echo $__env->make('admins.partials.setting-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">
                                <div class="active">
                                    <form class="form-horizontal form-bordered" method="POST" action="<?php echo e(route('admin.setting.update')); ?>" enctype="multipart/form-data">
                                        <div class="form-group row pb-4">
                                            <?php echo csrf_field(); ?>
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="title">Title</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="title" name="title" title="Enter Site Title" value="<?php echo e(setting('title')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>


                                        <div class="form-group row pb-4">
                                            <?php echo csrf_field(); ?>
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="logo">Logo</label>
                                            <div class="col-lg-6">
                                                <input type="file" class="form-control" id="logo" name="logo">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                            <div class="col-lg-4">
                                                <img src="<?php echo e(asset(setting('logo'))); ?>" alt="" class="border p-1" style="width:30%; margin-top:5px">
                                            </div>
                                        </div>
                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="favicon">Favicon</label>
                                            <div class="col-lg-6">
                                                <input type="file" class="form-control" id="favicon" name="favicon">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                            <div class="col-lg-4">
                                                <img src="<?php echo e(asset(setting('favicon'))); ?>" alt="" class="border p-1" style="width:30px; margin-top:5px">
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" class="btn btn-success">Save and Update</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/settings/index.blade.php ENDPATH**/ ?>