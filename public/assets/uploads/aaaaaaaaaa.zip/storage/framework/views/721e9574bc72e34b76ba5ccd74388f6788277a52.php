<style>
    .active {
        color: #0099e6 !important;
        background-color: #21262d;
    }
</style>
<nav id="menu" class="nav-main" role="navigation">
    <ul class="nav nav-main">
        <li>
            <a class="nav-link <?php echo e(Request::url() == route('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Dashboard</span>
            </a>
        </li>


        <li class="nav-parent <?php echo e(Request::url() == route('admin.user.create') || Request::url() == route('admin.users.index') ? 'nav-expanded' : ''); ?>">
            <a class="nav-link <?php echo e(Request::url() == route('admin.user.create') || Request::url() == route('admin.users.index') ? 'active' : ''); ?>" href="#">
                <i class="bx bx-cart-alt" aria-hidden="true"></i>
                <span>Users</span>
            </a>
            <ul class="nav nav-children">
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.user.create') ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.create')); ?>">
                        Add User
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.users.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
                        List User
                    </a>
                </li>

            </ul>
        </li>


        <li class="nav-parent <?php echo e(Request::url() == route('mobile-payment-getway.index') || Request::url() == route('mobile-payment-getway.create') || Request::url() == route('bank-payment-getway.index') || Request::url() == route('bank-payment-getway.create') ? 'nav-expanded' : ''); ?>">
            <a class="nav-link <?php echo e(Request::url() == route('mobile-payment-getway.index') || Request::url() == route('mobile-payment-getway.create') || Request::url() == route('bank-payment-getway.index') || Request::url() == route('bank-payment-getway.create') ? 'active' : ''); ?>" href="#">
                <i class="bx bx-cart-alt" aria-hidden="true"></i>
                <span>Payment Getway</span>
            </a>
            <ul class="nav nav-children">
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('mobile-payment-getway.index') ? 'active' : ''); ?>" href="<?php echo e(route('mobile-payment-getway.index')); ?>">
                        Mobile Getway List
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('mobile-payment-getway.create') ? 'active' : ''); ?>" href="<?php echo e(route('mobile-payment-getway.create')); ?>">
                        Add Mobile Getway
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('bank-payment-getway.index') ? 'active' : ''); ?>" href="<?php echo e(route('bank-payment-getway.index')); ?>">
                        Bank Getway List
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('bank-payment-getway.create') ? 'active' : ''); ?>" href="<?php echo e(route('bank-payment-getway.create')); ?>">
                        Add Bank Getway
                    </a>
                </li>
            </ul>
        </li>


        <li class="nav-parent <?php echo e(Request::url() == route('team.index') || Request::url() == route('team.create') || Request::url() == route('admin.about.index') || Request::url() == route('work-processes.index') || Request::url() == route('admin.welcome.edit') ? 'nav-expanded' : ''); ?>">
            <a class="nav-link <?php echo e(Request::url() == route('team.index') || Request::url() == route('team.create') || Request::url() == route('admin.about.index') || Request::url() == route('work-processes.index') || Request::url() == route('admin.welcome.edit') ? 'active' : ''); ?>" href="#">
                <i class="bx bx-cart-alt" aria-hidden="true"></i>
                <span>Home Page</span>
            </a>
            <ul class="nav nav-children">
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.welcome.edit') ? 'active' : ''); ?>" href="<?php echo e(route('admin.welcome.edit')); ?>">
                        Welcome-Area
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.feature.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.feature.index')); ?>">
                        Home-Feature
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.about.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.about.index')); ?>">
                        About
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('team.index') ? 'active' : ''); ?>" href="<?php echo e(route('team.index')); ?>">
                        Team
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('work-processes.index') ? 'active' : ''); ?>" href="<?php echo e(route('work-processes.index')); ?>">
                        Work Processes
                    </a>
                </li>
            </ul>
        </li>


        <li>
            <a class="nav-link <?php echo e(Request::url() == route('page.index') ? 'active' : ''); ?>" href="<?php echo e(route('page.index')); ?>">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Pages</span>
            </a>
        </li>

        <li>
            <a class="nav-link <?php echo e(Request::url() == route('admin.share.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.share.index')); ?>">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Share Request</span>
            </a>
        </li>

        <li>
            <a class="nav-link <?php echo e(Request::url() == route('document.index') ? 'active' : ''); ?>" href="<?php echo e(route('document.index')); ?>">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Documents</span>
            </a>
        </li>


        <li class="nav-parent <?php echo e(Request::url() == route('admin.fund.cashPayment') || Request::url() == route('admin.fund.pendingRequest') || Request::url() == route('admin.fund.approvedRequest') || Request::url() == route('admin.fund.rejectedRequest') ? 'nav-expanded' : ''); ?>">
            <a class="nav-link <?php echo e(Request::url() == route('admin.fund.cashPayment') || Request::url() == route('admin.fund.pendingRequest') || Request::url() == route('admin.fund.approvedRequest') || Request::url() == route('admin.fund.rejectedRequest') ? 'active' : ''); ?>" href="#">
                <i class="bx bx-cart-alt" aria-hidden="true"></i>
                <span>Payment</span>
            </a>
            <ul class="nav nav-children">
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.fund.cashPayment') ? 'active' : ''); ?>" href="<?php echo e(route('admin.fund.cashPayment')); ?>">
                        Add Payment
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.fund.pendingRequest') ? 'active' : ''); ?>" href="<?php echo e(route('admin.fund.pendingRequest')); ?>">
                        Pending Request
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.fund.approvedRequest') ? 'active' : ''); ?>" href="<?php echo e(route('admin.fund.approvedRequest')); ?>">
                        Approved Payment
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('admin.fund.rejectedRequest') ? 'active' : ''); ?>" href="<?php echo e(route('admin.fund.rejectedRequest')); ?>">
                        Rejected Payment
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-parent <?php echo e(Request::url() == route('invest.create') || Request::url() == route('invest.index') ? 'nav-expanded' : ''); ?>">
            <a class="nav-link <?php echo e(Request::url() == route('invest.create') || Request::url() == route('invest.index') ? 'active' : ''); ?>" href="#">
                <i class="bx bx-cart-alt" aria-hidden="true"></i>
                <span>Invest</span>
            </a>
            <ul class="nav nav-children">
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('invest.create') ? 'active' : ''); ?>" href="<?php echo e(route('invest.create')); ?>">
                        Add Invest
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(Request::url() == route('invest.index') ? 'active' : ''); ?>" href="<?php echo e(route('invest.index')); ?>">
                        All Invest
                    </a>
                </li>
            </ul>
        </li>


    </ul>
</nav>
<?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/partials/side-nav.blade.php ENDPATH**/ ?>