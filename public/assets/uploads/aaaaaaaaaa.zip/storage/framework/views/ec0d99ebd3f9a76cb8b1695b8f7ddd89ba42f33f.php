<?php $__env->startSection('title'); ?>
    <title>Add Fund</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Add Fund</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Add Fund</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-10">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Select Payment Method</h2>
                    </header>
                    <div class="card-body">
                        <div class="row justify-content-center">
                            <?php $__currentLoopData = $mgetways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-2">
                                    <a href="<?php echo e(route('user.payment.create', [$getway->account_name, Crypt::encrypt($getway->id), 'mobile-banking'])); ?>">
                                        <div class="card border">
                                            <div class="card-header">
                                                <h2 class="card-title text-center mp-0"><?php echo e($getway->account_name); ?></h2>
                                            </div>
                                            <div class="card-body">
                                                <img src="<?php echo e(asset('public/' . $getway->logo)); ?>" alt="" class="img-fluid w-100">
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $bgetways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-2">
                                    <a href="<?php echo e(route('user.payment.create', [$getway->bank_name, Crypt::encrypt($getway->id), 'bank-details'])); ?>">
                                        <div class="card border">
                                            <div class="card-header">
                                                <h2 class="card-title text-center mp-0"><?php echo e($getway->bank_name); ?></h2>
                                            </div>
                                            <div class="card-body">
                                                <img src="<?php echo e(asset('public/' . $getway->logo)); ?>" alt="" class="img-fluid w-100">
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/fund/index.blade.php ENDPATH**/ ?>