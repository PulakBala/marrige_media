<?php $__env->startSection('title'); ?>
    <title>REGISTER -</title>

    <style>
        /* Style all input fields */


        /* Style the submit button */
        input[type=submit] {
          background-color: #04AA6D;
          color: white;
        }



        /* The message box is shown when the user clicks on the password field */
        #message {
          display:none;
          color: #000;
          position: relative;
        }

        #message p {
          padding: 2px 10px;
          font-size: 12px;
        }

        /* Add a green text color and a checkmark when the requirements are right */
        .valid {
          color: green;
          display: none;
        }

        .valid:before {
          position: relative;
          left: -5px;
          content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
          color: red;
        }

        .invalid:before {
          position: relative;
          left: -5px;
          content: "✖";
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('authform'); ?>
<div class="card-title-sign mt-3 text-end">
    <h2 class="title text-uppercase font-weight-bold m-0">
        <i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Sign Up
    </h2>
</div>
<div class="card-body">
    <form action="<?php echo e(route('register')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-3">
            <label>Name</label>
            <input name="name" type="text" class="form-control form-control-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" placeholder="Enter name"/>
            <span class="text-danger">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>

        <div class="form-group mb-3">
            <label>E-mail Address</label>
            <input name="email" type="email" class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" placeholder="Enter Email"/>
            <span class="text-danger">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>

        <div class="form-group mb-0">
            <div class="row">
                <div class="col-sm-6 mb-3">
                    <label>Password</label>
                    <input name="password" type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" id="psw" placeholder="Enter password"/>
                </div>
                <div class="col-sm-6 mb-3">
                    <label>Password Confirmation</label>
                    <input name="password_confirmation" type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Re-type password"/>
                    <span class="text-danger">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 text-center">
                    <span class="text-danger">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>


                <div id="message">
                    <p id="letter" class="invalid my-0 py-0">A <b>lowercase</b> letter</p>
                    <p id="capital" class="invalid my-0 py-0">A <b>capital (uppercase)</b> letter</p>
                    <p id="number" class="invalid my-0 py-0">A <b>number</b></p>
                    <p id="length" class="invalid my-0 py-0">Minimum <b>8 characters</b></p>
                  </div>
            </div>
        </div>

        <div class="row">
            <div class="">
                <button type="submit" id="submit" class="btn btn-primary mt-2">Sign Up</button>
            </div>
        </div>
        <?php if(setting('facebook') == 1 || setting('google') == 1 ||  setting('twitter') == 1 || setting('linkedin') == 1): ?>
            <span class="mt-3 mb-3 line-thru text-center text-uppercase">
                <span>or</span>
            </span>
        <?php endif; ?>
        <div class="mb-1 text-center">
            <?php if(setting('facebook') == 1): ?>
                <!-- Facebook -->
                <a class="btn btn-primary border-0" style="background-color: #3b5998;" href="<?php echo e(route('facebook.redirect')); ?>" role="button"><i class="fab fa-facebook-f"></i></a>
            <?php endif; ?>

            <?php if(setting('google') == 1): ?>
                <!-- Google -->
                <a class="btn btn-primary border-0" style="background-color: #dd4b39;" href="<?php echo e(route('google.redirect')); ?>" role="button"><i class="fab fa-google"></i></a>
            <?php endif; ?>

            <?php if(setting('twitter') == 1): ?>
                <!-- Twitter -->
                <a class="btn btn-primary border-0" style="background-color: #55acee;" href="<?php echo e(route('twitter.redirect')); ?>" role="button"><i class="fab fa-twitter"></i></a>
            <?php endif; ?>

            <?php if(setting('linkedin') == 1): ?>
                <!-- Linkedin -->
                <a class="btn btn-primary border-0" style="background-color: #0082ca;" href="<?php echo e(route('linkedin.redirect')); ?>" role="button"><i class="fab fa-linkedin-in"></i></a>
            <?php endif; ?>
        </div>
        <p class="text-center">Already have an account? <a href="<?php echo e(route('login')); ?>">Sign In!</a></p>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    var myInput = document.getElementById("psw");
    var letter = document.getElementById("letter");
    var capital = document.getElementById("capital");
    var number = document.getElementById("number");
    var length = document.getElementById("length");

    // When the user clicks on the password field, show the message box
    myInput.onfocus = function() {
      document.getElementById("message").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    myInput.onblur = function() {
      document.getElementById("message").style.display = "none";
    }

    // When the user starts to type something inside the password field
    myInput.onkeyup = function() {
      // Validate lowercase letters
      var lowerCaseLetters = /[a-z]/g;
      if(myInput.value.match(lowerCaseLetters)) {
        letter.classList.remove("invalid");
        letter.classList.add("valid");

      } else {
        letter.classList.remove("valid");
        letter.classList.add("invalid");
      }

      // Validate capital letters
      var upperCaseLetters = /[A-Z]/g;
      if(myInput.value.match(upperCaseLetters)) {
        capital.classList.remove("invalid");
        capital.classList.add("valid");
      } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
      }

      // Validate numbers
      var numbers = /[0-9]/g;
      if(myInput.value.match(numbers)) {
        number.classList.remove("invalid");
        number.classList.add("valid");
      } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
      }

      // Validate length
      if(myInput.value.length >= 8) {
        length.classList.remove("invalid");
        length.classList.add("valid");
      } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
      }
    }
    </script>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('auth.layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>