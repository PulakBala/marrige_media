<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>