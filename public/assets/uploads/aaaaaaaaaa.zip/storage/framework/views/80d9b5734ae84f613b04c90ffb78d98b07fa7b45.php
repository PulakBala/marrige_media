<?php $__env->startSection('title'); ?>
    <title>Invest List</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/datatables/media/css/dataTables.bootstrap5.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Invest List</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Invest List</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Invest List</h2>
                    </header>
                    <div class="card-body">
                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>Name</th>
                                    <th>Invest Amount</th>
                                    <th>Invest Profit</th>
                                    <th>Monthly Profit</th>
                                    <th>Add Profit </th>
                                    <th>History</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <td><?php echo e(++$loop->index); ?></td>
                                        <td><?php echo e(Carbon\Carbon::parse($data->created_at)->format('d M, Y')); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->amount); ?> tk</td>
                                        <td><?php echo e($data->profit ?? 0); ?> tk</td>
                                         <td><?php echo e($data->monthly_profit ?? 0); ?> tk</td>
                                          <td>
                                            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addProfitModal<?php echo e($data->id); ?>">Add Profit</button>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary show-history"
                                                    data-id="<?php echo e($data->id); ?>"
                                                    data-name="<?php echo e($data->name); ?>"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#historyModal">History</button>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('invest.edit', $data->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                        </td>
                                    </tr>
                                       <!-- Modal for each row -->
                                      <div class="modal fade" id="addProfitModal<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="addProfitModalLabel<?php echo e($data->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addProfitModalLabel<?php echo e($data->id); ?>">Add Monthly Profit for <?php echo e($data->name); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('invest.store.monthly.profit', $data->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="monthly_profit" class="form-label">Monthly Profit Amount</label>
                                                            <input type="number" class="form-control" id="monthly_profit" name="monthly_profit" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                          
                                     <!-- Single History Modal for all rows -->
<div class="modal fade" id="historyModal" tabindex="-1" aria-labelledby="historyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="history-modal-title">Profit History</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Monthly Profit</th>
                        </tr>
                    </thead>
                    <tbody id="history-table-body">
                        <!-- Data will be loaded here dynamically -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="<?php echo e(asset('admin')); ?>/js/examples/examples.datatables.tabletools.js"></script>
		
		          <!-- Add new script for history modal -->
          <script>
            $(document).ready(function() {
                $('.show-history').on('click', function() {
                    const id = $(this).data('id');
                    const name = $(this).data('name');

                    console.log('Making request for ID:', id); // Add this debug line
                    console.log('URL:', `/admin/invest/profit-history/${id}`); // Add this debug line

                    // Update modal title
                    $('#history-modal-title').text('Profit History - ' + name);

                    // Clear existing data
                    $('#history-table-body').html('<tr><td colspan="2" class="text-center">Loading...</td></tr>');

                    // Fetch profit history data
                    $.ajax({
                        url: `/admin/invest/profit-history/${id}`,
                        method: 'GET',
                        success: function(response) {
                            console.log('Response:', response); // Add this debug line
                            let html = '';
                            if (response.length === 0) {
                                html = '<tr><td colspan="2" class="text-center">No history found</td></tr>';
                            } else {
                                response.forEach(function(item) {
                                    html += `<tr>
                                        <td>${item.formatted_date}</td>
                                        <td>${item.monthly_profit} tk</td>
                                    </tr>`;
                                });
                            }
                            $('#history-table-body').html(html);
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error); // Add this debug line
                            console.error('Status:', status);
                            console.error('Response:', xhr.responseText);
                            $('#history-table-body').html('<tr><td colspan="2" class="text-center">Error loading data</td></tr>');
                        }
                    });
                });
            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/invest/index.blade.php ENDPATH**/ ?>