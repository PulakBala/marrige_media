<?php $__env->startSection('title'); ?>
    <title>LOGIN -</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('authform'); ?>

    <div class="card-title-sign mt-3 w-100">
        <h2 class="title text-uppercase font-weight-bold m-0"><i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Sign In</h2>
    </div>
    <div class="card-body">

    <?php echo e(config('app.google')); ?>

        <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label>Email</label>
                <div class="input-group">
                    <input name="email" type="text" class="form-control form-control-lg" value="<?php echo e(old('email')); ?>" placeholder="Enter email"/>
                    <span class="input-group-text">
                        <i class="bx bx-user text-4"></i>
                    </span>
                </div>
                <span class="text-danger">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
            </div>

            <div class="form-group mb-3">
                <div class="clearfix">
                    <label class="float-left">Password</label>
                    <a href="<?php echo e(route('password.request')); ?>" class="float-end">Lost Password?</a>
                </div>
                <div class="input-group">
                    <input name="password" type="password" class="form-control form-control-lg" placeholder="Enter password"/>
                    <span class="input-group-text">
                        <i class="bx bx-lock text-4"></i>
                    </span>
                </div>
                <span class="text-danger">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
            </div>

            <div class="row">
                <div class="col-sm-8">
                    <div class="checkbox-custom checkbox-default">
                        <input id="remember" name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
                        <label for="remember">Remember Me</label>
                    </div>
                </div>
                <div class="col-sm-4 text-end">
                    <button type="submit" class="btn btn-primary mt-2">Sign In</button>
                </div>
            </div>

            <?php if(setting('facebook') == 1 || setting('google') == 1 ||  setting('twitter') == 1 || setting('linkedin') == 1): ?>
                <span class="mt-3 mb-3 line-thru text-center text-uppercase">
                    <span>or</span>
                </span>
            <?php endif; ?>
            <div class="mb-1 text-center">
                <?php if(setting('facebook') == 1): ?>
                    <!-- Facebook -->
                    <a class="btn btn-primary border-0" style="background-color: #3b5998;" href="<?php echo e(route('facebook.redirect')); ?>" role="button"><i class="fab fa-facebook-f"></i></a>
                <?php endif; ?>

                <?php if(setting('google') == 1): ?>
                    <!-- Google -->
                    <a class="btn btn-primary border-0" style="background-color: #dd4b39;" href="<?php echo e(route('google.redirect')); ?>" role="button"><i class="fab fa-google"></i></a>
                <?php endif; ?>

                <?php if(setting('twitter') == 1): ?>
                    <!-- Twitter -->
                    <a class="btn btn-primary border-0" style="background-color: #55acee;" href="<?php echo e(route('twitter.redirect')); ?>" role="button"><i class="fab fa-twitter"></i></a>
                <?php endif; ?>

                <?php if(setting('linkedin') == 1): ?>
                    <!-- Linkedin -->
                    <a class="btn btn-primary border-0" style="background-color: #0082ca;" href="<?php echo e(route('linkedin.redirect')); ?>" role="button"><i class="fab fa-linkedin-in"></i></a>
                <?php endif; ?>
            </div>

            <p class="text-center">Don't have an account yet? <a href="<?php echo e(route('register')); ?>">Sign Up!</a></p>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>