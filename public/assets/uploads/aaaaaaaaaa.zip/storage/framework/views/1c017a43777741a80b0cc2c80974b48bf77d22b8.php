<?php $__env->startSection('title'); ?>
    <title>Document</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Document</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Document</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-12">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Documents</h2>
                    </header>
                    <div class="card-body">
                        <div class="row justify-content-center">
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 mb-3">
                                    
                                    <div class="card border">
                                        <div class="card-header">
                                            <h2 class="card-title">
                                                
                                                <a href="" target="_blank"><?php echo e($data->title); ?></a>
                                                  <a href="<?php echo e(asset($data->file)); ?>" download="<?php echo e($data->title); ?>" class="btn btn-primary">
        Download
    </a>
                                            </h2>
                                        </div>
                                       
                                        <div class="card-body">
                                            <?php
                                                $arr = explode('.', $data->file);
                                                $ext = end($arr);
                                            ?>
                                            <?php if($ext == 'pdf'): ?>
                                                <iframe src="<?php echo e(asset($data->file)); ?>" frameborder="1" class="w-100"></iframe>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset($data->file)); ?>" class="img-fluid w-100" alt="" style="height: 160px">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                       
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/document/index.blade.php ENDPATH**/ ?>