<?php $__env->startSection('title'); ?>
    <title>Creaet Share</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Creaet Share</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Creaet Share</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Add Share</h2>
                    </header>
                    <div class="card-body">
                        <form action="<?php echo e(route('user.form.update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-lg-6 mb-3">
                                    <label for="name">Name <span class="text-danger">*</span></label>
                                    <input type="text" id="name" placeholder="Enter Name" name="name" class="form-control" value="<?php echo e(old('name') ??  auth()->user()->name); ?>" readonly>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="email">Email <span class="text-danger">*</span></label>
                                    <input type="email" id="email" placeholder="Enter email" name="email" class="form-control" value="<?php echo e(old('email') ??  auth()->user()->email); ?>" readonly>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="father_name">Father/Husbend Name <span class="text-danger">*</span></label>
                                    <input type="text" id="father_name" placeholder="Enter father name" name="father_name" class="form-control" value="<?php echo e(old('father_name') ?? auth()->user()->father_name); ?>">
                                    <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="mother_name">Mother's Name <span class="text-danger">*</span></label>
                                    <input type="text" id="mother_name" placeholder="Enter mother name" name="mother_name" class="form-control" value="<?php echo e(old('mother_name') ?? auth()->user()->mother_name); ?>">
                                    <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="phone_number">Phone Number <span class="text-danger">*</span></label>
                                    <input type="number" id="phone_number" placeholder="Enter phone number" name="phone_number" class="form-control" value="<?php echo e(old('phone_number') ?? auth()->user()->phone_number); ?>">
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="education_qualification">Education Qualification <span class="text-danger">*</span></label>
                                    <input type="text" id="education_qualification" placeholder="Enter education qualification" name="education_qualification" class="form-control" value="<?php echo e(old('education_qualification') ?? auth()->user()->education_qualification); ?>">
                                    <?php $__errorArgs = ['education_qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="passport_or_nid_type">Passport/NID Type <span class="text-danger">*</span></label>
                                    <select name="passport_or_nid_type" id="passport_or_nid_type" class="form-control" required>
                                        <option value="">Select type</option>
                                        <option <?php echo e(old('passport_or_nid_type') == 'Nid'?  'selected' : ''); ?> value="Nid">Nid</option>
                                        <option <?php echo e(old('passport_or_nid_type') == 'Passport' ? 'selected' : ''); ?> value="Passport">Passport</option>
                                    </select>
                                    <?php $__errorArgs = ['passport_or_nid_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="passport_or_nid_number">Passport/NID No <span class="text-danger">*</span></label>
                                    <input type="number" id="passport_or_nid_number" placeholder="Enter passport or nid no" name="passport_or_nid_number" class="form-control" value="<?php echo e(old('passport_or_nid_number') ?? auth()->user()->passport_or_nid_number); ?>">
                                    <?php $__errorArgs = ['passport_or_nid_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="religion">Religion <span class="text-danger">*</span></label>
                                    <input type="text" id="religion" placeholder="Enter religion" name="religion" class="form-control" value="<?php echo e(old('religion') ?? auth()->user()->religion); ?>">
                                    <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="date_of_birth">Date Of Birth <span class="text-danger">*</span></label>
                                    <input type="date" id="date_of_birth" placeholder="Enter date of birth" name="date_of_birth" class="form-control">
                                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="nationality">Nationality <span class="text-danger">*</span></label>
                                    <input type="text" id="nationality" placeholder="Enter nationality" name="nationality" class="form-control" value="<?php echo e(old('nationality') ?? auth()->user()->nationality); ?>">
                                    <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="blood_group">Blood Group <span class="text-danger">*</span></label>
                                    <input type="text" id="blood_group" placeholder="Enter blood group" name="blood_group" class="form-control" value="<?php echo e(old('blood_group') ?? auth()->user()->blood_group); ?>">
                                    <?php $__errorArgs = ['blood_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="occupation">Occupation <span class="text-danger">*</span></label>
                                    <input type="text" id="occupation" placeholder="Enter occupation" name="occupation" class="form-control" value="<?php echo e(old('occupation') ?? auth()->user()->occupation); ?>">
                                    <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12">
                                    <h4>Address</h4>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="village">Village <span class="text-danger">*</span></label>
                                    <input type="text" id="village" placeholder="Enter village" name="village" class="form-control" value="<?php echo e(old('village') ?? auth()->user()->village); ?>">
                                    <?php $__errorArgs = ['village'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="word_no">Word No <span class="text-danger">*</span></label>
                                    <input type="number" id="word_no" placeholder="Enter word no" name="word_no" class="form-control" value="<?php echo e(old('word_no') ?? auth()->user()->word_no); ?>">
                                    <?php $__errorArgs = ['word_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="post_office">Post Office <span class="text-danger">*</span></label>
                                    <input type="text" id="post_office" placeholder="Enter post office" name="post_office" class="form-control" value="<?php echo e(old('post_office') ?? auth()->user()->post_office); ?>">
                                    <?php $__errorArgs = ['post_office'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="thana">Thana <span class="text-danger">*</span></label>
                                    <input type="text" id="thana" placeholder="Enter thana" name="thana" class="form-control" value="<?php echo e(old('thana') ?? auth()->user()->thana); ?>">
                                    <?php $__errorArgs = ['thana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="upzilla">Upzilla <span class="text-danger">*</span></label>
                                    <input type="text" id="upzilla" placeholder="Enter upzilla" name="upzilla" class="form-control" value="<?php echo e(old('upzilla') ?? auth()->user()->upzilla); ?>">
                                    <?php $__errorArgs = ['upzilla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="district">District <span class="text-danger">*</span></label>
                                    <input type="text" id="district" placeholder="Enter district" name="district" class="form-control" value="<?php echo e(old('district') ?? auth()->user()->district); ?>">
                                    <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <button type="submit" id="submit" class="btn btn-primary mt-2">Submit</button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/form.blade.php ENDPATH**/ ?>