<?php $__env->startSection('title'); ?>
    <title>Payment Request</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/datatables/media/css/dataTables.bootstrap5.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Payment Request</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Payment Request</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Payment Request</h2>
                    </header>
                    <div class="card-body">
                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Payment Method</th>
                                    <th>Sender Number</th>
                                    <th>Amount</th>
                                    <th>Transaction ID</th>
                                    <th>Payment Status</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <td><?php echo e(++$loop->index); ?></td>
                                        <td><?php echo e($data->month. ', ' . $data->year); ?></td>
                                        <td class="text-nowrap">
                                            <div class="d-flex justify-content-start align-items-center">
                                                <img src="<?php echo e(asset($data->fundWithUserRelation->profile)); ?>" alt="" width="40" class="border">
                                                <div class="mx-1">
                                                    <b><?php echo e($data->fundWithUserRelation->name); ?></b>
                                                    <span class="d-block"><b>Profile ID: </b> <?php echo e($data->fundWithUserRelation->profile_id); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($data->type == 'mobile-banking'): ?>
                                                <?php echo e($data->mobileGetwayWithFundRelation->account_name); ?>

                                            <?php elseif($data->type == 'bank-details'): ?>
                                                <?php echo e($data->bankGetwayWithFundRelation->bank_name); ?>

                                            <?php else: ?>
                                                Cash Payment
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($data->sender_number); ?> </td>
                                        <td><?php echo e($data->amount); ?> tk</td>
                                        <td><?php echo e($data->trx_id); ?></td>
                                        <td>
                                            <span class="text-capitalize"><?php echo e($data->payment_status); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-capitalize"><?php echo e($data->status); ?></span>
                                        </td>
                                        <td>
                                            <?php if($data->status == 'pending'): ?>
                                                <a href="<?php echo e(route('admin.fund.approvedStatus', $data->id)); ?>" class="btn btn-sm btn-success">Approved</a>
                                                <a href="<?php echo e(route('admin.fund.rejectedStatus', $data->id)); ?>" class="btn btn-sm btn-danger">Rejected</a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('admin.fund.deleteStatus', $data->id)); ?>" onclick="return confirm('Are you want to delete?');" class="btn btn-sm btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="<?php echo e(asset('admin')); ?>/js/examples/examples.datatables.tabletools.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/fund/index.blade.php ENDPATH**/ ?>