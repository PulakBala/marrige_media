
<?php $__env->startSection('title'); ?>
    <title>Settings</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/bootstrap-multiselect/css/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

    <style>
        .bootstrap-tagsinput .badge {
            margin: 2px !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                <?php echo $__env->make('admins.partials.setting-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">
                                <form action="<?php echo e(route('admin.meta.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <input type="hidden" name="metas[]" value="author_name">
                                                <input type="hidden" name="metas[]" value="meta_keyword">
                                                <input type="hidden" name="metas[]" value="meta_tags">
                                                <input type="hidden" name="metas[]" value="meta_description">
                                                <div class="col-lg-4 form-group border-0">
                                                    <label for="">Meta Author</label>
                                                    <input type="text" name="author_name" placeholder="Enter Author Name" class="form-control"  value="<?php echo e(old('author_name') ? old('author_name') : setting('author_name')); ?>">
                                                    <?php $__errorArgs = ['author_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-lg-4 form-group border-0">
                                                    <label for="meta_tags">Meta Tags</label>
                                                    <input type="text" name="meta_keyword" id="meta_tags" data-role="tagsinput" placeholder="Enter Meta Tags" class="form-control" value="<?php echo e(old('meta_tags') ? old('meta_tags') : setting('meta_tags')); ?>">
                                                    <?php $__errorArgs = ['meta_tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-lg-4 form-group border-0">
                                                    <label for="meta_keywords">Meta Keywords</label>
                                                    <input type="text" name="meta_tags" id="meta_keywords" data-role="tagsinput" placeholder="Enter Meta Keywords" class="form-control" value="<?php echo e(old('meta_keyword') ? old('meta_keyword') : setting('meta_keyword')); ?>">
                                                    <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-lg-12 form-group">
                                                    <label for="meta_description">Meta Description</label>
                                                    <textarea name="meta_description" id="meta_description" class="form-control" rows="5" placeholder="Enter Meta Description"><?php echo e(old('meta_description') ? old('meta_description') : setting('meta_description')); ?></textarea>
                                                    <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <div class="form-group row pb-4">
                                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                                <div class="col-lg-6">
                                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('admin')); ?>/vendor/bootstrapv5-multiselect/js/bootstrap-multiselect.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/js/examples/examples.advanced.form.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/settings/meta.blade.php ENDPATH**/ ?>