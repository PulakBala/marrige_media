<!doctype html>
<html class="fixed">
	<head>
		<!-- Basic -->
		<meta charset="UTF-8">
        <meta http-equiv="refresh" content="60">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">
        <link rel="icon" href="">
		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/bootstrap/css/bootstrap.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/font-awesome/css/all.min.css" />
		<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/boxicons/css/boxicons.min.css" />
        <!-- Theme CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/theme.css" />
		<!-- Skin CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/skins/default.css" />
        <style>
            img {
                text-align: center;
                margin: 0 auto;
                margin-bottom: 0px !important;
            }
            .body-sign .card-sign .card-title-sign .title {
                width: 100%;
                text-align: center;
            }
            body{
                background-image: linear-gradient(to bottom, rgba(142,97,231, 0.32), rgba(117, 19, 93, 0.73));
            }
        </style>
        <?php echo $__env->yieldContent('title'); ?>

	</head>
	<body>
		<!-- start: page -->
		<section class="body-sign">
			<div class="center-sign ">
                <div class="text-center">

                        <a href="<?php echo e(url('/')); ?>" class="logo">
                            <img  class="logo" src="<?php echo e(asset('admin/logo-circle.jpg')); ?>" width="120" alt="logo">
                        </a>
                </div>

				<div class="panel card-sign">
					<?php echo $__env->yieldContent('authform'); ?>
				</div>

				
			</div>
		</section>
		<!-- end: page -->


        <?php echo $__env->yieldContent('scripts'); ?>
	</body>
</html>
<?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/auth/layouts/auth_app.blade.php ENDPATH**/ ?>