<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,300,400,500,700,900" rel="stylesheet">

    <title><?php echo e(setting('title')); ?></title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend')); ?>/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend')); ?>/css/font-awesome.css">

    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/css/templatemo-softy-pinko.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/css/style.css">
    <link rel="shortcut icon" href="<?php echo e(asset(setting('favicon'))); ?>" type="image/x-icon">
    
    <style>

    </style>
</head>

<body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->
<?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/partials/header.blade.php ENDPATH**/ ?>