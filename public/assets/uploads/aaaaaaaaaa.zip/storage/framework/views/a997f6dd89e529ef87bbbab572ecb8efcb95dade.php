<?php $__env->startSection('title'); ?>
    <title>Mobile Getway Lists</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/datatables/media/css/dataTables.bootstrap5.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Mobile Getway Lists</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Mobile Getway</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">All Mobile Getway</h2>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th class="text-nowrap">Account Name</th>
                                    <th class="text-nowrap">Account Number</th>
                                    <th class="text-nowrap">Account Type</th>
                                    <th class="text-nowrap">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <td class="text-nowrap">
                                            <div class="d-flex justify-content-start align-items-center w-100">
                                                <img src="<?php echo e(asset( 'public/'. $data->logo)); ?>" alt="" class="img-fluid border p-1" width="70" height="70">
                                                <h4 class="my-0 px-2"><?php echo e($data->account_name); ?></h4>
                                            </div>
                                        </td>
                                        <td class="text-nowrap" ><?php echo e($data->account_number); ?></td>
                                        <td class="text-nowrap text-capitalize" ><?php echo e($data->account_type); ?></td>
                                        <td class="text-nowrap" >
                                        <form action="<?php echo e(route('mobile-payment-getway.destroy', $data->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                            <a href="<?php echo e(route('mobile-payment-getway.edit', $data->id)); ?>" class="text-info"><i class="fas fa-pencil-alt"></i></a>
                                            <button type="submit" class="text-danger border-0" style="background: none" onclick="return confirm('Are you sure you want to delete this item?');"><i class="far fa-trash-alt"></i></button>
                                        </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="<?php echo e(asset('admin')); ?>/js/examples/examples.datatables.tabletools.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/mobile-getway/index.blade.php ENDPATH**/ ?>