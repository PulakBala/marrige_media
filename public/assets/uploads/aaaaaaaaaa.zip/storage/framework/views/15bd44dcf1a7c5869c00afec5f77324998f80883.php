<?php $__env->startSection('title'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Dashboard</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <!-- start: page -->
        <div class="row mb-3 justify-content-center">
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fa fa-users"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Users</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($totalUsers); ?></strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                <a class="text-muted text-uppercase" href="<?php echo e(route('admin.users.index')); ?>">(view all)</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fa fa-share"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Share Request</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($shareRequest); ?></strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                <a class="text-muted text-uppercase" href="<?php echo e(route('admin.share.index')); ?>">(view all)</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Payment Request</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($paymentRequest); ?></strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                <a class="text-muted text-uppercase" href="<?php echo e(route('admin.fund.pendingRequest')); ?>">(view all)</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Fund</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($totalFund); ?> tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Due</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($totalDue); ?> tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Invest</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($totalInvest); ?> tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Profit</h4>
                                    <div class="info">
                                        <strong class="amount"><?php echo e($totalInvestProfit); ?> tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Loan</h4>
                                    <div class="info">
                                        <strong class="amount">0 tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Jakat</h4>
                                    <div class="info">
                                        <strong class="amount">0 tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/index.blade.php ENDPATH**/ ?>