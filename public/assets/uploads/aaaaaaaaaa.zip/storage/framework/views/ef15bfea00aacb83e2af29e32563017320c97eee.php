
<?php $__env->startSection('title'); ?>
    <title>Settings</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                <?php echo $__env->make('admins.partials.setting-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">
                                <div class="active">
                                    <form class="form-horizontal form-bordered" method="POST" action="<?php echo e(route('admin.setting.email.update')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="mail_transport" name="credentials[]">
                                        <input type="hidden" value="mail_host" name="credentials[]">
                                        <input type="hidden" value="mail_port" name="credentials[]">
                                        <input type="hidden" value="mail_username" name="credentials[]">
                                        <input type="hidden" value="mail_password" name="credentials[]">
                                        <input type="hidden" value="mail_encryption" name="credentials[]">
                                        <input type="hidden" value="mail_from" name="credentials[]">
                                        <input type="hidden" value="mail_from_name" name="credentials[]">
                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_transport">Mail Transport</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_transport" name="mail_transport" title="Enter mail transport" value="<?php echo e(setting('mail_transport')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_transport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_host">Mail Host</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_host" name="mail_host" title="Enter mail host" value="<?php echo e(setting('mail_host')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>


                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_port">Mail Port</label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" id="mail_port" name="mail_port" title="Enter mail port" value="<?php echo e(setting('mail_port')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_username">Mail Username</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_username" name="mail_username" title="Enter mail username" value="<?php echo e(setting('mail_username')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>


                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_password">Mail Password</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_password" name="mail_password" title="Enter mail username" value="<?php echo e(setting('mail_password')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_encryption">Mail Encryption</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_encryption" name="mail_encryption" title="Enter mail username" value="<?php echo e(setting('mail_encryption')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_from">Mail From</label>
                                            <div class="col-lg-6">
                                                <input type="email" class="form-control" id="mail_from" name="mail_from" title="Enter mail username" value="<?php echo e(setting('mail_from')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_from_name">Mail From Name</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_from_name" name="mail_from_name" title="Enter mail username" value="<?php echo e(setting('mail_from_name')); ?>">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['mail_from_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-group row pb-4">
                                            <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" class="btn btn-success">Save and Update</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/admins/settings/email-credentials.blade.php ENDPATH**/ ?>