<?php $__env->startSection('content'); ?>
<br><br><br><br>
    <section class="" id="team">
        <div class="mini-content">
            <div class="container">
                <div class="py-5 team4">
                    <div class="container">
                        <div class="row justify-content-center mb-4">
                            <div class="col-md-7 text-center">
                                <h3 class="mb-3"><?php echo e($data->title); ?></h3>
                            </div>
                        </div>
                        <div class="row">
                            <?php echo $data->content; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/page.blade.php ENDPATH**/ ?>