
    <!-- ***** Footer Start ***** -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <ul class="social">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 copyright">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="nav justify-content-center">
                                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(route('frontend.privacyPolicy')); ?>">Privacy Policy</a></li>
                                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(route('frontend.tramsAndCondition')); ?>">Trams & Condition</a></li>
                                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(route('frontend.dmca')); ?>">DMCA</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-6 justify-content-center mt-2">
                            <p class="">Copyright &copy;
                                <script>document.write(new Date().getFullYear())</script> Abosor All Righgt Reserved.
                            </p>
                            <p class="text-center">
                                <a href="https://spurepix.com/" class="text-white" target="_blank">Developed by SpurePix</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="<?php echo e(asset('frontend')); ?>/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="<?php echo e(asset('frontend')); ?>/js/popper.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="<?php echo e(asset('frontend')); ?>/js/scrollreveal.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/js/waypoints.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/js/jquery.counterup.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/js/imgfix.min.js"></script>

    <!-- Global Init -->
    <script src="<?php echo e(asset('frontend')); ?>/js/custom.js"></script>

</body>

</html>
<?php /**PATH /home/u455025027/domains/abosor-com-570072.hostingersite.com/public_html/resources/views/partials/footer.blade.php ENDPATH**/ ?>