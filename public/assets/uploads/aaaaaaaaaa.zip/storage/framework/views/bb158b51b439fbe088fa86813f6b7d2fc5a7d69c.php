<!doctype html>
<html class="fixed">
	<head>
		<!-- Basic -->
		<meta charset="UTF-8">
		<?php echo $__env->yieldContent('title'); ?>
		<meta name="description" content="<?php echo e(setting('meta_description')); ?>">
        <meta name="keywords" content="<?php echo e(setting('meta_keyword')); ?>">
        <meta name="tags" content="<?php echo e(setting('meta_tags')); ?>">
		<meta name="author" content="<?php echo e(setting('author_name')); ?>">
        <link rel="icon" href="<?php echo e(asset(setting('favicon'))); ?>">
		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/bootstrap/css/bootstrap.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/font-awesome/css/all.min.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/boxicons/css/boxicons.min.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/vendor/pnotify/pnotify.custom.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/theme.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/skins/default.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/custom.css">
        <style>
            .active {
                background-color: transparent !important;
            }
        </style>
        <?php echo $__env->yieldContent('styles'); ?>
	</head>
	<body class="loading-overlay-showing" data-loading-overlay>

        <div class="loading-overlay">
            <div class="bounce-loader">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>


		<section class="body">
			<!-- start: header -->
			<header class="header">
				<div class="logo-container">
					<a href="" class="logo">
                        <img class="logo" src="<?php echo e(asset('public/' . setting('logo'))); ?>" width="100" alt="aaaa">
					</a>

					<div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fas fa-bars" aria-label="Toggle sidebar"></i>
					</div>

				</div>

				<!-- start: search & user box -->
				<div class="header-right">



					<span class="separator"></span>

					<div id="userbox" class="userbox">
						<a href="#" data-bs-toggle="dropdown">
							<figure class="profile-picture">
								<img src="<?php echo e(asset('public/' . auth()->user()->profile)); ?>" alt="Joseph Doe" class="rounded-circle" data-lock-picture="img/!logged-user.jpg" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name"><?php echo e(auth()->user()->name); ?></span>
								<span class="role">User</span>
							</div>

							<i class="fa custom-caret"></i>
						</a>

						<div class="dropdown-menu">
							<ul class="list-unstyled mb-2">
								<li class="divider"></li>
								<li>
                                    <a role="menuitem" tabindex="-1" href="<?php echo e(route('user.profile.index')); ?>"><i class="bx bx-user-circle"></i> My Profile</a>
								</li>
                                
								<li>
									<a role="menuitem" tabindex="-1" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="bx bx-power-off"></i> Logout</a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">

				    <div class="sidebar-header">
				        <div class="sidebar-title">
				            &nbsp;
				        </div>
				        <div class="sidebar-toggle d-none d-md-block" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
				            <i class="fas fa-bars" aria-label="Toggle sidebar"></i>
				        </div>
				    </div>

				    <div class="nano">
				        <div class="nano-content">
                            <?php echo $__env->make('users.partials.side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				        </div>

				        <script>
				            // Maintain Scroll Position
				            if (typeof localStorage !== 'undefined') {
				                if (localStorage.getItem('sidebar-left-position') !== null) {
				                    var initialPosition = localStorage.getItem('sidebar-left-position'),
				                        sidebarLeft = document.querySelector('#sidebar-left .nano-content');

				                    sidebarLeft.scrollTop = initialPosition;
				                }
				            }
				        </script>
				    </div>
				</aside>
				<!-- end: sidebar -->
                <?php echo $__env->yieldContent('content'); ?>
			</div>
		</section>

        <script src="<?php echo e(asset('admin')); ?>/vendor/jquery/jquery.js"></script>
		<script src="<?php echo e(asset('admin')); ?>vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/common/common.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/pnotify/pnotify.custom.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/theme.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/js/examples/examples.notifications.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/vendor/modernizr/modernizr.js"></script>

        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

        </script>

        <?php if(session('success')): ?>
            <script>
                new PNotify({
                    title: 'Success',
                    text: '<?php echo e(session("success")); ?>',
                    type: 'success',
                    addclass: 'notification-success',
                    icon: 'fas fa-check'
                });
            </script>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <script>
                new PNotify({
                    title: 'Error',
                    text: '<?php echo e(session("error")); ?>',
                    type: 'Error',
                    addclass: 'notification-danger',
                    icon: 'fas fa-times'
                });
            </script>
        <?php endif; ?>
        <?php echo $__env->yieldContent('scripts'); ?>
	</body>
</html>
<?php /**PATH /home/u455025027/domains/abosor.com/public_html/resources/views/users/layouts/app_user.blade.php ENDPATH**/ ?>