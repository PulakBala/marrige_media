<?php

use App\Http\Controllers\Admin\AdminAboutController;
use App\Http\Controllers\Admin\AdminBankPaymentGetwayController;
use App\Http\Controllers\Admin\AdminDocumentController;
use App\Http\Controllers\Admin\AdminFeaturedAreaController;
use App\Http\Controllers\Admin\AdminFundController;
use App\Http\Controllers\Admin\AdminHomeController;
use App\Http\Controllers\Admin\AdminInvestController;
use App\Http\Controllers\Admin\AdminMobilePaymentGetwayController;
use App\Http\Controllers\Admin\AdminPageController;
use App\Http\Controllers\Admin\AdminProfileController;
use App\Http\Controllers\Admin\AdminSettingController;
use App\Http\Controllers\Admin\AdminShareController;
use App\Http\Controllers\Admin\AdminTeamController;
use App\Http\Controllers\Admin\AdminUserController;
use App\Http\Controllers\Admin\AdminWorkProcessController;
use App\Http\Controllers\FrontendController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Socialite\FacebookController;
use App\Http\Controllers\Socialite\GoogleController;
use App\Http\Controllers\Socialite\LinkedinController;
use App\Http\Controllers\Socialite\TwitterController;
use App\Http\Controllers\User\UserDocumentController;
use App\Http\Controllers\User\UserFundController;
use App\Http\Controllers\User\UserHomeController;
use App\Http\Controllers\User\UserProfileController;
use App\Http\Controllers\User\UserShareController;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// cache clear
Route::get('/reboot', function () {
    Artisan::call('cache:clear');
    Artisan::call('view:clear');
    Artisan::call('route:clear');
    Artisan::call('config:cache');
    Artisan::call('view:cache');
    // composer dump-autoload
    dd('Done');
});




Route::get('/', [FrontendController::class, 'index'])->name('frontend.index');
Route::get('/privacy-policy', [FrontendController::class, 'privacyPolicy'])->name('frontend.privacyPolicy');
Route::get('/trams-and-condition', [FrontendController::class, 'tramsAndCondition'])->name('frontend.tramsAndCondition');
Route::get('/dmca', [FrontendController::class, 'dmca'])->name('frontend.dmca');

Auth::routes([
    'verify' => true
]);

Route::get('/home', [HomeController::class, 'index'])->name('home');

// google redirect routes
Route::get('/google/redirect', [GoogleController::class, 'googleRedirect'])->name('google.redirect');
Route::get('/google/callback', [GoogleController::class, 'googleCallback'])->name('google.callback');

// facebook redirect routes
Route::get('/facebook/redirect', [FacebookController::class, 'facebookRedirect'])->name('facebook.redirect');
Route::get('/facebook/callback', [FacebookController::class, 'facebookCallback'])->name('facebook.callback');

// twitter redirect routes
Route::get('/twitter/redirect', [TwitterController::class, 'twitterRedirect'])->name('twitter.redirect');
Route::get('/twitter/callback', [TwitterController::class, 'twitterCallback'])->name('twitter.callback');

// linkedin redirect routes
Route::get('/linkedin/redirect', [LinkedinController::class, 'linkedinRedirect'])->name('linkedin.redirect');
Route::get('/linkedin/callback', [LinkedinController::class, 'linkedinCallback'])->name('linkedin.callback');

Route::group(['prefix' => 'admin', 'middleware' => ['auth', 'is_admin']], function() {
    Route::get('/dashboard', [AdminHomeController::class, 'index'])->name('admin.dashboard');



    Route::get('/general-settings', [AdminSettingController::class, 'index'])->name('admin.setting.index');
    Route::get('/meta-settings', [AdminSettingController::class, 'meta'])->name('admin.setting.meta');
    Route::post('/update-meta-tag', [AdminSettingController::class, 'updateMeta'])->name('admin.meta.update');
    Route::post('/general-settings', [AdminSettingController::class, 'updateSetting'])->name('admin.setting.update');

    Route::get('/email-configure', [AdminSettingController::class, 'emailCredentials'])->name('admin.setting.email');
    Route::post('/email-configure', [AdminSettingController::class, 'emailCredentialsUpdate'])->name('admin.setting.email.update');

    // google login credentials
    Route::get('/socialite-settings', [AdminSettingController::class, 'socialite'])->name('admin.setting.socialite');
    Route::post('update/google-credentials', [GoogleController::class, 'updateCredentials'])->name('admin.update.google.credentials');
    Route::get('update/google-switch', [GoogleController::class, 'updateGoogleSwitch'])->name('admin.update.google.switch');

    // facebook login credentials
    Route::post('update/facebook-credentials', [FacebookController::class, 'updateCredentials'])->name('admin.update.facebook.credentials');
    Route::get('update/facebook-switch', [FacebookController::class, 'updateFacebookSwitch'])->name('admin.update.facebook.switch');

    // twitter login credentials
    Route::post('update/twitter-credentials', [TwitterController::class, 'updateCredentials'])->name('admin.update.twitter.credentials');
    Route::get('update/twitter/switch', [TwitterController::class, 'updateTwitterSwitch'])->name('admin.update.twitter.switch');

    // linkedin login credentials
    Route::post('update/linkedin-credentials', [LinkedinController::class, 'updateCredentials'])->name('admin.update.linkedin.credentials');
    Route::get('update/linkedin/switch', [LinkedinController::class, 'updateLinkedinSwitch'])->name('admin.update.linkedin.switch');

    // admin profile
    Route::get('/profile', [AdminProfileController::class, 'index'])->name('admin.profile.index');
    Route::post('/update-profile', [AdminProfileController::class, 'updateProfile'])->name('admin.profile.update');
    Route::post('/update-email', [AdminProfileController::class, 'updateEmail'])->name('admin.email.update');
    Route::post('/update-password', [AdminProfileController::class, 'updatePassword'])->name('admin.password.update');

    // User's lists
    Route::get('users', [AdminUserController::class, 'index'])->name('admin.users.index');
    Route::get('users/{id}/details', [AdminUserController::class, 'details'])->name('admin.user.details');
    Route::get('users/{id}/edit', [AdminUserController::class, 'edit'])->name('admin.user.edit');
    Route::get('users/create', [AdminUserController::class, 'create'])->name('admin.user.create');
    Route::post('users/store', [AdminUserController::class, 'store'])->name('admin.user.store');
    Route::post('users/{id}/update', [AdminUserController::class, 'update'])->name('admin.user.update');
    Route::post('users/{id}/add-fund', [AdminUserController::class, 'addFund'])->name('admin.user.addFund');
    Route::post('users/{id}/add-due', [AdminUserController::class, 'addDue'])->name('admin.user.addDue');
    Route::get('users/{id}/show-due', [AdminUserController::class, 'dueShow'])->name('admin.users.dueShow');
    Route::get('users/{id}/delete-due', [AdminUserController::class, 'deleteDue'])->name('admin.users.due.delete');
    Route::get('users/{id}/delete', [AdminUserController::class, 'delete'])->name('admin.user.delete');
    Route::get('users/{id}/download-details', [AdminUserController::class, 'downloadDetails'])->name('admin.user.downloadDetails');
    Route::get('users/{id}/email-verified', [AdminUserController::class, 'emailVerified'])->name('admin.user.emailVerified');


    Route::resource('page', AdminPageController::class);
    Route::resource('team', AdminTeamController::class);
    Route::get('about', [AdminAboutController::class, 'index'])->name('admin.about.index');
    Route::post('about', [AdminAboutController::class, 'update'])->name('admin.about.update');
    Route::get('welcome-area', [AdminAboutController::class, 'welcome'])->name('admin.welcome.edit');
    Route::post('welcome-area', [AdminAboutController::class, 'welcomeUpdate'])->name('admin.welcome.update');
    Route::resource('work-processes', AdminWorkProcessController::class);
    Route::get('featured-area', [AdminFeaturedAreaController::class, 'index'])->name('admin.feature.index');
    Route::get('featured-area/{id}/edit', [AdminFeaturedAreaController::class, 'edit'])->name('admin.feature.edit');
    Route::post('featured-area/{id}/update', [AdminFeaturedAreaController::class, 'update'])->name('admin.feature.update');

    Route::resource('mobile-payment-getway', AdminMobilePaymentGetwayController::class);
    Route::resource('bank-payment-getway', AdminBankPaymentGetwayController::class);
    Route::resource('document', AdminDocumentController::class);
    Route::resource('invest', AdminInvestController::class);
    Route::post('/invest/monthly-profit/{id}', [AdmininvestController::class, 'storeMonthlyProfit'])->name('invest.store.monthly.profit');
    Route::get('invest/profit-history/{id}', [AdmininvestController::class, 'getProfitHistory'])->name('invest.profit.history');



    Route::get('shares', [AdminShareController::class, 'index'])->name('admin.share.index');
    Route::post('chash-payment-amount', [AdminShareController::class, 'getShareAmount'])->name('admin.user.getShareAmount');
    Route::get('share/{id}/accept', [AdminShareController::class, 'acceptStatus'])->name('admin.share.acceptStatus');
    Route::get('share/{id}/rejected', [AdminShareController::class, 'rejectedStatus'])->name('admin.share.rejectedStatus');
    Route::get('share/{id}/delete', [AdminShareController::class, 'delete'])->name('admin.share.delete');


    Route::get('cash-payment', [AdminFundController::class, 'cashPayment'])->name('admin.fund.cashPayment');
    Route::post('cash-payment', [AdminFundController::class, 'cashPaymentStore'])->name('admin.fund.cashPayment.store');
    Route::get('penidng-request', [AdminFundController::class, 'pending'])->name('admin.fund.pendingRequest');
    Route::get('approved-request', [AdminFundController::class, 'approved'])->name('admin.fund.approvedRequest');
    Route::get('rejected-request', [AdminFundController::class, 'rejected'])->name('admin.fund.rejectedRequest');

    Route::get('approvedStatus/{id}', [AdminFundController::class, 'approvedStatus'])->name('admin.fund.approvedStatus');
    Route::get('rejectedStatus/{id}', [AdminFundController::class, 'rejectedStatus'])->name('admin.fund.rejectedStatus');
    Route::get('deleteStatus/{id}', [AdminFundController::class, 'deleteStatus'])->name('admin.fund.deleteStatus');



});



Route::group(['prefix' => 'user', 'middleware' => ['auth', 'is_user', 'verified']], function() {
    Route::get('/dashboard', [UserHomeController::class, 'index'])->name('user.dashboard');
    Route::get('/form', [UserHomeController::class, 'form'])->name('user.form.submit');
    Route::post('/form', [UserHomeController::class, 'update'])->name('user.form.update');

    // user profile
    Route::get('/profile', [UserProfileController::class, 'index'])->name('user.profile.index');
    Route::post('/update-profile', [UserProfileController::class, 'updateProfile'])->name('user.profile.update');
    Route::post('/update-email', [UserProfileController::class, 'updateEmail'])->name('user.email.update');
    Route::post('/update-password', [UserProfileController::class, 'updatePassword'])->name('user.password.update');

    Route::resource('share', UserShareController::class);

    Route::get('/add-fund', [UserFundController::class, 'index'])->name('user.fund.index');
    Route::get('/payment/{name}/{id}/{type}', [UserFundController::class, 'create'])->name('user.payment.create');
    Route::post('/payment', [UserFundController::class, 'store'])->name('user.payment.store');
    Route::get('/payment/history', [UserFundController::class, 'history'])->name('user.payment.history');
    Route::get('/show-due', [UserFundController::class, 'due'])->name('user.fund.due');

    Route::get('/documents', [UserDocumentController::class, 'index'])->name('user.document.index');



});
