@extends('users.layouts.app_user')
@section('title')
    <title>Payment</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Payment</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Payment</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Payment by (<span class="text-danger">{{$getway->bank_name ?? $getway->account_name }}</span>)</h2><br>
                        @if ($type == 'mobile-banking')
                            <p class="text-dark" style="margin-bottom: 0px"><b>Account Number</b> : {{ $getway->account_number }} (<small class="text-capitalize text-success">{{ $getway->account_type }}</small>)</p>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Transfer Type</b> : <span class="text-capitalize">{{ $getway->account_type == 'personal' ? 'Send Money' : 'Cash Out' }}</span></p>
                        @else
                            <p class="text-dark" style="margin-bottom: 0px"><b>Name</b> : {{ $getway->account_name }}</p>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Account Number</b> : {{ $getway->account_number }}</p>
                            <p class="text-dark" style="margin-bottom: 0px"><b>Brunch Name</b> : {{ $getway->branch_name }}</p>
                        @endif
                    </header>
                    <div class="card-body">
                        <form role="form" action="{{ route('user.payment.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" value="{{ $getway->id }}" name="getway_id">
                            <input type="hidden" value="{{ $type }}" name="type">
                            <input type="hidden" value="{{ $share }}" name="share">
                          <div class="card-body">
                            <div class="row mb-3">
                                <div class="form-group col-md-4 border-0">
                                    <label for="month">Select Month</label>
                                    <select name="month" id="month" class="form-control">
                                        <option value="January">January</option>
                                        <option value="February">February</option>
                                        <option value="March">March</option>
                                        <option value="April">April</option>
                                        <option value="May">May</option>
                                        <option value="June">June</option>
                                        <option value="July">July</option>
                                        <option value="August">August</option>
                                        <option value="September">September</option>
                                        <option value="October">October</option>
                                        <option value="November">November</option>
                                        <option value="December">December</option>
                                    </select>
                                    @error('month')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="form-group col-md-4 border-0">
                                    <label for="year">Select Year</label>
                                    <select name="year" id="year" class="form-control">
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                        <option value="2026">2026</option>
                                        <option value="2027">2027</option>
                                        <option value="2028">2028</option>
                                        <option value="2029">2029</option>
                                        <option value="2030">2030</option>
                                        <option value="2031">2031</option>
                                        <option value="2032">2032</option>
                                        <option value="2033">2033</option>
                                        <option value="2034">2034</option>
                                        <option value="2035">2035</option>
                                        <option value="2036">2036</option>
                                        <option value="2037">2037</option>
                                        <option value="2038">2038</option>
                                        <option value="2039">2039</option>
                                        <option value="2040">2040</option>
                                        <option value="2041">2041</option>
                                        <option value="2042">2042</option>
                                        <option value="2043">2043</option>
                                        <option value="2044">2044</option>
                                        <option value="2045">2045</option>
                                        <option value="2046">2046</option>
                                        <option value="2047">2047</option>
                                        <option value="2048">2048</option>
                                        <option value="2049">2049</option>
                                        <option value="2050">2050</option>
                                    </select>
                                    @error('year')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="form-group col-md-4 border-0">
                                    <label for="payment_status">Select Payment Sutatus</label>
                                    <select name="payment_status" id="payment_status" class="form-control">
                                        <option value="main">Main Payment</option>
                                        <option value="due">Due Payment</option>
                                    </select>
                                    @error('payment_status')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                            </div>
                            <div class="form-group">
                                <label for="sender_number">Sender Account Number</label>
                                <input type="text" name="sender_number" class="form-control" id="sender_number" placeholder="Enter sender account number" value="{{ old('sender_number') }}">
                                @error('sender_number')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount</label>
                                <input type="text" readonly name="amount" class="form-control" id="amount" placeholder="Enter amount" value="{{ $share * 2000 }}">
                                @error('amount')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="transaction_id">Transaction ID</label>
                                <input type="text" name="transaction_id" class="form-control" id="transaction_id" placeholder="Enter transaction id" value="{{ old('transaction_id') }}">
                                @error('transaction_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                          </div>
                          <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Submit </button>
                          </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')



@endsection
