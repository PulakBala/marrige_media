@extends('users.layouts.app_user')
@section('title')
    <title>Add Fund</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Add Fund</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Add Fund</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-10">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Select Payment Method</h2>
                    </header>
                    <div class="card-body">
                        <div class="row justify-content-center">
                            @foreach ($mgetways as $getway)
                                <div class="col-lg-2">
                                    <a href="{{ route('user.payment.create', [$getway->account_name, Crypt::encrypt($getway->id), 'mobile-banking']) }}">
                                        <div class="card border">
                                            <div class="card-header">
                                                <h2 class="card-title text-center mp-0">{{ $getway->account_name }}</h2>
                                            </div>
                                            <div class="card-body">
                                                <img src="{{ asset('public/' . $getway->logo) }}" alt="" class="img-fluid w-100">
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endforeach

                            @foreach ($bgetways as $getway)
                                <div class="col-lg-2">
                                    <a href="{{ route('user.payment.create', [$getway->bank_name, Crypt::encrypt($getway->id), 'bank-details']) }}">
                                        <div class="card border">
                                            <div class="card-header">
                                                <h2 class="card-title text-center mp-0">{{ $getway->bank_name }}</h2>
                                            </div>
                                            <div class="card-body">
                                                <img src="{{ asset('public/' . $getway->logo) }}" alt="" class="img-fluid w-100">
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')

@endsection
