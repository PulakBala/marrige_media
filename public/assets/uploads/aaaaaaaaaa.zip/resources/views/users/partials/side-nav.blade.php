<style>
    .active {
        color: #0099e6 !important;
        background-color: #21262d;
    }
</style>
<nav id="menu" class="nav-main" role="navigation">
    <ul class="nav nav-main">
        <li>
            <a class="nav-link {{ Request::url() == route('user.dashboard') ? 'active' : '' }}" href="{{ route('user.dashboard') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li>
            <a class="nav-link {{ Request::url() == route('user.form.submit') ? 'active' : '' }}" href="{{ route('user.form.submit') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Form Submit</span>
            </a>
        </li>

        <li>
            <a class="nav-link {{ Request::url() == route('user.payment.history') ? 'active' : '' }}" href="{{ route('user.payment.history') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Payment History</span>
            </a>
        </li>

        <li>
            <a class="nav-link" href="{{ route('user.fund.index') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Add Fund</span>
            </a>
        </li>

        <li>
            <a class="nav-link" href="{{ route('user.document.index') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Docoment</span>
            </a>
        </li>

        <li>
            <a class="nav-link" href="#">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Loan</span>
            </a>
        </li>

        <li>
            <a class="nav-link {{ Request::url() == route('share.index') ? 'active' : '' }}" href="{{ route('share.index') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Share</span>
            </a>
        </li>

        {{-- <li class="nav-parent {{ Request::url() == route('admin.users.index') ? 'nav-expanded' : '' }}">
            <a class="nav-link {{ Request::url() == route('admin.users.index') ? 'active' : '' }}" href="#">
                <i class="bx bx-cart-alt" aria-hidden="true"></i>
                <span>Users</span>
            </a>
            <ul class="nav nav-children">
                <li>
                    <a class="nav-link {{ Request::url() == route('admin.users.index') ? 'active' : '' }}" href="{{ route('admin.users.index') }}">
                        User List
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="">
                        Add User
                    </a>
                </li>
            </ul>
        </li>




        <li>
            <a class="nav-link {{ Request::url() == route('page.index') ? 'active' : '' }}" href="{{ route('page.index') }}">
                <i class="bx bx-home-alt" aria-hidden="true"></i>
                <span>Pages</span>
            </a>
        </li> --}}


    </ul>
</nav>
