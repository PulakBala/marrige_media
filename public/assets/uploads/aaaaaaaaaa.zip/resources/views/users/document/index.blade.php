@extends('users.layouts.app_user')
@section('title')
    <title>Document</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Document</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Document</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-12">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Documents</h2>
                    </header>
                    <div class="card-body">
                        <div class="row justify-content-center">
                            @foreach ($datas as $data)
                                <div class="col-lg-4 mb-3">
                                    
                                    <div class="card border">
                                        <div class="card-header">
                                            <h2 class="card-title">
                                                {{-- <a href="{{ asset($data->file) }}" target="_blank">{{ $data->title }}</a> --}}
                                                <a href="" target="_blank">{{ $data->title }}</a>
                                                  <a href="{{ asset($data->file) }}" download="{{ $data->title }}" class="btn btn-primary">
        Download
    </a>
                                            </h2>
                                        </div>
                                       
                                        <div class="card-body">
                                            @php
                                                $arr = explode('.', $data->file);
                                                $ext = end($arr);
                                            @endphp
                                            @if ($ext == 'pdf')
                                                <iframe src="{{ asset($data->file) }}" frameborder="1" class="w-100"></iframe>
                                            @else
                                                <img src="{{ asset($data->file) }}" class="img-fluid w-100" alt="" style="height: 160px">
                                            @endif
                                        </div>
                                    </div>
                                       
                                </div>
                            @endforeach
                        </div>
                        {{-- <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Title</th>
                                    <th>Document</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($datas as $data)
                                    <tr class="align-middle">
                                        <td>{{ ++$loop->index }}</td>
                                        <td><b>{{ $data->title }}</b></td>
                                        <td>
                                            <iframe src="{{ asset($data->file) }}" frameborder="0" class="w-100"></iframe>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table> --}}
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')

@endsection
