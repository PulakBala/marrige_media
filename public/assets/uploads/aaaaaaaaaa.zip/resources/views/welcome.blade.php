@extends('layouts.app')
@section('content')
    <!-- ***** Welcome Area Start ***** -->
    <div class="welcome-area" id="welcome">
        <!-- ***** Header Text Start ***** -->
        <div class="header-text">
            <div class="container">
                <div class="row">
                    <div class="offset-xl-3 col-xl-6 offset-lg-2 col-lg-8 col-md-12 col-sm-12">
                        <h1 class="font-family-for-bengoli">{{ $welcome->heading }}</h1>
                        {{-- <h3>আমাদের সাথে আপনার ব্যবসা বৃদ্ধি করুন</h3>
                        <p>Best Micro Credit Management Software in Bangladesh.</p> --}}
                        <a href="{{ $welcome->link }}" class="main-button-slider">Discover More</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- ***** Header Text End ***** -->
    </div>
    <!-- ***** Welcome Area End ***** -->

    <!-- ***** Features Small Start ***** -->
    <section class="section home-feature">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        @foreach ($featureds as $featured)
                            <!-- ***** Features Small Item Start ***** -->
                            <div class="col-lg-4 col-md-6 col-sm-6 col-12"
                                data-scroll-reveal="enter bottom move 50px over 0.6s after 0.2s">
                                <div class="features-small-item">
                                    <div class="icon">
                                        <i><img src="{{ asset('public/' . $featured->icon) }}" alt="" class="img-fluid" width="40"></i>
                                    </div>
                                    <h5 class="features-title font-family-for-bengoli">{{ $featured->title }}</h5>
                                    <!--    <p>Customize anything in this template to fit your website needs</p> -->
                                </div>
                            </div>
                            <!-- ***** Features Small Item End ***** -->
                        @endforeach

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Features Small End ***** -->

    <!-- ***** Features Big Item Start ***** -->
    <section class="section padding-top-70 padding-bottom-0" id="features">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-sm-12 align-self-center"
                    data-scroll-reveal="enter left move 30px over 0.6s after 0.4s">
                    <img src="{{ asset('public/' . $about->image) }}" class="rounded img-fluid d-block mx-auto" alt="App">
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-6 col-md-12 col-sm-12 align-self-center mobile-top-fix">
                    <div class="left-heading">
                        <h2 class="section-title font-family-for-bengoli">{{ $about->heading }}</h2>
                    </div>
                    <div class="left-text">
                        <p class="font-family-for-bengoli">{{ $about->description }}</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="hr"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Features Big Item End ***** -->


    <!-- ***** Home Parallax Start ***** -->
    <section class="mini" id="work-process">
        <div class="mini-content">
            <div class="container">
                <div class="row">
                    <div class="offset-lg-3 col-lg-6">
                        <div class="info">
                            <h1 class="font-family-for-bengoli">কার্য পদ্ধতি</h1>
                            <p class="font-family-for-bengoli">অবসরের কার্য পদ্বতি হলো সকল পার্টনারের পরামর্শ ক্রমে যে কোন কাজ সম্পন্ন করা
                                </p>
                        </div>
                    </div>
                </div>

                <!-- ***** Mini Box Start ***** -->
                <div class="row">
                    @foreach ($works as $work)
                        <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                            <a href="#" class="mini-box">
                                <i><img src="{{ asset('public/' .$work->icon) }}" alt="{{ $work->title }}"></i>
                                <strong class="font-family-for-bengoli">{{ $work->title }}</strong>
                                <span>{{ $work->short_description }}</span>
                            </a>
                        </div>
                    @endforeach
                </div>
                <!-- ***** Mini Box End ***** -->
            </div>
        </div>
    </section>
    <!-- ***** Home Parallax End ***** -->

    <!-- ***** Home Parallax Start ***** -->
    @if (count($teams) > 0)
        <section class="" id="team">
            <div class="mini-content">
                <div class="container">
                    <div class="py-5 team4">
                        <div class="container">
                            <div class="row justify-content-center mb-4">
                                <div class="col-md-7 text-center">
                                    <h3 class="mb-3">Experienced & Professional Team</h3>
                                </div>
                            </div>
                            <div class="row">
                                @foreach ($teams as $team)
                                    <!-- column  -->
                                    <div class="col-lg-3 mb-4">
                                        <!-- Row -->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <img src="{{ asset('public/' . $team->image) }}" alt="{{ $team->name }}" class="img-fluid rounded-circle" style="width: 245px; height:245px;"/>
                                            </div>
                                            <div class="col-md-12 text-center">
                                                <div class="pt-2">
                                                    <h5 class="mt-4 font-weight-medium mb-0">{{ $team->name }}</h5>
                                                    <h6 class="subtitle mb-3">{{ $team->title }}</h6>
                                                    <ul class="list-inline">
                                                        @if ($team->fb_link)
                                                            <li class="list-inline-item"><a href="{{ $team->fb_link }}" class="text-decoration-none d-block px-1"><i class="fa fa-facebook"></i></a></li>
                                                        @endif
                                                        @if ($team->tw_link)
                                                            <li class="list-inline-item"><a href="{{ $team->tw_link }}" class="text-decoration-none d-block px-1"><i class="fa fa-twitter"></i></a></li>
                                                        @endif
                                                        @if ($team->ins_link)
                                                            <li class="list-inline-item"><a href="{{ $team->ins_link }}" class="text-decoration-none d-block px-1"><i class="fa fa-instagram"></i></a></li>
                                                        @endif
                                                        {{-- <li class="list-inline-item"><a href="#" class="text-decoration-none d-block px-1"><i class="fa fa-behance"></i></a></li> --}}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Row -->
                                    </div>
                                    <!-- column  -->
                                @endforeach


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    @endif
@endsection




