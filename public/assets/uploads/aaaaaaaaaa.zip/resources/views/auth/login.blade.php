@extends('auth.layouts.auth_app')

@section('title')
    <title>LOGIN -</title>
@endsection
@section('authform')

    <div class="card-title-sign mt-3 w-100">
        <h2 class="title text-uppercase font-weight-bold m-0"><i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Sign In</h2>
    </div>
    <div class="card-body">

    {{ config('app.google') }}
        <form action="{{ route('login') }}" method="post">
            @csrf
            <div class="form-group mb-3">
                <label>Email</label>
                <div class="input-group">
                    <input name="email" type="text" class="form-control form-control-lg" value="{{ old('email') }}" placeholder="Enter email"/>
                    <span class="input-group-text">
                        <i class="bx bx-user text-4"></i>
                    </span>
                </div>
                <span class="text-danger">
                    @error('email')
                    {{ $message }}
                    @enderror
                </span>
            </div>

            <div class="form-group mb-3">
                <div class="clearfix">
                    <label class="float-left">Password</label>
                    <a href="{{ route('password.request') }}" class="float-end">Lost Password?</a>
                </div>
                <div class="input-group">
                    <input name="password" type="password" class="form-control form-control-lg" placeholder="Enter password"/>
                    <span class="input-group-text">
                        <i class="bx bx-lock text-4"></i>
                    </span>
                </div>
                <span class="text-danger">
                    @error('password')
                    {{ $message }}
                    @enderror
                </span>
            </div>

            <div class="row">
                <div class="col-sm-8">
                    <div class="checkbox-custom checkbox-default">
                        <input id="remember" name="remember" type="checkbox" {{ old('remember') ? 'checked' : '' }}/>
                        <label for="remember">Remember Me</label>
                    </div>
                </div>
                <div class="col-sm-4 text-end">
                    <button type="submit" class="btn btn-primary mt-2">Sign In</button>
                </div>
            </div>

            @if (setting('facebook') == 1 || setting('google') == 1 ||  setting('twitter') == 1 || setting('linkedin') == 1)
                <span class="mt-3 mb-3 line-thru text-center text-uppercase">
                    <span>or</span>
                </span>
            @endif
            <div class="mb-1 text-center">
                @if (setting('facebook') == 1)
                    <!-- Facebook -->
                    <a class="btn btn-primary border-0" style="background-color: #3b5998;" href="{{ route('facebook.redirect') }}" role="button"><i class="fab fa-facebook-f"></i></a>
                @endif

                @if (setting('google') == 1)
                    <!-- Google -->
                    <a class="btn btn-primary border-0" style="background-color: #dd4b39;" href="{{ route('google.redirect') }}" role="button"><i class="fab fa-google"></i></a>
                @endif

                @if (setting('twitter') == 1)
                    <!-- Twitter -->
                    <a class="btn btn-primary border-0" style="background-color: #55acee;" href="{{ route('twitter.redirect') }}" role="button"><i class="fab fa-twitter"></i></a>
                @endif

                @if (setting('linkedin') == 1)
                    <!-- Linkedin -->
                    <a class="btn btn-primary border-0" style="background-color: #0082ca;" href="{{ route('linkedin.redirect') }}" role="button"><i class="fab fa-linkedin-in"></i></a>
                @endif
            </div>

            <p class="text-center">Don't have an account yet? <a href="{{ route('register') }}">Sign Up!</a></p>

        </form>
    </div>

@endsection
