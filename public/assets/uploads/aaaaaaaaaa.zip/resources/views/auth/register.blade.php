@extends('auth.layouts.auth_app')

@section('title')
    <title>REGISTER -</title>

    <style>
        /* Style all input fields */


        /* Style the submit button */
        input[type=submit] {
          background-color: #04AA6D;
          color: white;
        }



        /* The message box is shown when the user clicks on the password field */
        #message {
          display:none;
          color: #000;
          position: relative;
        }

        #message p {
          padding: 2px 10px;
          font-size: 12px;
        }

        /* Add a green text color and a checkmark when the requirements are right */
        .valid {
          color: green;
          display: none;
        }

        .valid:before {
          position: relative;
          left: -5px;
          content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
          color: red;
        }

        .invalid:before {
          position: relative;
          left: -5px;
          content: "✖";
        }

    </style>
@endsection
@section('authform')
<div class="card-title-sign mt-3 text-end">
    <h2 class="title text-uppercase font-weight-bold m-0">
        <i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Sign Up
    </h2>
</div>
<div class="card-body">
    <form action="{{ route('register') }}" method="POST">
        @csrf
        <div class="form-group mb-3">
            <label>Name</label>
            <input name="name" type="text" class="form-control form-control-lg @error('name') is-invalid @enderror" value="{{ old('name') }}" placeholder="Enter name"/>
            <span class="text-danger">
                @error('name')
                    {{ $message }}
                @enderror
            </span>
        </div>

        <div class="form-group mb-3">
            <label>E-mail Address</label>
            <input name="email" type="email" class="form-control form-control-lg @error('email') is-invalid @enderror" value="{{ old('email') }}" placeholder="Enter Email"/>
            <span class="text-danger">
                @error('email')
                    {{ $message }}
                @enderror
            </span>
        </div>

        <div class="form-group mb-0">
            <div class="row">
                <div class="col-sm-6 mb-3">
                    <label>Password</label>
                    <input name="password" type="password" class="form-control form-control-lg @error('password') is-invalid @enderror" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" id="psw" placeholder="Enter password"/>
                </div>
                <div class="col-sm-6 mb-3">
                    <label>Password Confirmation</label>
                    <input name="password_confirmation" type="password" class="form-control form-control-lg @error('password') is-invalid @enderror" placeholder="Re-type password"/>
                    <span class="text-danger">
                        @error('password_confirmation')
                            {{ $message }}
                        @enderror
                    </span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 text-center">
                    <span class="text-danger">
                        @error('password')
                            {{ $message }}
                        @enderror
                    </span>
                </div>


                <div id="message">
                    <p id="letter" class="invalid my-0 py-0">A <b>lowercase</b> letter</p>
                    <p id="capital" class="invalid my-0 py-0">A <b>capital (uppercase)</b> letter</p>
                    <p id="number" class="invalid my-0 py-0">A <b>number</b></p>
                    <p id="length" class="invalid my-0 py-0">Minimum <b>8 characters</b></p>
                  </div>
            </div>
        </div>

        <div class="row">
            <div class="">
                <button type="submit" id="submit" class="btn btn-primary mt-2">Sign Up</button>
            </div>
        </div>
        @if (setting('facebook') == 1 || setting('google') == 1 ||  setting('twitter') == 1 || setting('linkedin') == 1)
            <span class="mt-3 mb-3 line-thru text-center text-uppercase">
                <span>or</span>
            </span>
        @endif
        <div class="mb-1 text-center">
            @if (setting('facebook') == 1)
                <!-- Facebook -->
                <a class="btn btn-primary border-0" style="background-color: #3b5998;" href="{{ route('facebook.redirect') }}" role="button"><i class="fab fa-facebook-f"></i></a>
            @endif

            @if (setting('google') == 1)
                <!-- Google -->
                <a class="btn btn-primary border-0" style="background-color: #dd4b39;" href="{{ route('google.redirect') }}" role="button"><i class="fab fa-google"></i></a>
            @endif

            @if (setting('twitter') == 1)
                <!-- Twitter -->
                <a class="btn btn-primary border-0" style="background-color: #55acee;" href="{{ route('twitter.redirect') }}" role="button"><i class="fab fa-twitter"></i></a>
            @endif

            @if (setting('linkedin') == 1)
                <!-- Linkedin -->
                <a class="btn btn-primary border-0" style="background-color: #0082ca;" href="{{ route('linkedin.redirect') }}" role="button"><i class="fab fa-linkedin-in"></i></a>
            @endif
        </div>
        <p class="text-center">Already have an account? <a href="{{ route('login') }}">Sign In!</a></p>

    </form>
</div>
@endsection
@section('scripts')
<script>
    var myInput = document.getElementById("psw");
    var letter = document.getElementById("letter");
    var capital = document.getElementById("capital");
    var number = document.getElementById("number");
    var length = document.getElementById("length");

    // When the user clicks on the password field, show the message box
    myInput.onfocus = function() {
      document.getElementById("message").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    myInput.onblur = function() {
      document.getElementById("message").style.display = "none";
    }

    // When the user starts to type something inside the password field
    myInput.onkeyup = function() {
      // Validate lowercase letters
      var lowerCaseLetters = /[a-z]/g;
      if(myInput.value.match(lowerCaseLetters)) {
        letter.classList.remove("invalid");
        letter.classList.add("valid");

      } else {
        letter.classList.remove("valid");
        letter.classList.add("invalid");
      }

      // Validate capital letters
      var upperCaseLetters = /[A-Z]/g;
      if(myInput.value.match(upperCaseLetters)) {
        capital.classList.remove("invalid");
        capital.classList.add("valid");
      } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
      }

      // Validate numbers
      var numbers = /[0-9]/g;
      if(myInput.value.match(numbers)) {
        number.classList.remove("invalid");
        number.classList.add("valid");
      } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
      }

      // Validate length
      if(myInput.value.length >= 8) {
        length.classList.remove("invalid");
        length.classList.add("valid");
      } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
      }
    }
    </script>
@endsection








{{-- <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/font-awesome/css/all.min.css" />
    <title>REGISTER-</title>
    <style>
        body{
            background-image: linear-gradient(to bottom, rgba(142,97,231, 0.32), rgba(117, 19, 93, 0.73));
        }
    </style>
    <style>


        /* Style the submit button */
        input[type=submit] {
          background-color: #04AA6D;
          color: white;
        }



        /* The message box is shown when the user clicks on the password field */
        #message {
          display:none;
          color: #000;
          position: relative;
        }

        #message p {
          padding: 2px 10px;
          font-size: 12px;
        }

        /* Add a green text color and a checkmark when the requirements are right */
        .valid {
          color: green;
          display: none;
        }

        .valid:before {
          position: relative;
          left: -5px;
          content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
          color: red;
        }

        .invalid:before {
          position: relative;
          left: -5px;
          content: "✖";
        }
        </style>
  </head>
  <body>
    <div class="container-fluid">
        <div class="container">
            <br><br>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="card">
                        <div class="card-header">
                            <h4>Register</h4>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('register') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group row">
                                    <div class="col-lg-6 mb-3">
                                        <label for="name">Name <span class="text-danger">*</span></label>
                                        <input type="text" id="name" placeholder="Enter Name" name="name" class="form-control">
                                        @error('name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="email">Email <span class="text-danger">*</span></label>
                                        <input type="email" id="email" placeholder="Enter email" name="email" class="form-control">
                                        @error('email')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="father_name">Father/Husbend Name <span class="text-danger">*</span></label>
                                        <input type="text" id="father_name" placeholder="Enter father name" name="father_name" class="form-control">
                                        @error('father_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="mother_name">Mother's Name <span class="text-danger">*</span></label>
                                        <input type="text" id="mother_name" placeholder="Enter mother name" name="mother_name" class="form-control">
                                        @error('mother_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="phone_number">Phone Number <span class="text-danger">*</span></label>
                                        <input type="number" id="phone_number" placeholder="Enter phone number" name="phone_number" class="form-control">
                                        @error('phone_number')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="education_qualification">Education Qualification <span class="text-danger">*</span></label>
                                        <input type="text" id="education_qualification" placeholder="Enter education qualification" name="education_qualification" class="form-control">
                                        @error('education_qualification')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="passport_or_nid_number">Passport/NID no <span class="text-danger">*</span></label>
                                        <input type="number" id="passport_or_nid_number" placeholder="Enter passport or nid no" name="passport_or_nid_number" class="form-control">
                                        @error('passport_or_nid_number')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="religion">Religion <span class="text-danger">*</span></label>
                                        <input type="text" id="religion" placeholder="Enter religion" name="religion" class="form-control">
                                        @error('religion')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="date_of_birth">Date Of Birth <span class="text-danger">*</span></label>
                                        <input type="date" id="date_of_birth" placeholder="Enter date of birth" name="date_of_birth" class="form-control">
                                        @error('date_of_birth')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="nationality">Nationality <span class="text-danger">*</span></label>
                                        <input type="text" id="nationality" placeholder="Enter nationality" name="nationality" class="form-control">
                                        @error('nationality')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="blood_group">Blood Group <span class="text-danger">*</span></label>
                                        <input type="text" id="blood_group" placeholder="Enter blood group" name="blood_group" class="form-control">
                                        @error('blood_group')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="occupation">Occupation <span class="text-danger">*</span></label>
                                        <input type="text" id="occupation" placeholder="Enter occupation" name="occupation" class="form-control">
                                        @error('occupation')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-12">
                                        <h4>Address</h4>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label for="village">Village <span class="text-danger">*</span></label>
                                        <input type="text" id="village" placeholder="Enter village" name="village" class="form-control">
                                        @error('village')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label for="word_no">Word No <span class="text-danger">*</span></label>
                                        <input type="number" id="word_no" placeholder="Enter word no" name="word_no" class="form-control">
                                        @error('word_no')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label for="post_office">Post Office <span class="text-danger">*</span></label>
                                        <input type="text" id="post_office" placeholder="Enter post office" name="post_office" class="form-control">
                                        @error('post_office')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label for="thana">Thana <span class="text-danger">*</span></label>
                                        <input type="text" id="thana" placeholder="Enter thana" name="thana" class="form-control">
                                        @error('thana')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label for="upzilla">Upzilla <span class="text-danger">*</span></label>
                                        <input type="text" id="upzilla" placeholder="Enter upzilla" name="upzilla" class="form-control">
                                        @error('upzilla')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label for="district">District <span class="text-danger">*</span></label>
                                        <input type="text" id="district" placeholder="Enter district" name="district" class="form-control">
                                        @error('district')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="password">Password <span class="text-danger">*</span></label>
                                        <input type="password" id="password" placeholder="Enter password" name="password" class="form-control">
                                        @error('password')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        <div id="message">
                                            <p id="letter" class="invalid my-0 py-0">A <b>lowercase</b> letter</p>
                                            <p id="capital" class="invalid my-0 py-0">A <b>capital (uppercase)</b> letter</p>
                                            <p id="number" class="invalid my-0 py-0">A <b>number</b></p>
                                            <p id="length" class="invalid my-0 py-0">Minimum <b>8 characters</b></p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for="confirmation_password">Re-type confirmation_password <span class="text-danger">*</span></label>
                                        <input type="password" id="confirmation_password" placeholder="Enter confirmation password" name="confirmation_password" class="form-control">
                                        @error('confirmation_password')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-12">
                                        <button class="btn btn-primary" type="submit" id="submit">Sign Up</button>
                                        @if (setting('facebook') == 1 || setting('google') == 1 ||  setting('twitter') == 1 || setting('linkedin') == 1)
                                        <br><span class="mt-3 mb-3 line-thru text-center text-uppercase">
                                                <span>or</span>
                                            </span><br>
                                        @endif
                                        <div class="mb-1 text-center">
                                            @if (setting('facebook') == 1)
                                                <!-- Facebook -->
                                                <a class="btn btn-primary border-0" style="background-color: #3b5998;" href="{{ route('facebook.redirect') }}" role="button"><i class="fab fa-facebook-f"></i></a>
                                            @endif

                                            @if (setting('google') == 1)
                                                <!-- Google -->
                                                <a class="btn btn-primary border-0" style="background-color: #dd4b39;" href="{{ route('google.redirect') }}" role="button"><i class="fab fa-google"></i></a>
                                            @endif

                                            @if (setting('twitter') == 1)
                                                <!-- Twitter -->
                                                <a class="btn btn-primary border-0" style="background-color: #55acee;" href="{{ route('twitter.redirect') }}" role="button"><i class="fab fa-twitter"></i></a>
                                            @endif

                                            @if (setting('linkedin') == 1)
                                                <!-- Linkedin -->
                                                <a class="btn btn-primary border-0" style="background-color: #0082ca;" href="{{ route('linkedin.redirect') }}" role="button"><i class="fab fa-linkedin-in"></i></a>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <p class="mb-0">Already have an account <a href="{{ route('login') }}">Sign in</a></p>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <br><br>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <script>
        var myInput = document.getElementById("psw");
        var letter = document.getElementById("letter");
        var capital = document.getElementById("capital");
        var number = document.getElementById("number");
        var length = document.getElementById("length");

        // When the user clicks on the password field, show the message box
        myInput.onfocus = function() {
          document.getElementById("message").style.display = "block";
        }

        // When the user clicks outside of the password field, hide the message box
        myInput.onblur = function() {
          document.getElementById("message").style.display = "none";
        }

        // When the user starts to type something inside the password field
        myInput.onkeyup = function() {
          // Validate lowercase letters
          var lowerCaseLetters = /[a-z]/g;
          if(myInput.value.match(lowerCaseLetters)) {
            letter.classList.remove("invalid");
            letter.classList.add("valid");

          } else {
            letter.classList.remove("valid");
            letter.classList.add("invalid");
          }

          // Validate capital letters
          var upperCaseLetters = /[A-Z]/g;
          if(myInput.value.match(upperCaseLetters)) {
            capital.classList.remove("invalid");
            capital.classList.add("valid");
          } else {
            capital.classList.remove("valid");
            capital.classList.add("invalid");
          }

          // Validate numbers
          var numbers = /[0-9]/g;
          if(myInput.value.match(numbers)) {
            number.classList.remove("invalid");
            number.classList.add("valid");
          } else {
            number.classList.remove("valid");
            number.classList.add("invalid");
          }

          // Validate length
          if(myInput.value.length >= 8) {
            length.classList.remove("invalid");
            length.classList.add("valid");
          } else {
            length.classList.remove("valid");
            length.classList.add("invalid");
          }
        }
        </script>
  </body>
</html> --}}
