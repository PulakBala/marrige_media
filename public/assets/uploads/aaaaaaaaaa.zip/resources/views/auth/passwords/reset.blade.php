@extends('auth.layouts.auth_app')

@section('title')
    <title>RESET PASSWORD -</title>
@endsection
@section('authform')
    <div class="card-title-sign mt-3 text-end">
        <h2 class="title text-uppercase font-weight-bold m-0"><i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Reset</h2>
    </div>
    <div class="card-body">
        <form action="{{ route('password.update') }}" method="POST">
            @csrf
            <input type="hidden" name="token" value="{{ $token }}">
            <div class="form-group mb-3">
                <label>E-mail Address</label>
                <input name="email" type="email" class="form-control form-control-lg" value="{{ $email ?? old('email') }}"/>
                <span class="text-danger">
                    @error('email')
                        {{ $message }}
                    @enderror
                </span>
            </div>

            <div class="form-group mb-3">
                <label>Password</label>
                <input name="password" type="password" class="form-control form-control-lg"/>
                <span class="text-danger">
                    @error('password')
                        {{ $message }}
                    @enderror
                </span>
            </div>

            <div class="form-group mb-3">
                <label>Confirm Password</label>
                <input name="password_confirmation" type="password" class="form-control form-control-lg" />
                <span class="text-danger">
                    @error('password_confirmation')
                        {{ $message }}
                    @enderror
                </span>
            </div>
            <div class="col-sm-5 text-right">
                <button type="submit" class="btn btn-primary mt-2">Reset Password</button>
            </div>
            <p class="text-center mt-3">Remembered? <a href="{{ route('login') }}">Sign In!</a></p>
        </form>
    </div>

@endsection
