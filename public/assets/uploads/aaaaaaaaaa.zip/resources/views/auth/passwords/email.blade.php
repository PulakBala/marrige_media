
@extends('auth.layouts.auth_app')

@section('title')
<title>RESET EMAIL -</title>
@endsection
@section('authform')
<div class="card-title-sign mt-3 text-end">
    <h2 class="title text-uppercase font-weight-bold m-0"><i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Reset</h2>
</div>
<div class="card-body">
    <div class="alert alert-info">
        @if (session('status'))
            <p class="m-0">{{ session('status') }}</p>
            @else
            <p class="m-0">Enter your e-mail below and we will send you reset instructions!</p>
        @endif
    </div>

    <form action="{{ route('password.email') }}" method="POST">
        @csrf
        <div class="form-group mb-0">
            <div class="input-group">
                <input name="email" type="text" placeholder="E-mail" class="form-control form-control-lg @error('email') is-invalid @enderror">
                <button class="btn btn-primary btn-lg" type="submit">Reset!</button>
            </div>
            @error('email')
                <span class="text-danger">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>

        <p class="text-center mt-3">Remembered? <a href="{{ route('login') }}">Sign In!</a></p>
    </form>
</div>

@endsection
