<x-mail::message>
 <div style="text-align: center; padding: 4px; margin: 8px 0; background-color:#ddd; border-radius: 4px; display:flex; justify-content:center; align-items:center;">
        <img src="{{ asset('admin/logo-circle.jpg') }}" alt="Abosor Logo" style="width: 80px; height:80px; display: inline-block;">
    </div>

# Dear {{ $name }},

We are pleased to inform you that an amount of Tk. {{ $amount }}/- has been credited to your account.
<br>
Your Closing Balance is TK. {{ $amount }}
Month : {{$month}}
Total Blance Tk. {{$updated_total_fund}}

## Thank you for being a valued Partner  of Abosor.


Sincerely,<br>
Team Abosor
</x-mail::message>
