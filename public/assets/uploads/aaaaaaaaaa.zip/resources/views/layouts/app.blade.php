@include('partials.header')
@include('partials.navbar')
@yield('content')
@include('partials.footer')
