@extends('layouts.app')
@section('content')
<br><br><br><br>
    <section class="" id="team">
        <div class="mini-content">
            <div class="container">
                <div class="py-5 team4">
                    <div class="container">
                        <div class="row justify-content-center mb-4">
                            <div class="col-md-7 text-center">
                                <h3 class="mb-3">{{ $data->title }}</h3>
                            </div>
                        </div>
                        <div class="row">
                            {!! $data->content !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection




