<!-- ***** Header Area Start ***** -->
<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="{{ route('frontend.index') }}" class="logo">
                        <img src="{{ asset('public/' . setting('logo')) }}" alt="{{ asset(setting('name')) }}" style="width: 147px; height:63px;"/>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        <li><a href="{{ route('frontend.index') }}" class="active">Home</a></li>
                        <li><a href="#features">About</a></li>
                        <li><a href="#work-process">Work Process</a></li>
                        <li><a href="#team">Team</a></li>
                        {{-- <li><a href="#gellary">Gellary</a></li> --}}
                        @auth
                            @if (auth()->user()->role == 'user')
                                <li><a href="{{ route('user.dashboard') }}">Dashboard</a></li>
                            @else
                                <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                            @endif
                            <li><a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></li>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        @else
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <li><a href="{{ route('register') }}">Register</a></li>
                        @endauth
                    </ul>
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- ***** Header Area End ***** -->
