<!doctype html>
<html class="fixed">
	<head>
		<!-- Basic -->
		<meta charset="UTF-8">
		@yield('title')
		<meta name="description" content="{{ setting('meta_description') }}">
        <meta name="keywords" content="{{ setting('meta_keyword') }}">
        <meta name="tags" content="{{ setting('meta_tags') }}">
		<meta name="author" content="{{ setting('author_name') }}">
        <link rel="icon" href="{{ asset(setting('favicon')) }}">
		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="{{ asset('admin') }}/vendor/bootstrap/css/bootstrap.css" />
        <link rel="stylesheet" href="{{ asset('admin') }}/vendor/font-awesome/css/all.min.css" />
        <link rel="stylesheet" href="{{ asset('admin') }}/vendor/boxicons/css/boxicons.min.css" />
        <link rel="stylesheet" href="{{ asset('admin') }}/vendor/pnotify/pnotify.custom.css" />
        <link rel="stylesheet" href="{{ asset('admin') }}/css/theme.css" />
        <link rel="stylesheet" href="{{ asset('admin') }}/css/skins/default.css" />
        <link rel="stylesheet" href="{{ asset('admin') }}/css/custom.css">
        <style>
            .active {
                background-color: transparent !important;
            }
        </style>
        @yield('styles')
	</head>
	<body class="loading-overlay-showing" data-loading-overlay>

        <div class="loading-overlay">
            <div class="bounce-loader">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>


		<section class="body">
			<!-- start: header -->
			<header class="header">
				<div class="logo-container">
					<a href="" class="logo">
                        <img class="logo" src="{{ asset('public/' . setting('logo')) }}" width="100" alt="">
					</a>

					<div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fas fa-bars" aria-label="Toggle sidebar"></i>
					</div>

				</div>

				<!-- start: search & user box -->
				<div class="header-right">



					<span class="separator"></span>

					<div id="userbox" class="userbox">
						<a href="#" data-bs-toggle="dropdown">
							<figure class="profile-picture">
								<img src="{{ asset('public/' . auth()->user()->profile) }}" alt="Joseph Doe" class="rounded-circle" data-lock-picture="img/!logged-user.jpg" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name">{{ auth()->user()->name }}</span>
								<span class="role">Administrator</span>
							</div>

							<i class="fa custom-caret"></i>
						</a>

						<div class="dropdown-menu">
							<ul class="list-unstyled mb-2">
								<li class="divider"></li>
								<li>
                                    <a role="menuitem" tabindex="-1" href="{{ route('admin.profile.index') }}"><i class="bx bx-user-circle"></i> My Profile</a>
								</li>
                                <li>
                                    <a tabindex="-1" href="{{ route('admin.setting.index') }}"><i class="fa fa-cog"></i> Settings</a>
                                </li>
								<li>
									<a role="menuitem" tabindex="-1" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="bx bx-power-off"></i> Logout</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">

				    <div class="sidebar-header">
				        <div class="sidebar-title">
				            &nbsp;
				        </div>
				        <div class="sidebar-toggle d-none d-md-block" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
				            <i class="fas fa-bars" aria-label="Toggle sidebar"></i>
				        </div>
				    </div>

				    <div class="nano">
				        <div class="nano-content">
                            @include('admins.partials.side-nav')
				        </div>

				        <script>
				            // Maintain Scroll Position
				            if (typeof localStorage !== 'undefined') {
				                if (localStorage.getItem('sidebar-left-position') !== null) {
				                    var initialPosition = localStorage.getItem('sidebar-left-position'),
				                        sidebarLeft = document.querySelector('#sidebar-left .nano-content');

				                    sidebarLeft.scrollTop = initialPosition;
				                }
				            }
				        </script>
				    </div>
				</aside>
				<!-- end: sidebar -->
                @yield('content')
			</div>
		</section>

        <script src="{{ asset('admin') }}/vendor/jquery/jquery.js"></script>
		<script src="{{ asset('admin') }}vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
        <script src="{{ asset('admin') }}/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="{{ asset('admin') }}/vendor/common/common.js"></script>
        <script src="{{ asset('admin') }}/vendor/pnotify/pnotify.custom.js"></script>
        <script src="{{ asset('admin') }}/js/theme.js"></script>
        <script src="{{ asset('admin') }}/js/examples/examples.notifications.js"></script>
        <script src="{{ asset('admin') }}/vendor/modernizr/modernizr.js"></script>

        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

        </script>

        @if (session('success'))
            <script>
                new PNotify({
                    title: 'Success',
                    text: '{{ session("success") }}',
                    type: 'success',
                    addclass: 'notification-success',
                    icon: 'fas fa-check'
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                new PNotify({
                    title: 'Error',
                    text: '{{ session("error") }}',
                    type: 'Error',
                    addclass: 'notification-danger',
                    icon: 'fas fa-times'
                });
            </script>
        @endif
        @yield('scripts')
	</body>
</html>
