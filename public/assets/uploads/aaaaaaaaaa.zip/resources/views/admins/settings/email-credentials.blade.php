@extends('admins.layouts.app_admin')
@section('title')
    <title>Settings</title>
@endsection

@section('styles')
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                @include('admins.partials.setting-nav')
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">
                                <div class="active">
                                    <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.setting.email.update') }}">
                                        @csrf
                                        <input type="hidden" value="mail_transport" name="credentials[]">
                                        <input type="hidden" value="mail_host" name="credentials[]">
                                        <input type="hidden" value="mail_port" name="credentials[]">
                                        <input type="hidden" value="mail_username" name="credentials[]">
                                        <input type="hidden" value="mail_password" name="credentials[]">
                                        <input type="hidden" value="mail_encryption" name="credentials[]">
                                        <input type="hidden" value="mail_from" name="credentials[]">
                                        <input type="hidden" value="mail_from_name" name="credentials[]">
                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_transport">Mail Transport</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_transport" name="mail_transport" title="Enter mail transport" value="{{ setting('mail_transport') }}">
                                                <span class="text-danger">
                                                    @error('mail_transport')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_host">Mail Host</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_host" name="mail_host" title="Enter mail host" value="{{ setting('mail_host') }}">
                                                <span class="text-danger">
                                                    @error('mail_host')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>


                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_port">Mail Port</label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" id="mail_port" name="mail_port" title="Enter mail port" value="{{ setting('mail_port') }}">
                                                <span class="text-danger">
                                                    @error('mail_port')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_username">Mail Username</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_username" name="mail_username" title="Enter mail username" value="{{ setting('mail_username') }}">
                                                <span class="text-danger">
                                                    @error('mail_username')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>


                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_password">Mail Password</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_password" name="mail_password" title="Enter mail username" value="{{ setting('mail_password') }}">
                                                <span class="text-danger">
                                                    @error('mail_password')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_encryption">Mail Encryption</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_encryption" name="mail_encryption" title="Enter mail username" value="{{ setting('mail_encryption') }}">
                                                <span class="text-danger">
                                                    @error('mail_encryption')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_from">Mail From</label>
                                            <div class="col-lg-6">
                                                <input type="email" class="form-control" id="mail_from" name="mail_from" title="Enter mail username" value="{{ setting('mail_from') }}">
                                                <span class="text-danger">
                                                    @error('mail_from')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="mail_from_name">Mail From Name</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="mail_from_name" name="mail_from_name" title="Enter mail username" value="{{ setting('mail_from_name') }}">
                                                <span class="text-danger">
                                                    @error('mail_from_name')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-group row pb-4">
                                            <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" class="btn btn-success">Save and Update</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
@endsection
