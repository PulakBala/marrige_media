@extends('admins.layouts.app_admin')
@section('title')
    <title>Settings</title>
@endsection

@section('styles')
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                    <li><span>Socialite</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                @include('admins.partials.setting-nav')
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">

                                <section class="card">
                                    <header class="card-header d-flex justify-content-between">
                                            <h2 class="card-title">Google Login Crediancial </h2>
                                        <div class="switch switch-primary ">
                                            <input type="checkbox" onchange="updateGoogle(this)" name="switch" data-plugin-ios-switch value="google" {{ setting('google') == 1 ? 'checked' : ''}}/>
                                        </div>
                                    </header>
                                    <div class="card-body">
                                        <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.google.credentials') }}">
                                            <input type="hidden" value="google_client_id" name="googleCredentials[]">
                                            <input type="hidden" value="google_client_secret" name="googleCredentials[]">
                                            <div class="form-group row pb-4">
                                                @csrf
                                                <label class="" for="google_client_id">Client Id</label>
                                                <div class="">
                                                    <input type="text" class="form-control" id="google_client_id" name="google_client_id" placeholder="Enter client id" value="{{ setting('google_client_id') }}">
                                                    <span class="text-danger">
                                                        @error('google_client_id')
                                                            {{ $message }}
                                                        @enderror
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="form-group row pb-4">
                                                @csrf
                                                <label class="" for="google_client_secret">Client Secret</label>
                                                <div class="">
                                                    <input type="text" class="form-control" id="google_client_secret" name="google_client_secret" placeholder="Enter client id" value="{{ setting('google_client_secret') }}">
                                                    <span class="text-danger">
                                                        @error('google_client_secret')
                                                            {{ $message }}
                                                        @enderror
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="form-group row pb-4">
                                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                                <div class="col-lg-6">
                                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </section>


                                <section class="card">
                                    <header class="card-header d-flex justify-content-between">
                                        <h2 class="card-title">Facebook Login Crediancial </h2>
                                        <div class="switch switch-primary ">
                                            <input type="checkbox" onchange="updateFacebook(this)" name="switch" data-plugin-ios-switch value="facebook" {{ setting('facebook') == 1 ? 'checked' : ''}}/>
                                        </div>
                                    </header>
                                    <div class="card-body">
                                        <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.facebook.credentials') }}" >
                                            <input type="hidden" value="facebook_app_id" name="facebookCredentials[]">
                                            <input type="hidden" value="facebook_client_secret" name="facebookCredentials[]">
                                            <div class="form-group row pb-4">
                                                @csrf
                                                <label class="" for="facebook_app_id">App Id</label>
                                                <div class="">
                                                    <input type="text" class="form-control" id="facebook_app_id" name="facebook_app_id" placeholder="Enter app id" value="{{ setting('facebook_app_id') }}">
                                                    <span class="text-danger">
                                                        @error('facebook_app_id')
                                                            {{ $message }}
                                                        @enderror
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="form-group row pb-4">
                                                @csrf
                                                <label class="" for="facebook_client_secret">Client Secret</label>
                                                <div class="">
                                                    <input type="text" class="form-control" id="facebook_client_secret" name="facebook_client_secret" placeholder="Enter client secret" value="{{ setting('facebook_client_secret') }}">
                                                    <span class="text-danger">
                                                        @error('facebook_client_secret')
                                                            {{ $message }}
                                                        @enderror
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="form-group row pb-4">
                                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                                <div class="col-lg-6">
                                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </section>

                                <section class="card">
                                    <header class="card-header d-flex justify-content-between">
                                        <h2 class="card-title">Twitter Login Crediancial </h2>
                                        <div class="switch switch-primary ">
                                            <input type="checkbox" onchange="updateTwitter(this)" name="switch" data-plugin-ios-switch value="twitter" {{ setting('twitter') == 1 ? 'checked' : ''}}/>
                                        </div>
                                    </header>
                                    <div class="card-body">
                                        <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.twitter.credentials') }}">
                                            <input type="hidden" value="twitter_client_id" name="twitterCredentials[]">
                                            <input type="hidden" value="twitter_client_secret" name="twitterCredentials[]">
                                            <div class="form-group row pb-4">
                                                @csrf
                                                <label class="" for="twitter_client_id">Client Id</label>
                                                <div class="">
                                                    <input type="text" class="form-control" id="twitter_client_id" name="twitter_client_id" placeholder="Enter client id" value="{{ setting('twitter_client_id') }}">
                                                    <span class="text-danger">
                                                        @error('twitter_client_id')
                                                            {{ $message }}
                                                        @enderror
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="form-group row pb-4">
                                                @csrf
                                                <label class="" for="twitter_client_secret">Client Secret</label>
                                                <div class="">
                                                    <input type="text" class="form-control" id="twitter_client_secret" name="twitter_client_secret" placeholder="Enter client id" value="{{ setting('twitter_client_secret') }}">
                                                    <span class="text-danger">
                                                        @error('twitter_client_secret')
                                                            {{ $message }}
                                                        @enderror
                                                    </span>
                                                </div>
                                            </div>

                                            <div class="form-group row pb-4">
                                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                                <div class="col-lg-6">
                                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </section>

                                <section class="card">
                                    <header class="card-header d-flex justify-content-between">
                                        <h2 class="card-title">Linkedin Login Crediancial </h2>
                                        <div class="switch switch-primary ">
                                            <input type="checkbox" onchange="updateLinkedin(this)" name="switch" data-plugin-ios-switch value="linkedin" {{ setting('linkedin') == 1 ? 'checked' : ''}}/>
                                        </div>
                                    </header>
                                    <div class="card-body">
                                            <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.linkedin.credentials') }}">
                                                <input type="hidden" value="linkedin_client_id" name="linkedinCredentials[]">
                                            <input type="hidden" value="linkedin_client_secret" name="linkedinCredentials[]">
                                                <div class="form-group row pb-4">
                                                    @csrf
                                                    <label class="" for="linkedin_client_id">Client Id</label>
                                                    <div class="">
                                                        <input type="text" class="form-control" id="linkedin_client_id" name="linkedin_client_id" placeholder="Enter client id" value="{{ setting('linkedin_client_id') }}">
                                                        <span class="text-danger">
                                                            @error('linkedin_client_id')
                                                                {{ $message }}
                                                            @enderror
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="form-group row pb-4">
                                                    @csrf
                                                    <label class="" for="linkedin_client_secret">Client Secret</label>
                                                    <div class="">
                                                        <input type="text" class="form-control" id="linkedin_client_secret" name="linkedin_client_secret" placeholder="Enter client id" value="{{ setting('linkedin_client_secret') }}">
                                                        <span class="text-danger">
                                                            @error('linkedin_client_secret')
                                                                {{ $message }}
                                                            @enderror
                                                        </span>
                                                    </div>
                                                </div>

                                                <div class="form-group row pb-4">
                                                    <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                                    <div class="col-lg-6">
                                                        <button type="submit" class="btn btn-success">Save and Update</button>
                                                    </div>
                                                </div>
                                            </form>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
<script>
    function updateGoogle(el){
        if(el.checked){
            var status = 1;
        }
        else{
            var status = 0;
        }
        $.get('{{ route('admin.update.google.switch') }}', {_token:'{{ csrf_token() }}', value:el.value, status:status}, function(data){
            if(data == 1){
                new PNotify({
                    title: 'Success!',
                    text: el.value+' login is activeted.',
                    type: 'success'
                });
            }
            else{
                $(el).prev().addClass( "off" );
                $(el).prev().removeClass( "on" );
                $(el).prop('checked', false);
                new PNotify({
                    title: 'Error!',
                    text: 'Please update the key first.',
                    type: 'danger'
                });
            }
        });
    }
    function updateFacebook(el){
        if(el.checked){
            var status = 1;
        }
        else{
            var status = 0;
        }
        $.get('{{ route('admin.update.facebook.switch') }}', {_token:'{{ csrf_token() }}', value:el.value, status:status}, function(data){
            if(data == 1){
                new PNotify({
                    title: 'Success!',
                    text: el.value+' login is activeted.',
                    type: 'success'
                });
            }
            else{
                $(el).prev().addClass( "off" );
                $(el).prev().removeClass( "on" );
                $(el).prop('checked', false);
                new PNotify({
                    title: 'Error!',
                    text: 'Please update the key first.',
                    type: 'danger'
                });
            }
        });
    }
    function updateTwitter(el){
        if(el.checked){
            var status = 1;
        }
        else{
            var status = 0;
        }
        $.get('{{ route('admin.update.twitter.switch') }}', {_token:'{{ csrf_token() }}', value:el.value, status:status}, function(data){
            if(data == 1){
                new PNotify({
                    title: 'Success!',
                    text: el.value+' login is activeted.',
                    type: 'success'
                });
            }
            else{
                $(el).prev().addClass( "off" );
                $(el).prev().removeClass( "on" );
                $(el).prop('checked', false);

                new PNotify({
                    title: 'Error!',
                    text: 'Please update the key first.',
                    type: 'danger'
                });
            }
        });
    }
    function updateLinkedin(el){
        if(el.checked){
            var status = 1;
        }
        else{
            var status = 0;
        }
        $.get('{{ route('admin.update.linkedin.switch') }}', {_token:'{{ csrf_token() }}', value:el.value, status:status}, function(data){
            if(data == 1){
                new PNotify({
                    title: 'Success!',
                    text: el.value+' login is activeted.',
                    type: 'success'
                });
            }
            else{
                $(el).prev().addClass( "off" );
                $(el).prev().removeClass( "on" );
                $(el).prop('checked', false);

                new PNotify({
                    title: 'Error!',
                    text: 'Please update the key first.',
                    type: 'danger'
                });
            }
        });
    }
</script>
@endsection
