@extends('admins.layouts.app_admin')
@section('title')
    <title>Settings</title>
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/bootstrap-multiselect/css/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

    <style>
        .bootstrap-tagsinput .badge {
            margin: 2px !important;
        }
    </style>
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                @include('admins.partials.setting-nav')
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">
                                <form action="{{ route('admin.meta.update') }}" method="POST">
                                    @csrf
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <input type="hidden" name="metas[]" value="author_name">
                                                <input type="hidden" name="metas[]" value="meta_keyword">
                                                <input type="hidden" name="metas[]" value="meta_tags">
                                                <input type="hidden" name="metas[]" value="meta_description">
                                                <div class="col-lg-4 form-group border-0">
                                                    <label for="">Meta Author</label>
                                                    <input type="text" name="author_name" placeholder="Enter Author Name" class="form-control"  value="{{ old('author_name') ? old('author_name') : setting('author_name') }}">
                                                    @error('author_name')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>

                                                <div class="col-lg-4 form-group border-0">
                                                    <label for="meta_tags">Meta Tags</label>
                                                    <input type="text" name="meta_keyword" id="meta_tags" data-role="tagsinput" placeholder="Enter Meta Tags" class="form-control" value="{{ old('meta_tags') ? old('meta_tags') : setting('meta_tags') }}">
                                                    @error('meta_tags')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>

                                                <div class="col-lg-4 form-group border-0">
                                                    <label for="meta_keywords">Meta Keywords</label>
                                                    <input type="text" name="meta_tags" id="meta_keywords" data-role="tagsinput" placeholder="Enter Meta Keywords" class="form-control" value="{{ old('meta_keyword') ? old('meta_keyword') : setting('meta_keyword') }}">
                                                    @error('meta_keyword')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>

                                                <div class="col-lg-12 form-group">
                                                    <label for="meta_description">Meta Description</label>
                                                    <textarea name="meta_description" id="meta_description" class="form-control" rows="5" placeholder="Enter Meta Description">{{ old('meta_description') ? old('meta_description') : setting('meta_description') }}</textarea>
                                                    @error('meta_description')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <div class="form-group row pb-4">
                                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                                <div class="col-lg-6">
                                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
    <script src="{{ asset('admin') }}/vendor/bootstrapv5-multiselect/js/bootstrap-multiselect.js"></script>
    <script src="{{ asset('admin') }}/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
    <script src="{{ asset('admin') }}/js/examples/examples.advanced.form.js"></script>
@endsection
