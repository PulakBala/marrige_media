@extends('admins.layouts.app_admin')
@section('title')
    <title>Settings</title>
@endsection

@section('styles')
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Setting</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Setting</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card card-modern card-big-info">
                    <div class="card-body">
                        <div class="tabs-modern row" style="min-height: 490px;">
                            <div class="col-lg-2-5 col-xl-1-5">
                                @include('admins.partials.setting-nav')
                            </div>
                            <div class="col-lg-3-5 col-xl-4-5">
                                <div class="active">
                                    <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.setting.update') }}" enctype="multipart/form-data">
                                        <div class="form-group row pb-4">
                                            @csrf
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="title">Title</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="title" name="title" title="Enter Site Title" value="{{ setting('title') }}">
                                                <span class="text-danger">
                                                    @error('title')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                        </div>


                                        <div class="form-group row pb-4">
                                            @csrf
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="logo">Logo</label>
                                            <div class="col-lg-6">
                                                <input type="file" class="form-control" id="logo" name="logo">
                                                <span class="text-danger">
                                                    @error('logo')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                            <div class="col-lg-4">
                                                <img src="{{ asset(setting('logo')) }}" alt="" class="border p-1" style="width:30%; margin-top:5px">
                                            </div>
                                        </div>
                                        <div class="form-group row pb-4">
                                            <label class="col-lg-2 control-label text-lg-end pt-2" for="favicon">Favicon</label>
                                            <div class="col-lg-6">
                                                <input type="file" class="form-control" id="favicon" name="favicon">
                                                <span class="text-danger">
                                                    @error('favicon')
                                                        {{ $message }}
                                                    @enderror
                                                </span>
                                            </div>
                                            <div class="col-lg-4">
                                                <img src="{{ asset(setting('favicon')) }}" alt="" class="border p-1" style="width:30px; margin-top:5px">
                                            </div>
                                        </div>

                                        <div class="form-group row pb-4">
                                            <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" class="btn btn-success">Save and Update</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        {{-- <h2 class="text-center">Site Meta</h2>

        <div class="row">
            <div class="col-lg-12">
                <form action="{{ route('admin.meta.update') }}" method="POST">
                    @csrf
                    <div data-collapsed="0" class="card">
                        <div class="card-header">
                            <div class="card-title">
                                <h2 class="card-title">Update Meta</h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12 form-group">
                                    <input type="hidden" name="metas[]" value="author_name">
                                    <input type="hidden" name="metas[]" value="meta_keyword">
                                    <input type="hidden" name="metas[]" value="meta_tags">
                                    <input type="hidden" name="metas[]" value="meta_description">
                                </div>
                                <div class="col-lg-4 form-group">
                                    <label for="">Meta Author</label>
                                    <input type="text" name="author_name" placeholder="Enter Author Name" class="form-control"  value="{{ old('author_name') ? old('author_name') : setting('author_name') }}">
                                    @error('author_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="col-lg-4 form-group">
                                    <label for="meta_tags">Meta Tags</label>
                                    <input type="text" name="meta_keyword" id="meta_tags" data-role="tagsinput" placeholder="Enter Meta Tags" class="form-control" value="{{ old('meta_tags') ? old('meta_tags') : setting('meta_tags') }}">
                                    @error('meta_tags')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="col-lg-4 form-group">
                                    <label for="meta_keywords">Meta Keywords</label>
                                    <input type="text" name="meta_tags" id="meta_keywords" data-role="tagsinput" placeholder="Enter Meta Keywords" class="form-control" value="{{ old('meta_keyword') ? old('meta_keyword') : setting('meta_keyword') }}">
                                    @error('meta_keyword')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="col-lg-12 form-group">
                                    <label for="meta_description">Meta Description</label>
                                    <textarea name="meta_description" id="meta_description" class="form-control" rows="5" placeholder="Enter Meta Description">{{ old('meta_description') ? old('meta_description') : setting('meta_description') }}</textarea>
                                    @error('meta_description')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                <div class="col-lg-6">
                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <h2 class="text-center">Control Social Login</h2>

        <div class="row">
            <div class="col-lg-6 mt-3 mt-lg-4">
                <section class="card">
                    <header class="card-header d-flex justify-content-between">
                            <h2 class="card-title">Google Login Crediancial </h2>
                        <div class="switch switch-primary ">
                            <input type="checkbox" onchange="updateGoogle(this)" name="switch" data-plugin-ios-switch value="google" {{ setting('google') == 1 ? 'checked' : ''}}/>
                        </div>
                    </header>
                    <div class="card-body">
                        <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.google.key') }}" >
                            <div class="form-group row pb-4">
                                @csrf
                                <label class="" for="googleClientId">Client Id</label>
                                <div class="">
                                    <input type="text" class="form-control" id="googleClientId" name="googleClientId" placeholder="Enter client id" value="{{ setting('google_client_id') }}">
                                    <span class="text-danger">
                                        @error('googleClientId')
                                            {{ $message }}
                                        @enderror
                                    </span>
                                </div>
                            </div>
                            <div class="form-group row pb-4">
                                @csrf
                                <label class="" for="googleClientSecret">Client Secret</label>
                                <div class="">
                                    <input type="text" class="form-control" id="googleClientSecret" name="googleClientSecret" placeholder="Enter client id" value="{{ setting('google_client_secret') }}">
                                    <span class="text-danger">
                                        @error('googleClientSecret')
                                            {{ $message }}
                                        @enderror
                                    </span>
                                </div>
                            </div>
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                <div class="col-lg-6">
                                    <button type="submit" class="btn btn-success">Save and Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 mt-3 mt-lg-4">
                <div class="row">
                    <section class="card">
                        <header class="card-header d-flex justify-content-between">
                            <h2 class="card-title">Facebook Login Crediancial </h2>
                            <div class="switch switch-primary ">
                                <input type="checkbox" onchange="updateFacebook(this)" name="switch" data-plugin-ios-switch value="facebook" {{ setting('facebook') == 1 ? 'checked' : ''}}/>
                            </div>
                        </header>
                        <div class="card-body">
                            <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.facebook.key') }}" >
                                <div class="form-group row pb-4">
                                    @csrf
                                    <label class="" for="facebookClientId">App Id</label>
                                    <div class="">
                                        <input type="text" class="form-control" id="facebookClientId" name="facebookClientId" placeholder="Enter client id" value="{{ setting('facebook_app_id') }}">
                                        <span class="text-danger">
                                            @error('facebookClientId')
                                                {{ $message }}
                                            @enderror
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row pb-4">
                                    @csrf
                                    <label class="" for="facebookClientSecret">Client Secret</label>
                                    <div class="">
                                        <input type="text" class="form-control" id="facebookClientSecret" name="facebookClientSecret" placeholder="Enter client id" value="{{ setting('facebook_client_secret') }}">
                                        <span class="text-danger">
                                            @error('facebookClientSecret')
                                                {{ $message }}
                                            @enderror
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row pb-4">
                                    <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                    <div class="col-lg-6">
                                        <button type="submit" class="btn btn-success">Save and Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
            <div class="col-lg-6 mt-3 mt-lg-4">
                <div class="row">
                    <section class="card">
                        <header class="card-header d-flex justify-content-between">
                            <h2 class="card-title">Twitter Login Crediancial </h2>
                            <div class="switch switch-primary ">
                                <input type="checkbox" onchange="updateTwitter(this)" name="switch" data-plugin-ios-switch value="twitter" {{ setting('twitter') == 1 ? 'checked' : ''}}/>
                            </div>
                        </header>
                        <div class="card-body">
                            <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.twitter.key') }}">
                                <div class="form-group row pb-4">
                                    @csrf
                                    <label class="" for="twitterClientId">Client Id</label>
                                    <div class="">
                                        <input type="text" class="form-control" id="twitterClientId" name="twitterClientId" placeholder="Enter client id" value="{{ setting('twitter_client_id') }}">
                                        <span class="text-danger">
                                            @error('twitterClientId')
                                                {{ $message }}
                                            @enderror
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row pb-4">
                                    @csrf
                                    <label class="" for="twitterclientSecret">Client Secret</label>
                                    <div class="">
                                        <input type="text" class="form-control" id="twitterclientSecret" name="twitterclientSecret" placeholder="Enter client id" value="{{ setting('twitter_client_secret') }}">
                                        <span class="text-danger">
                                            @error('twitterclientSecret')
                                                {{ $message }}
                                            @enderror
                                        </span>
                                    </div>
                                </div>

                                <div class="form-group row pb-4">
                                    <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                    <div class="col-lg-6">
                                        <button type="submit" class="btn btn-success">Save and Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
            <div class="col-lg-6 mt-3 mt-lg-4">
                <div class="row">
                    <section class="card">
                        <header class="card-header d-flex justify-content-between">
                            <h2 class="card-title">Linkedin Login Crediancial </h2>
                            <div class="switch switch-primary ">
                                <input type="checkbox" onchange="updateLinkedin(this)" name="switch" data-plugin-ios-switch value="linkedin" {{ setting('linkedin') == 1 ? 'checked' : ''}}/>
                            </div>
                        </header>
                        <div class="card-body">
                                <form class="form-horizontal form-bordered" method="POST" action="{{ route('admin.update.linkedin.key') }}">
                                    <div class="form-group row pb-4">
                                        @csrf
                                        <label class="" for="linkedinClientId">Client Id</label>
                                        <div class="">
                                            <input type="text" class="form-control" id="linkedinClientId" name="linkedinClientId" placeholder="Enter client id" value="{{ setting('linkedin_client_id') }}">
                                            <span class="text-danger">
                                                @error('linkedinClientId')
                                                    {{ $message }}
                                                @enderror
                                            </span>
                                        </div>
                                    </div>
                                    <div class="form-group row pb-4">
                                        @csrf
                                        <label class="" for="linkedinclientSecret">Client Secret</label>
                                        <div class="">
                                            <input type="text" class="form-control" id="linkedinclientSecret" name="linkedinclientSecret" placeholder="Enter client id" value="{{ setting('linkedin_client_secret') }}">
                                            <span class="text-danger">
                                                @error('linkedinclientSecret')
                                                    {{ $message }}
                                                @enderror
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group row pb-4">
                                        <label class="col-lg-3 control-label text-lg-end pt-2"></label>
                                        <div class="col-lg-6">
                                            <button type="submit" class="btn btn-success">Save and Update</button>
                                        </div>
                                    </div>
                                </form>
                        </div>
                    </section>
                </div>
            </div>
        </div> --}}
    </section>
@endsection

@section('scripts')
@endsection
