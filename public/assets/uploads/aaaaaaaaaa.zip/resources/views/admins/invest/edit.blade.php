@extends('admins.layouts.app_admin')
@section('title')
    <title>Invest</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Invest</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Invest</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Invest</h2>
                    </header>
                    <div class="card-body">
                        <form role="form" action="{{ route('invest.update', $data->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PATCH')
                          <div class="card-body">
                            <div class="form-group">
                                <label for="name">Title</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Enter name" value="{{ old('name') ?? $data->name }}">
                                @error('name')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="amount">Amount</label>
                                <input type="number" name="amount" class="form-control" id="amount" placeholder="Enter amount" value="{{ old('amount') ?? $data->amount }}">
                                @error('amount')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="profit">Profit</label>
                                <input type="number" name="profit" class="form-control" id="profit" placeholder="Enter profit" value="{{ old('profit') ?? $data->profit }}">
                                @error('profit')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            
                             <div class="form-group">
                                <label for="monthly_profit">Monthly Profit</label>
                                <input type="number" name="monthly_profit" class="form-control" id="monthly_profit" placeholder="Enter monthly profit" value="{{ old('monthly_profit') ?? $data->monthly_profit }}">
                                @error('monthly_profit')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                          </div>
                          <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save & Update</button>
                          </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')

</script>

@endsection
