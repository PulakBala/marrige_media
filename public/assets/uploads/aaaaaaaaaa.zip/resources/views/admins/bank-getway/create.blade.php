@extends('admins.layouts.app_admin')
@section('title')
    <title>Bank Details</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Bank Details</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Bank Details</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Add Bank Details</h2>
                    </header>
                    <div class="card-body">
                        <form role="form" action="{{ route('bank-payment-getway.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                          <div class="card-body">
                            <div class="form-group">
                                <label for="bank_name">Bank Name</label>
                                <input type="text" name="bank_name" class="form-control" id="bank_name" placeholder="Enter bank name" value="{{ old('bank_name') }}">
                                @error('bank_name')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="account_name">Account Name</label>
                                <input type="text" name="account_name" class="form-control" id="account_name" placeholder="Enter account name" value="{{ old('account_name') }}">
                                @error('account_name')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="account_number">Account Number</label>
                                <input type="number" name="account_number" class="form-control" id="account_number" placeholder="Enter category name"  value="{{ old('account_number') }}">
                                @error('account_number')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>


                            <div class="form-group">
                                <label for="branch_name">Branch Name</label>
                                <input type="text" name="branch_name" class="form-control" id="branch_name" placeholder="Enter branch name"  value="{{ old('branch_name') }}">
                                @error('branch_name')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>





                            <div class="form-group">
                                <label for="image">logo</label>
                                <input type="file" class="form-control" name="logo" id="logo">
                                @error('logo')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                          </div>
                          <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save & Create</button>
                          </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')



@endsection
