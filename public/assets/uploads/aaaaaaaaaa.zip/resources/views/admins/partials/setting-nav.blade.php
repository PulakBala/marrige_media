<div class="nav flex-column">

    <a class="nav-link {{ Request::url() == route('admin.setting.index') ? 'active' : '' }}" href="{{ route('admin.setting.index') }}" ><i class="bx bx-cog me-2"></i> General</a>

      <a class="nav-link {{ Request::url() == route('admin.setting.meta') ? 'active' : '' }}" href="{{ route('admin.setting.meta') }}"><i class="bx bx-block me-2"></i> Site Meta</a>

      <a class="nav-link {{ Request::url() == route('admin.setting.email') ? 'active' : '' }}" href="{{ route('admin.setting.email') }}"><i class="bx bx-envelope me-2"></i> Email Crediancials</a>

      <a class="nav-link {{ Request::url() == route('admin.setting.socialite') ? 'active' : '' }}" href="{{ route('admin.setting.socialite') }}"><i class="bx bx-power-off me-2"></i> Login Crediancials</a>
</div>
