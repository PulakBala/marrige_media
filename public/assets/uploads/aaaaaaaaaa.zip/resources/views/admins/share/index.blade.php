@extends('admins.layouts.app_admin')
@section('title')
    <title>Share Lists</title>
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/datatables/media/css/dataTables.bootstrap5.css" />
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Share Lists</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Share</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header d-flex justify-content-between align-items-center">
                        <h2 class="card-title">All Share</h2>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>User</th>
                                    <th>Name</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($datas as $data)
                                    <tr class="align-middle">
                                        <td>{{ ++$loop->index }}</td>
                                        <td class="text-nowrap">
                                            <div class="d-flex justify-content-start align-items-center">
                                                <img src="{{ asset('public/' . $data->shareWithUserRelation->profile) }}" alt="" width="40" class="border">
                                                <div class="mx-1">
                                                    <b>{{ $data->shareWithUserRelation->name }}</b>
                                                    <span class="d-block"><b>Profile ID: </b> {{ $data->shareWithUserRelation->profile_id }}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-nowrap"><b>{{ $data->name }}</b></td>
                                        <td class="text-nowrap">{{ $data->amount }} tk</td>
                                        <td class="text-nowrap"><span class="text-capitalize">{{ $data->status }}</span></td>
                                        <td class="text-nowrap">
                                            <a href="{{ route('admin.share.acceptStatus', $data->id) }}" class="btn btn-sm btn-success">Accept</a>
                                            <a href="{{ route('admin.share.rejectedStatus', $data->id) }}" class="btn btn-sm btn-danger">Rejected</a>
                                            <a href="{{ route('admin.share.delete', $data->id) }}" class="btn btn-sm btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="{{ asset('admin') }}/js/examples/examples.datatables.tabletools.js"></script>
@endsection
