@extends('admins.layouts.app_admin')
@section('title')
    <title>User's Lists</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Pages Lists</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Pages</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Edit Page</h2>
                    </header>
                    <div class="card-body">
                        <form class="form-horizontal form-bordered" action="{{ route('admin.about.update') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="heading">Heading</label>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" id="heading" name="heading" placeholder="Enter heading" value="{{ old('heading') ?? $data->heading }}">
                                    @error('heading')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>


                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="description">Description</label>
                                <div class="col-lg-6">
                                    <textarea class="form-control" id="description" name="description" placeholder="Enter description" rows="5">{{ old('description') ?? $data->description }}</textarea>
                                    @error('description')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="image">Image</label>
                                <div class="col-lg-6">
                                    <input type="file" class="form-control" id="image" name="image" placeholder="Enter image">
                                    @error('image')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <img src="{{ asset($data->image) }}" alt="" width="80" class="border rounded mt-2 p-1">
                                </div>
                            </div>




                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="content"></label>
                                <div class="col-lg-6">
                                    <button class="btn btn-success" type="submit">Save & Update</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')



@endsection
