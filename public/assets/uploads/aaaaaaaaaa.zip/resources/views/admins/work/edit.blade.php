@extends('admins.layouts.app_admin')
@section('title')
    <title>Edit Work</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Edit Work</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Pages</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Edit Work Process</h2>
                    </header>
                    <div class="card-body">
                        <form class="form-horizontal form-bordered" action="{{ route('work-processes.update', $data->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PATCH')
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="title">Title</label>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" value="{{ $data->title }}">
                                </div>
                            </div>

                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="short_description">Short Description</label>
                                <div class="col-lg-6">
                                    <textarea class="form-control" id="short_description" name="short_description" placeholder="Enter short description" rows="5">{{ $data->short_description }}</textarea>
                                </div>
                            </div>

                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="icon">Icon</label>
                                <div class="col-lg-6">
                                    <input type="file" class="form-control" id="icon" name="icon" placeholder="Enter icon">
                                    @error('icon')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <img src="{{ asset($data->icon) }}" alt="" width="50" class="border rounded mt-2 p-1">
                                </div>
                            </div>

                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="content"></label>
                                <div class="col-lg-6">
                                    <button class="btn btn-success" type="submit">Save & Update</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')

@endsection
