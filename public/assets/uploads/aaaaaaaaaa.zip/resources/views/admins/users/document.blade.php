
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Download Details</title>

    <style>
        .w-100{
            width: 100%;
        }
        .d-flex{
            display: flex;
        }
        .justify-content-between{
            justify-content: space-between;
        }
        .justify-content-start{
            justify-content: left ;
        }
        .align-items-center{
            align-items:center;
        }

        .text-left{
            text-align: left;
        }

        .mx-auto{
            margin: 0 auto;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="container">
            <div class="row p-3">
                <div class="col-12">
                    <div class="text-center p-1 my-2 rounded" style="background-color:#ddd;">
                        <img src="{{ asset('admin/logo-circle.jpg') }}" alt="" style="width: 80px; height:80px">
                    </div>


                    <h2>Dear {{ $name }},</h2>

                    <p>We are pleased to inform you that an amount of Tk. {{ $amount }}/- has been credited to your account.</p>
                    
                    <div class="mt-4">
                        <p><strong>Your Account Summary:</strong></p>
                        <ul style="list-style: none; padding-left: 10px;">
                            <li>Month: {{ $month }}</li>
                            <li>Your Closing Balance is`: TK. {{ $amount }}/-</li>
                            <li>Total Balance: TK. {{ $updated_total_fund }}/-</li>
                        </ul>
                    </div>
                    <h3>Thank you for being a valued Partner  of Abosor.</h3>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
