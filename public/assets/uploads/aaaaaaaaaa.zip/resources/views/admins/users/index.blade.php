@extends('admins.layouts.app_admin')
@section('title')
    <title>User's Lists</title>
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/datatables/media/css/dataTables.bootstrap5.css" />
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>User's Lists</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>User's</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">All User's</h2>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th class="text-nowrap">User</th>
                                    <th class="text-nowrap">Email</th>
                                    <th class="text-nowrap">Share</th>
                                     <th class="text-nowrap">Total Fund</th>
                                    <th class="text-nowrap">Add Fund</th>

                                    <th class="text-nowrap">Total Due</th>
                                    <th class="text-nowrap">Add Due</th>
                                    <th class="text-nowrap">Joined At</th>
                                    <th class="text-nowrap">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($users as $key => $user)
                                    <tr class="align-middle">
                                        <td class="text-nowrap">
                                            <div class=" px-2">
                                                <h4 class="my-0">{{ $user->name }}</h4>
                                                <span class="d-block"> <b>Profile ID:</b> {{ $user->profile_id }}</span>
                                            </div>
                                            {{-- <div class="d-md-flex justify-content-start align-items-center"> --}}
                                                {{-- <img src="{{ asset($user->profile) }}" alt="" class="img-fluid border p-1 d-none d-md-block rounded rounded-circle" width="70" height="70"> --}}
                                            {{-- </div> --}}
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-flex justify-content-between align-items-center">
                                                {{ $user->email }}
                                                @if ($user->email_verified_at == NULL)
                                                    <button class="btn btn-primary btn-sm" onclick="return window.location.href='{{ route('admin.user.emailVerified', $user->id) }}'">Verified</button>
                                                @else
                                                    <span class="badge badge-success">Verified</span>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >{{ getShare($user->id) }}</td>
                                         <td class="text-nowrap" >
                                            <div class="d-md-flex justify-content-between align-items-center">
                                                <span>{{ $user->total_fund }} tk</span>
                                                {{-- <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal2{{ $key }}">
                                                    Add Fund
                                                  </button> --}}

                                                  {{-- <a href="{{ route('admin.fund.cashPayment') }}" class="btn btn-sm btn-primary">Add fund</a> --}}
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-md-flex justify-content-between align-items-center">
                                                {{-- <span>{{ $user->total_fund }} tk</span> --}}
                                                {{-- <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal2{{ $key }}">
                                                    Add Fund
                                                  </button> --}}

                                                  <a href="{{ route('admin.fund.cashPayment') }}" class="btn btn-sm btn-primary">Add fund</a>
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="d-block">{{ $user->total_due }} tk</span>
                                                {{-- <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal{{ $key }}">
                                                    Add Due
                                                  </button> --}}
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >
                                            <div class="d-flex justify-content-between align-items-center">
                                                {{-- <span class="d-block">{{ $user->total_due }} tk</span> --}}
                                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal{{ $key }}">
                                                    Add Due
                                                  </button>
                                            </div>
                                        </td>
                                        <td class="text-nowrap" >{{ Carbon\Carbon::parse($user->created_at)->format('d m Y') }}</td>
                                        <td class="text-nowrap" >
                                            <a href="{{ route('admin.user.edit', $user->id) }}" class="delete-row mx-1"><i class="far fa-edit"></i></a>
                                            <a href="{{ route('admin.user.details', $user->id) }}" class="delete-row mx-1"><i class="far fa-eye"></i></a>
                                            <a href="{{ route('admin.user.delete', $user->id) }}" class="delete-row mx-1"><i class="far fa-trash-alt"></i></a>
                                            <a href="{{ route('admin.user.downloadDetails', $user->id) }}" class="mx-1"><i class="fa fa-download"></i></a>
                                        </td>
                                    </tr>


                                    <!-- Modal -->
                                    {{-- <div class="modal fade" id="exampleModal2{{ $key }}" tabindex="-1" role="dialog" aria-labelledby="exampleModal2Label" aria-hidden="true">
                                        <form action="{{ route('admin.user.addFund', $user->id) }}" method="POST" enctype="multipart/form-data">
                                            <div class="modal-dialog" role="document">
                                                @csrf
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModal2Label{{ $key }}">Modal title</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">

                                                        <div class="form-group">
                                                            <label for="type{{ $key }}">---Select "Type"---</label>
                                                            <select name="type" id="type{{ $key }}" class="form-control">
                                                                <option value="main">Main</option>
                                                                <option value="due">Due</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="month{{ $key }}">---Select Month---</label>
                                                            <select name="month" id="month{{ $key }}" class="form-control">
                                                                <option value="January">January</option>
                                                                <option value="February">February</option>
                                                                <option value="March">March</option>
                                                                <option value="April">April</option>
                                                                <option value="May">May</option>
                                                                <option value="June">June</option>
                                                                <option value="July">July</option>
                                                                <option value="August">August</option>
                                                                <option value="September">September</option>
                                                                <option value="October">October</option>
                                                                <option value="November">November</option>
                                                                <option value="December">December</option>
                                                            </select>
                                                        </div>



                                                        <div class="form-group border-0">
                                                            <label for="amount{{ $key }}">Amount</label>
                                                            <input type="number" step="1" min="1" class="form-control" placeholder="Enter amount" name="amount">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add Fund</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div> --}}



                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal{{ $key }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <form action="{{ route('admin.user.addDue', $user->id) }}" method="POST" enctype="multipart/form-data">
                                            <div class="modal-dialog" role="document">
                                                @csrf
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel{{ $key }}">Modal title</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="month{{ $key }}">---Select Month---</label>
                                                            <select name="month" id="month{{ $key }}" class="form-control">
                                                                <option value="January">January</option>
                                                                <option value="February">February</option>
                                                                <option value="March">March</option>
                                                                <option value="April">April</option>
                                                                <option value="May">May</option>
                                                                <option value="June">June</option>
                                                                <option value="July">July</option>
                                                                <option value="August">August</option>
                                                                <option value="September">September</option>
                                                                <option value="October">October</option>
                                                                <option value="November">November</option>
                                                                <option value="December">December</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group border-0">
                                                            <label for="year{{ $key }}">Select Year</label>
                                                            <select name="year" id="year{{ $key }}" class="form-control">
                                                                <option value="2024">2024</option>
                                                                <option value="2025">2025</option>
                                                                <option value="2026">2026</option>
                                                                <option value="2027">2027</option>
                                                                <option value="2028">2028</option>
                                                                <option value="2029">2029</option>
                                                                <option value="2030">2030</option>
                                                                <option value="2031">2031</option>
                                                                <option value="2032">2032</option>
                                                                <option value="2033">2033</option>
                                                                <option value="2034">2034</option>
                                                                <option value="2035">2035</option>
                                                                <option value="2036">2036</option>
                                                                <option value="2037">2037</option>
                                                                <option value="2038">2038</option>
                                                                <option value="2039">2039</option>
                                                                <option value="2040">2040</option>
                                                                <option value="2041">2041</option>
                                                                <option value="2042">2042</option>
                                                                <option value="2043">2043</option>
                                                                <option value="2044">2044</option>
                                                                <option value="2045">2045</option>
                                                                <option value="2046">2046</option>
                                                                <option value="2047">2047</option>
                                                                <option value="2048">2048</option>
                                                                <option value="2049">2049</option>
                                                                <option value="2050">2050</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Submit Due</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="{{ asset('admin') }}/js/examples/examples.datatables.tabletools.js"></script>
@endsection
