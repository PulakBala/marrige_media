@extends('admins.layouts.app_admin')
@section('title')
    <title>User Edit</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Pages Edit</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Pages</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Edit Page</h2>
                    </header>
                    <div class="card-body">
                        {{-- <form class="form-horizontal form-bordered" action="{{ route('admin.user.update', $user->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="name">Name</label>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" value="{{ old('name') ?? $user->name }}">
                                    @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="email">Email</label>
                                <div class="col-lg-6">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="{{ old('email') ?? $user->email }}">
                                    @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="avatar">avatar</label>
                                <div class="col-lg-6">
                                    <input type="file" class="form-control" id="avatar" name="avatar">
                                    @error('avatar')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <img src="{{ asset($user->profile) }}" alt="" style="width: 60px;">
                            </div>





                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="content"></label>
                                <div class="col-lg-6">
                                    <button class="btn btn-success" type="submit">Save & Update</button>
                                </div>
                            </div>

                        </form> --}}

                        <form action="{{ route('admin.user.update', $user->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row">
                                <div class="col-lg-6 mb-3">
                                    <label for="name">Name <span class="text-danger">*</span></label>
                                    <input type="text" id="name" placeholder="Enter Name" name="name" class="form-control">
                                    @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="email">Email <span class="text-danger">*</span></label>
                                    <input type="email" id="email" placeholder="Enter email" name="email" class="form-control">
                                    @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="father_name">Father/Husbend Name <span class="text-danger">*</span></label>
                                    <input type="text" id="father_name" placeholder="Enter father name" name="father_name" class="form-control">
                                    @error('father_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="mother_name">Mother's Name <span class="text-danger">*</span></label>
                                    <input type="text" id="mother_name" placeholder="Enter mother name" name="mother_name" class="form-control">
                                    @error('mother_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="phone_number">Phone Number <span class="text-danger">*</span></label>
                                    <input type="number" id="phone_number" placeholder="Enter phone number" name="phone_number" class="form-control">
                                    @error('phone_number')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="education_qualification">Education Qualification <span class="text-danger">*</span></label>
                                    <input type="text" id="education_qualification" placeholder="Enter education qualification" name="education_qualification" class="form-control">
                                    @error('education_qualification')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="passport_or_nid_number">Passport/NID no <span class="text-danger">*</span></label>
                                    <input type="number" id="passport_or_nid_number" placeholder="Enter passport or nid no" name="passport_or_nid_number" class="form-control">
                                    @error('passport_or_nid_number')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="religion">Religion <span class="text-danger">*</span></label>
                                    <input type="text" id="religion" placeholder="Enter religion" name="religion" class="form-control">
                                    @error('religion')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="date_of_birth">Date Of Birth <span class="text-danger">*</span></label>
                                    <input type="date" id="date_of_birth" placeholder="Enter date of birth" name="date_of_birth" class="form-control">
                                    @error('date_of_birth')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="nationality">Nationality <span class="text-danger">*</span></label>
                                    <input type="text" id="nationality" placeholder="Enter nationality" name="nationality" class="form-control">
                                    @error('nationality')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="blood_group">Blood Group <span class="text-danger">*</span></label>
                                    <input type="text" id="blood_group" placeholder="Enter blood group" name="blood_group" class="form-control">
                                    @error('blood_group')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="occupation">Occupation <span class="text-danger">*</span></label>
                                    <input type="text" id="occupation" placeholder="Enter occupation" name="occupation" class="form-control">
                                    @error('occupation')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-12">
                                    <h4>Address</h4>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="village">Village <span class="text-danger">*</span></label>
                                    <input type="text" id="village" placeholder="Enter village" name="village" class="form-control">
                                    @error('village')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="word_no">Word No <span class="text-danger">*</span></label>
                                    <input type="number" id="word_no" placeholder="Enter word no" name="word_no" class="form-control">
                                    @error('word_no')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="post_office">Post Office <span class="text-danger">*</span></label>
                                    <input type="text" id="post_office" placeholder="Enter post office" name="post_office" class="form-control">
                                    @error('post_office')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="thana">Thana <span class="text-danger">*</span></label>
                                    <input type="text" id="thana" placeholder="Enter thana" name="thana" class="form-control">
                                    @error('thana')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="upzilla">Upzilla <span class="text-danger">*</span></label>
                                    <input type="text" id="upzilla" placeholder="Enter upzilla" name="upzilla" class="form-control">
                                    @error('upzilla')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="district">District <span class="text-danger">*</span></label>
                                    <input type="text" id="district" placeholder="Enter district" name="district" class="form-control">
                                    @error('district')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="password">Password <span class="text-danger">*</span></label>
                                    <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" id="psw" placeholder="Enter password" name="password" class="form-control">
                                    @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror

                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="password_confirmation">Re-type confirmation Password <span class="text-danger">*</span></label>
                                    <input type="password" id="password_confirmation" placeholder="Enter confirmation password" name="password_confirmation" class="form-control">
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary" type="submit" id="submit">Sign Up</button>

                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')



@endsection
