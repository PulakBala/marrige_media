<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- Bootstrap CSS -->
    {{-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"> --}}

    <title>Download Details</title>

    <style>
        .w-100{
            width: 100% !important;
        }
        .w-50{
            width: 50% !important;
        }
        .d-flex{
            display: flex;
        }
        .justify-content-between{
            justify-content: space-between;
        }
        .justify-content-start{
            justify-content: left ;
        }
        .align-items-center{
            align-items:center;
        }

        .text-left{
            text-align: left;
        }

        .mx-auto{
            margin: 0 auto;
        }
        .overlay{
            background-image: url('{{ asset('admin/logo-circle.jpg') }}');
            background-repeat: no-repeat;
            top:15%;
            width:100%;
            opacity: .1;
            left:12%;
            height:100%;
            position:absolute;
            z-index:-99;
        }
        .border-bottom{
            border-bottom: 2px dotted #A661DB;
        }
        .mb-5{
            margin-bottom: 20px;
        }
        body span{
            font-size: 18px;
        }
    </style>
</head>

<body style="border: 2px solid #A661DB; padding:5px;">

    <div class="container-fluid">
        <img src="{{ asset('admin/logo-circle.jpg') }}" alt="" style="width: 66px; height:66px;position:absolute;left:3px; padding:1px; z-index:9999;margin-top:3px;">



        <img src="{{ asset('admin/headline.png') }}" alt="" style="width: 100%;position: relative; border-radius:50px;height:60px;margin-top:7px;align-items:center;">




        <img src="{{ asset($data->profile) }}" alt="" style="width: 60px; height:60px;margin-top:5px; position:absolute;right:6px; padding:1px; border-radius:100%;margin-top:6px;">






        <div class="overlay"></div>

            <h2 class="border-bottom text-dark" style="padding-bottom:3px;"><i>Personal Information :</i></h2>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:180px;"><b>Name: </b>{{ $data->name }}</span>
                <span><b>Email: </b>{{ $data->email }}</span>
            </div>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:100px;"><b>Father Name: </b>{{ $data->father_name }}</span>
                <span><b>Mother Name: </b>{{ $data->mother_name }}</span>
            </div>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:40px;"><b>Mobile Number: </b>{{ $data->phone_number }}</span>
                <span><b>Edu. Qualification: </b>{{ $data->education_qualification }}</span>
            </div>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:80px;"><b>Total Share: </b>{{ $share }}</span>
                <span style="margin-right:100px;"><b>{{ $data->passport_or_nid_type }}: </b>{{ $data->passport_or_nid_number }}</span>
                <span><b>Religion: </b>{{ $data->religion }}</span>
            </div>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:30px;"><b>Date Of Birth: </b>{{ Carbon\Carbon::parse($data->date_of_birth)->format('d M, Y') }}</span>
                <span style="margin-right:40px;"><b>Nationality: </b>{{ $data->nationality }}</span>
                <span><b>Blood Group: </b>{{ $data->blood_group }}</span>
            </div>

            <br>
            <h2 class="border-bottom text-dark" style="padding-bottom:3px;"><i>Address :</i></h2>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:50px;"><b>Village: </b>{{ $data->village }}</span>
                <span style="margin-right:40px;"><b>Word No: </b>{{ $data->word_no }}</span>
                <span><b>Post Office: </b>{{ $data->post_office }}</span>
            </div>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:50px;"><b>Thana: </b>{{ $data->thana }}</span>
                <span style="margin-right:40px;"><b>Upzilla: </b>{{ $data->upzilla }}</span>
                <span><b>District: </b>{{ $data->district }}</span>
            </div>

            <br>
            <h2 class="border-bottom text-dark" style="padding-bottom:3px;"><i>Permanent Address :</i></h2>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:50px;"><b>Village: </b>{{ $data->village }}</span>
                <span style="margin-right:40px;"><b>Word No: </b>{{ $data->word_no }}</span>
                <span><b>Post Office: </b>{{ $data->post_office }}</span>
            </div>

            <div class="border-bottom mb-5" style="padding-bottom:3px;">
                <span style="margin-right:50px;"><b>Thana: </b>{{ $data->thana }}</span>
                <span style="margin-right:40px;"><b>Upzilla: </b>{{ $data->upzilla }}</span>
                <span><b>District: </b>{{ $data->district }}</span>
            </div>

            <br>
            <h2 class="text-dark" style="padding-bottom:3px; margin:0 auto;text-align:center;text-transform:uppercase;"><i>Authorization</i></h2>

            <div class="mb-5" style="padding-bottom:3px;text-align:center;">
                <br>
                <span style="margin-right:200px;"><b>Chairman: </b> &nbsp; </span>
                <span><b>Secretary: </b> &nbsp; </span>
            </div>




        <br> <br> <br> <br> <br>
        <div style="background: #ddd; padding:1px; margin-bottom:-10px;">
            <p style="text-align: center;">Thanks by <span style="color: #A661DB"><b>Abosor</b></span></p>
        </div>

    </div>
    {{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script> --}}
</body>

</html>
