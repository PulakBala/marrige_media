@extends('admins.layouts.app_admin')
@section('title')
    <title>Payment History</title>
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/datatables/media/css/dataTables.bootstrap5.css" />
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header ">
            <h2>Payment History</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>History</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header d-flex justify-content-between align-items-center">
                        <h2 class="card-title">Payment History</h2>
                        <a href="{{ route('admin.users.dueShow', $user->id) }}" class="btn btn-success btn-sm">Show Due</a>
                    </header>
                    <div class="card-body">

                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Sender Number</th>
                                    <th>Amount</th>
                                    <th>Transaction ID</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($datas as $data)
                                    <tr class="align-middle">
                                        <td>{{ ++$loop->index }}</td>
                                        <td>{{ $data->month. ', ' . $data->year }}</td>
                                        <td>
                                            @if ($data->type == 'mobile-banking')
                                                {{ $data->mobileGetwayWithFundRelation->account_name }}
                                            @elseif($data->type == 'bank-details')
                                                {{ $data->bankGetwayWithFundRelation->bank_name }}
                                            @else
                                                Cash Payment
                                            @endif
                                        </td>
                                        <td>{{ $data->sender_number ?? 'N/A' }} </td>
                                        <td>{{ $data->amount }} tk</td>
                                        <td>{{ $data->trx_id ?? 'N/A' }}</td>
                                        <td><span class="text-capitalize">
                                            @if ($data->status == 'pending')
                                                <span class="badge bg-secondary">Pending</span>
                                            @elseif ($data->status == 'approved')
                                                <span class="badge bg-success">Approved</span>
                                            @else
                                                <span class="badge bg-danger">Approved</span>
                                            @endif
                                        </span></td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="{{ asset('admin') }}/js/examples/examples.datatables.tabletools.js"></script>
@endsection
