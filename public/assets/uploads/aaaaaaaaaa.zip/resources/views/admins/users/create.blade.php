@extends('admins.layouts.app_admin')
@section('title')
    <title>Add User</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Pages Create</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Pages</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Add User</h2>
                    </header>
                    <div class="card-body">
                        <form action="{{ route('admin.user.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row">
                                <div class="col-lg-6 mb-3">
                                    <label for="name">Name <span class="text-danger">*</span></label>
                                    <input type="text" id="name" placeholder="Enter Name" name="name" class="form-control">
                                    @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="email">Email <span class="text-danger">*</span></label>
                                    <input type="email" id="email" placeholder="Enter email" name="email" class="form-control">
                                    @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                
                                <div class="col-lg-6 mb-3">
                                    <label for="password">Password <span class="text-danger">*</span></label>
                                    <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" id="psw" placeholder="Enter password" name="password" class="form-control">
                                    @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror

                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="password_confirmation">Re-type confirmation Password <span class="text-danger">*</span></label>
                                    <input type="password" id="password_confirmation" placeholder="Enter confirmation password" name="password_confirmation" class="form-control">
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary" type="submit" id="submit">Sign Up</button>

                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')



@endsection
