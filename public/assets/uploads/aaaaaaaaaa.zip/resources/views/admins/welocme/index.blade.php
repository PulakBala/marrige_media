@extends('admins.layouts.app_admin')
@section('title')
    <title>Edit Welcome</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Edit Welcome</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Edit Welcome</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Edit Welcome</h2>
                    </header>
                    <div class="card-body">
                        <form class="form-horizontal form-bordered" action="{{ route('admin.welcome.update', $data->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf

                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="heading">Heading</label>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" id="heading" name="heading" placeholder="Enter heading" value="{{ old('heading') ?? $data->heading }}">
                                    @error('heading')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>



                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="link">Link</label>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" id="link" name="link" placeholder="Enter url" value="{{ old('link') ?? $data->link }}">
                                    @error('link')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>


                            <div class="form-group row pb-4">
                                <label class="col-lg-3 control-label text-lg-end pt-2" for="content"></label>
                                <div class="col-lg-6">
                                    <button class="btn btn-success" type="submit">Save & Update</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')



@endsection
