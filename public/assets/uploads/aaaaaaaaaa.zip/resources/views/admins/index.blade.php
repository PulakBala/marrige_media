@extends('admins.layouts.app_admin')
@section('title')
    <title>Dashboard</title>
@endsection

@section('styles')

@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Dashboard</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <!-- start: page -->
        <div class="row mb-3 justify-content-center">
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fa fa-users"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Users</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $totalUsers }}</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                <a class="text-muted text-uppercase" href="{{ route('admin.users.index') }}">(view all)</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fa fa-share"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Share Request</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $shareRequest }}</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                <a class="text-muted text-uppercase" href="{{ route('admin.share.index') }}">(view all)</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Payment Request</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $paymentRequest }}</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Fund</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $totalFund }} tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                {{-- <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Due</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $totalDue }} tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                {{-- <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Invest</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $totalInvest }} tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                {{-- <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Profit</h4>
                                    <div class="info">
                                        <strong class="amount">{{ $totalInvestProfit }} tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                {{-- <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Loan</h4>
                                    <div class="info">
                                        <strong class="amount">0 tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                {{-- <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-xl-4">
                <section class="card card-featured-left card-featured-primary mb-3">
                    <div class="card-body">
                        <div class="widget-summary">
                            <div class="widget-summary-col widget-summary-col-icon">
                                <div class="summary-icon bg-primary">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="widget-summary-col">
                                <div class="summary">
                                    <h4 class="title">Total Jakat</h4>
                                    <div class="info">
                                        <strong class="amount">0 tk</strong>
                                    </div>
                                </div>
                                <div class="summary-footer">
                                {{-- <a class="text-muted text-uppercase" href="{{ route('admin.fund.pendingRequest') }}">(view all)</a> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </section>
@endsection

@section('scripts')

@endsection
