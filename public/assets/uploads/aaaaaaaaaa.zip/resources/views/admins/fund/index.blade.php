@extends('admins.layouts.app_admin')
@section('title')
    <title>Payment Request</title>
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('admin') }}/vendor/datatables/media/css/dataTables.bootstrap5.css" />
@endsection

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Payment Request</h2>
            <div class="right-wrapper text-end">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{route('admin.dashboard')}}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                    <li><span>Payment Request</span></li>
                </ol>
                <div class="sidebar-right-toggle"  class="d-none">&nbsp;</div>
            </div>
        </header>

        <div class="row">
            <div class="col">
                <section class="card">
                    <header class="card-header">
                        <h2 class="card-title">Payment Request</h2>
                    </header>
                    <div class="card-body">
                        <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">

                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Payment Method</th>
                                    <th>Sender Number</th>
                                    <th>Amount</th>
                                    <th>Transaction ID</th>
                                    <th>Payment Status</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($datas as $data)
                                    <tr class="align-middle">
                                        <td>{{ ++$loop->index }}</td>
                                        <td>{{ $data->month. ', ' . $data->year }}</td>
                                        <td class="text-nowrap">
                                            <div class="d-flex justify-content-start align-items-center">
                                                <img src="{{ asset($data->fundWithUserRelation->profile) }}" alt="" width="40" class="border">
                                                <div class="mx-1">
                                                    <b>{{ $data->fundWithUserRelation->name }}</b>
                                                    <span class="d-block"><b>Profile ID: </b> {{ $data->fundWithUserRelation->profile_id }}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            @if ($data->type == 'mobile-banking')
                                                {{ $data->mobileGetwayWithFundRelation->account_name }}
                                            @elseif($data->type == 'bank-details')
                                                {{ $data->bankGetwayWithFundRelation->bank_name }}
                                            @else
                                                Cash Payment
                                            @endif
                                        </td>
                                        <td>{{ $data->sender_number }} </td>
                                        <td>{{ $data->amount }} tk</td>
                                        <td>{{ $data->trx_id }}</td>
                                        <td>
                                            <span class="text-capitalize">{{ $data->payment_status }}</span>
                                        </td>
                                        <td>
                                            <span class="text-capitalize">{{ $data->status }}</span>
                                        </td>
                                        <td>
                                            @if ($data->status == 'pending')
                                                <a href="{{ route('admin.fund.approvedStatus', $data->id) }}" class="btn btn-sm btn-success">Approved</a>
                                                <a href="{{ route('admin.fund.rejectedStatus', $data->id) }}" class="btn btn-sm btn-danger">Rejected</a>
                                            @endif
                                            <a href="{{ route('admin.fund.deleteStatus', $data->id) }}" onclick="return confirm('Are you want to delete?');" class="btn btn-sm btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
        <script src="{{ asset('admin') }}/vendor/datatables/media/js/dataTables.bootstrap5.min.js"></script>
		<script src="{{ asset('admin') }}/js/examples/examples.datatables.tabletools.js"></script>
@endsection
