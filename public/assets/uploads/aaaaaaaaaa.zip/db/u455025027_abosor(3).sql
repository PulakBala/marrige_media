-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 27, 2024 at 10:03 AM
-- Server version: 10.11.7-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u455025027_abosor`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `heading` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `heading`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'আমাদের প্রকল্প সম্পর্কে আলোচনা করা যাক', 'অবসর\r\nবহুমুখী প্রকল্পের স্বপ্নের সেতু', 'uploads/about/left-image.png', '2024-06-09 12:14:59', '2024-06-27 04:31:16');

-- --------------------------------------------------------

--
-- Table structure for table `bank_payment_getways`
--

CREATE TABLE `bank_payment_getways` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `user_id`, `title`, `file`, `created_at`, `updated_at`) VALUES
(2, 5, 'Fund Added', '/uploads/documents/5697679154877683049.pdf', '2024-06-15 15:05:35', NULL),
(3, 5, 'Fund Added', '/uploads/documents/5913585765299299844.pdf', '2024-06-15 09:53:02', NULL),
(4, 5, 'Fund Added', '/uploads/documents/5899553136897230597.pdf', '2024-06-15 09:55:32', NULL),
(5, 5, 'dfgasdf', 'uploads/documents/1718445380-profile-image.jpg', '2024-06-15 09:56:20', NULL),
(6, 5, 'Fund Added', '/uploads/documents/5436631700514621528.pdf', '2024-06-15 12:59:17', NULL),
(7, 6, 'Fund Added', '/uploads/documents/6564249609148549822.pdf', '2024-06-26 19:09:30', NULL),
(8, 6, 'Fund Added', '/uploads/documents/6121196820477694557.pdf', '2024-06-26 19:09:39', NULL),
(9, 6, 'Fund Added', '/uploads/documents/6742480144893059620.pdf', '2024-06-26 19:10:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dues`
--

CREATE TABLE `dues` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `month` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dues`
--

INSERT INTO `dues` (`id`, `user_id`, `month`, `year`, `amount`, `created_at`, `updated_at`) VALUES
(21, 6, 'April', '2024', 4000.00, '2024-06-26 19:06:31', NULL),
(22, 6, 'May', '2024', 4000.00, '2024-06-26 19:06:46', NULL),
(23, 6, 'June', '2024', 4000.00, '2024-06-26 19:06:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `featured_areas`
--

CREATE TABLE `featured_areas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `featured_areas`
--

INSERT INTO `featured_areas` (`id`, `title`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'সহজ ডিজিটাল প্ল্যাটফর্ম', 'uploads/featured/featured-item-01.png', '2024-06-09 12:14:59', NULL),
(2, 'আপনার প্রতিষ্ঠানের উপযোগী', 'uploads/featured/featured-item-01.png', '2024-06-09 12:14:59', NULL),
(3, 'আনলিমিটেড অ্যাক্সেস', 'uploads/featured/featured-item-01.png', '2024-06-09 12:14:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `funds`
--

CREATE TABLE `funds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `getway_id` bigint(20) UNSIGNED NOT NULL,
  `sender_number` varchar(255) DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `trx_id` varchar(255) DEFAULT NULL,
  `month` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `type` enum('mobile-banking','bank-details','cash') NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `payment_status` enum('due','main') NOT NULL DEFAULT 'main',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `funds`
--

INSERT INTO `funds` (`id`, `user_id`, `getway_id`, `sender_number`, `amount`, `trx_id`, `month`, `year`, `type`, `status`, `payment_status`, `created_at`, `updated_at`) VALUES
(6, 5, 0, NULL, 4000.00, 'N/A', 'January', '2024', 'cash', 'approved', 'due', '2024-06-15 09:49:16', NULL),
(7, 5, 0, NULL, 4000.00, 'N/A', 'January', '2024', 'cash', 'approved', 'due', '2024-06-15 09:53:01', NULL),
(8, 5, 0, NULL, 4000.00, 'N/A', 'February', '2024', 'cash', 'approved', 'due', '2024-06-15 09:55:31', NULL),
(9, 5, 0, NULL, 4000.00, 'N/A', 'January', '2024', 'cash', 'approved', 'due', '2024-06-15 12:59:15', NULL),
(10, 6, 1, '01816451708', 4000.00, '1708', 'January', '2024', 'mobile-banking', 'approved', 'due', '2024-06-26 19:08:15', '2024-06-26 19:10:13'),
(11, 6, 1, '01816451708', 4000.00, '1708', 'February', '2024', 'mobile-banking', 'approved', 'due', '2024-06-26 19:08:31', '2024-06-26 19:09:38'),
(12, 6, 1, '01816451708', 4000.00, '1708', 'March', '2024', 'mobile-banking', 'approved', 'due', '2024-06-26 19:08:44', '2024-06-26 19:09:28');

-- --------------------------------------------------------

--
-- Table structure for table `invests`
--

CREATE TABLE `invests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `profit` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invests`
--

INSERT INTO `invests` (`id`, `name`, `amount`, `profit`, `created_at`, `updated_at`) VALUES
(1, 'রেশন কার্ড', 170000.00, 7000.00, '2024-06-19 09:49:50', '2024-06-19 09:50:39');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_11_27_061820_create_settings_table', 1),
(6, '2024_03_13_171916_create_pages_table', 1),
(7, '2024_03_17_131220_create_teams_table', 1),
(8, '2024_03_17_153337_create_abouts_table', 1),
(9, '2024_03_17_175321_create_work_processes_table', 1),
(10, '2024_03_18_053443_create_welcome_areas_table', 1),
(11, '2024_03_18_162353_create_featured_areas_table', 1),
(12, '2024_03_19_135259_create_mobile_payment_getways_table', 1),
(13, '2024_03_19_142654_create_bank_payment_getways_table', 1),
(14, '2024_03_20_060936_create_shares_table', 1),
(15, '2024_03_21_200958_create_funds_table', 1),
(16, '2024_03_22_202205_create_documents_table', 1),
(17, '2024_03_24_100522_create_dues_table', 1),
(18, '2024_03_24_111219_create_invests_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_payment_getways`
--

CREATE TABLE `mobile_payment_getways` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `account_type` enum('personal','agent') NOT NULL DEFAULT 'personal',
  `logo` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mobile_payment_getways`
--

INSERT INTO `mobile_payment_getways` (`id`, `account_name`, `account_number`, `account_type`, `logo`, `created_at`, `updated_at`) VALUES
(1, 'Bkash', '01318533187', 'personal', 'uploads/payment-getway/1718441382-payment-getway.jpg', '2024-06-15 08:49:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Privacy Policy', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam, quibusdam!', '2024-06-09 12:14:59', NULL),
(2, 'Trams & Condition', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam, quibusdam!', '2024-06-09 12:14:59', NULL),
(3, 'DMCA', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam, quibusdam!', '2024-06-09 12:14:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'title', 'Site Title', '2024-06-09 12:14:58', '2024-06-27 03:45:22'),
(2, 'logo', 'uploads/default/1719459922-logo.png', '2024-06-09 12:14:58', '2024-06-27 03:45:22'),
(3, 'favicon', 'uploads/default/default-favicon.png', '2024-06-09 12:14:58', NULL),
(4, 'author_name', 'Admin', '2024-06-09 12:14:58', NULL),
(5, 'meta_keyword', 'keyword-1,keyword-2,keyword-3,keyword-4,keyword-5', '2024-06-09 12:14:58', NULL),
(6, 'meta_tags', 'tag-1,tag-2,tag-3,tag-4,tag-5', '2024-06-09 12:14:58', NULL),
(7, 'meta_description', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s,', '2024-06-09 12:14:58', NULL),
(8, 'facebook', '0', '2024-06-09 12:14:58', NULL),
(9, 'twitter', '0', '2024-06-09 12:14:58', NULL),
(10, 'google', '0', '2024-06-09 12:14:58', NULL),
(11, 'linkedin', '0', '2024-06-09 12:14:58', NULL),
(12, 'google_client_id', NULL, '2024-06-09 12:14:58', NULL),
(13, 'google_client_secret', NULL, '2024-06-09 12:14:58', NULL),
(14, 'facebook_app_id', NULL, '2024-06-09 12:14:58', NULL),
(15, 'facebook_client_secret', NULL, '2024-06-09 12:14:58', NULL),
(16, 'twitter_client_id', NULL, '2024-06-09 12:14:58', NULL),
(17, 'twitter_client_secret', NULL, '2024-06-09 12:14:58', NULL),
(18, 'linkedin_client_id', NULL, '2024-06-09 12:14:58', NULL),
(19, 'linkedin_client_secret', NULL, '2024-06-09 12:14:58', NULL),
(20, 'mail_transport', 'smtp', '2024-06-09 12:14:58', NULL),
(21, 'mail_host', 'smtp.mailtrap.io', '2024-06-09 12:14:58', NULL),
(22, 'mail_port', '2525', '2024-06-09 12:14:58', NULL),
(23, 'mail_username', '028d59157d3fe0', '2024-06-09 12:14:58', NULL),
(24, 'mail_password', '3b06bc96a55072', '2024-06-09 12:14:58', NULL),
(25, 'mail_encryption', 'tls', '2024-06-09 12:14:58', NULL),
(26, 'mail_from', 'example@test.com', '2024-06-09 12:14:58', NULL),
(27, 'mail_from_name', 'Test', '2024-06-09 12:14:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shares`
--

CREATE TABLE `shares` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `status` enum('pending','accept','rejected','deactive') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shares`
--

INSERT INTO `shares` (`id`, `user_id`, `name`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(3, 6, 'md alauddin', 2000.00, 'accept', '2024-06-26 18:58:28', '2024-06-26 19:01:39'),
(4, 6, 'md alauddin', 2000.00, 'accept', '2024-06-26 18:58:35', '2024-06-26 19:01:36');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `fb_link` varchar(255) DEFAULT NULL,
  `tw_link` varchar(255) DEFAULT NULL,
  `ins_link` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `profile` varchar(255) NOT NULL DEFAULT 'uploads/profile/profile-img.png',
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `total_fund` double(8,2) NOT NULL DEFAULT 0.00,
  `total_due` double(8,2) NOT NULL DEFAULT 0.00,
  `profile_id` int(11) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `education_qualification` varchar(255) DEFAULT NULL,
  `passport_or_nid_type` varchar(255) DEFAULT NULL,
  `passport_or_nid_number` varchar(255) DEFAULT NULL,
  `religion` varchar(255) DEFAULT NULL,
  `date_of_birth` timestamp NULL DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `blood_group` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `village` varchar(255) DEFAULT NULL,
  `word_no` varchar(255) DEFAULT NULL,
  `post_office` varchar(255) DEFAULT NULL,
  `thana` varchar(255) DEFAULT NULL,
  `upzilla` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `provider`, `provider_id`, `profile`, `role`, `total_fund`, `total_due`, `profile_id`, `father_name`, `mother_name`, `phone_number`, `education_qualification`, `passport_or_nid_type`, `passport_or_nid_number`, `religion`, `date_of_birth`, `nationality`, `blood_group`, `occupation`, `village`, `word_no`, `post_office`, `thana`, `upzilla`, `district`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, '$2y$10$7XsN9vfv/MdxPD05/WEKE.BewYJNasjMjtWjHjEdQ66R9a78vaZc6', NULL, NULL, 'uploads/profile/1719459836-profile-image.png', 'admin', 0.00, 0.00, 500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-06-09 12:14:58', '2024-06-27 03:43:56'),
(4, 'Admin2', 'admin1@gmail.com', NULL, '$2y$10$7XsN9vfv/MdxPD05/WEKE.BewYJNasjMjtWjHjEdQ66R9a78vaZc6', NULL, NULL, 'uploads/profile/profile-img.png', 'admin', 0.00, 0.00, 500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-06-09 12:14:58', NULL),
(6, 'md alauddin', 'engr.alauddinridoy@gmail.com', '2024-06-26 18:57:03', '$2y$10$2NMYc7BKyqhc5hkxyWHtEOXQOrlD6ThcFR6BFY8GEpJmmzcY7dD/q', NULL, NULL, 'uploads/profile/profile-img.png', 'user', 12000.00, 12000.00, 501, 'mahmudul hoque', 'bibi umme hani', '01816451708', 'Bsc In Civil', 'Nid', '4201931864', 'islam', '1996-10-15 00:00:00', 'bangladeshi', 'o+', 'engineer', 'East Holudia', '7', 'chikon chora', 'vuzpur', 'fatik chori', 'chittagong', 'nv6sUZs3MCLjh37F40REU7ELQsOVLYtrdmUBkQuafsVCvIui1bIQ2Okx5Idh', NULL, '2024-06-26 19:10:13');

-- --------------------------------------------------------

--
-- Table structure for table `welcome_areas`
--

CREATE TABLE `welcome_areas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `heading` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `welcome_areas`
--

INSERT INTO `welcome_areas` (`id`, `heading`, `link`, `created_at`, `updated_at`) VALUES
(1, 'আমরা বিশেষ সুবিধা সম্বিলিত  সুধ মুক্ত বিজনেস পরিচালনা করে থাকি।', '#', '2024-06-09 12:14:59', '2024-06-27 04:17:17');

-- --------------------------------------------------------

--
-- Table structure for table `work_processes`
--

CREATE TABLE `work_processes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `work_processes`
--

INSERT INTO `work_processes` (`id`, `title`, `short_description`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'আলোচনা', 'Godard pabst prism fam cliche.', 'uploads/work/work-process-item-01.png', '2024-06-09 12:14:59', NULL),
(2, 'সংশোধন', 'Godard pabst prism fam cliche.', 'uploads/work/work-process-item-01.png', '2024-06-09 12:14:59', NULL),
(3, 'অনুমোদন', 'Godard pabst prism fam cliche.', 'uploads/work/work-process-item-01.png', '2024-06-09 12:14:59', NULL),
(4, 'আরম্ভ', 'Godard pabst prism fam cliche.', 'uploads/work/work-process-item-01.png', '2024-06-09 12:14:59', NULL),
(5, 'ডেপলয়', 'Godard pabst prism fam cliche.', 'uploads/work/work-process-item-01.png', '2024-06-09 12:14:59', NULL),
(6, 'সাপোর্ট', 'Godard pabst prism fam cliche.', 'uploads/work/work-process-item-01.png', '2024-06-09 12:14:59', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_payment_getways`
--
ALTER TABLE `bank_payment_getways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dues`
--
ALTER TABLE `dues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `featured_areas`
--
ALTER TABLE `featured_areas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `funds`
--
ALTER TABLE `funds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invests`
--
ALTER TABLE `invests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobile_payment_getways`
--
ALTER TABLE `mobile_payment_getways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shares`
--
ALTER TABLE `shares`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `welcome_areas`
--
ALTER TABLE `welcome_areas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_processes`
--
ALTER TABLE `work_processes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bank_payment_getways`
--
ALTER TABLE `bank_payment_getways`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dues`
--
ALTER TABLE `dues`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `featured_areas`
--
ALTER TABLE `featured_areas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `funds`
--
ALTER TABLE `funds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `invests`
--
ALTER TABLE `invests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `mobile_payment_getways`
--
ALTER TABLE `mobile_payment_getways`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `shares`
--
ALTER TABLE `shares`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `welcome_areas`
--
ALTER TABLE `welcome_areas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `work_processes`
--
ALTER TABLE `work_processes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
