<?php

namespace App\Jobs;

use App\Mail\PaymentMail;
use App\Models\Document;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class ProcessFundDocument implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $name;
    protected $amount;
    protected $month;
    protected $updated_total_fund;
    protected $email;
    protected $userId;
    protected $path;
    protected $fileName;

    public function __construct($name, $amount, $month, $updated_total_fund, $email, $userId, $path, $fileName)
    {
        $this->name = $name;
        $this->amount = $amount;
        $this->month = $month;    // Make sure this is set
        $this->updated_total_fund = $updated_total_fund;
        $this->email = $email;
        $this->userId = $userId;
        $this->path = $path;
        $this->fileName = $fileName;
    }



    public function handle()
    {
        try {
            // Generate and save PDF
            $pdf = PDF::loadView('admins.users.document', [
                'name' => $this->name,
                'amount' => $this->amount,
                'month' => $this->month,
                'updated_total_fund' => $this->updated_total_fund,
            ])
            ->setPaper('a4')
            ->setWarnings(false);

            $pdf->save(public_path($this->path.$this->fileName));

            // Create document record
            Document::insert([
                'user_id' => $this->userId,
                'title' => 'Fund Added',
                'file' => $this->path.$this->fileName,
                'created_at' => Carbon::now()
            ]);
             // Send email with debug check
            if (!isset($this->month)) {
                throw new \Exception('Month is not set before sending email');
            }
            // Send email
            Mail::to($this->email)->send(new PaymentMail(
                $this->name,
                $this->amount,
                $this->month,
                $this->updated_total_fund
            ));
        } catch (\Exception $e) {
            \Log::error('Fund document processing failed: ' . $e->getMessage());
        }
    }
}
