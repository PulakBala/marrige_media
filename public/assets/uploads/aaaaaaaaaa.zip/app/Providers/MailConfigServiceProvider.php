<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use Config;

class MailConfigServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $setting = DB::table('settings')->find(1);
        $transport = $setting->mail_transport;
        $mail_host = $setting->mail_host;
        $mail_port = $setting->mail_port;
        $mail_encryption = $setting->mail_encryption;
        $mail_username = $setting->mail_username;
        $mail_password = $setting->mail_password;
        $mail_from = $setting->mail_from;
        $mail_from_name = $setting->mail_from_name;
        $data = [
            'driver' => $transport,
            'host' => $mail_host,
            'port' => $mail_port,
            'encryption' => $mail_encryption,
            'username' => $mail_username,
            'password' => $mail_password,
            'from' => [
                'address' => $mail_from,
                'name' =>$mail_from_name
            ],
        ];

        Config::set('mail', $data);
    }
}
