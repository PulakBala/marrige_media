<?php

namespace App\Http\Controllers;

use App\Models\About;
use App\Models\FeaturedArea;
use App\Models\Page;
use App\Models\Team;
use App\Models\WelcomeArea;
use App\Models\WorkProcess;
use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index() {
        $welcome = WelcomeArea::where('id', 1)->first();
        $featureds = FeaturedArea::all();
        $about = About::where('id', 1)->first();
        $teams = Team::all();
        $works = WorkProcess::all();
        return view('welcome', compact('teams', 'about', 'works', 'welcome', 'featureds'));
    }

    public function privacyPolicy() {
        $data = Page::where('id', 1)->first();
        return view('page', compact('data'));
    }
    public function tramsAndCondition() {
        $data = Page::where('id', 2)->first();
        return view('page', compact('data'));
    }
    public function dmca() {
        $data = Page::where('id', 3)->first();
        return view('page', compact('data'));
    }
}
