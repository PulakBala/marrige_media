<?php

namespace App\Http\Controllers\Socialite;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Str;

class GoogleController extends Controller
{
    public function updateCredentials(Request $request)
    {
        $request->validate([
            '*' => 'required',
            'google_client_id' => 'required',
            'google_client_secret' => 'required',
        ],[
            'google_client_id.required' => 'The google client id field is required.',
            'google_client_secret.required' => 'The google client secret field is required.',
        ]);
        $credentials = $request->googleCredentials;
        foreach($credentials as $name){
            Setting::where('name', $name)->update([
                'value' => $request->$name
            ]);
        }
        return back()->with('success', 'Updated Successfully');
    }

    public function updateGoogleSwitch(Request $request)
    {
        if(setting('google_client_id') != null && setting('google_client_secret') != null)
        {
            $updateGoogleSwitch = Setting::where('name', $request->value)->update([
                'value' => $request->status
            ]);
            if($updateGoogleSwitch)
            {
                echo 1;
            }
            else
            {
                echo 0;
            }
        }
        else
        {
            echo 0;
        }
    }

    public function googleRedirect()
    {
        return Socialite::driver('google')->redirect();
    }
    public function googleCallback()
    {
        $user = Socialite::driver('google')->user();
        $name = $user->getName();
        $email = $user->getEmail();
        $providerId = $user->id;
        $password = 'klsdf*(^654jkd654&(987534998+-*/65983kjdflsGSLKFoisdlfj';
        $getUserDetails = User::where('email', $user->getEmail())->first();
        if($getUserDetails)
        {
            $password = $getUserDetails->password;
            Auth::login($getUserDetails);
            return redirect()->route('home');
        }
        else
        {
            $login_info = User::create([
                'name' => $name,
                'email' => $email,
                'email_verified_at' => Carbon::now(),
                'provider' => 'google',
                'provider_id' => $providerId,
                'password' => Hash::make($password)
            ]);
            Auth::login($login_info);
            return redirect()->route('home');
        }
    }


}
