<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Share;
use Carbon\Carbon;
use Illuminate\Http\Request;

class UserShareController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = Share::where([['user_id', auth()->user()->id], ['status', 'accept']])->get();
        return view('users.share.index', compact('datas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.share.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required | string | max:255'
        ]);
        Share::insert([
            'user_id' => auth()->user()->id,
            'name' => $request->name,
            'amount' => 2000,
            'created_at' => Carbon::now()
        ]);
        return redirect()->route('share.index')->with('success', 'Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Share::where([['id', $id], ['user_id', auth()->user()->id]])->first();
        return view('users.share.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = Share::where([['id', $id], ['user_id', auth()->user()->id]])->first();
        $request->validate([
            'name' => 'required | string | max:255'
        ]);
        $data->update([
            'name' => $request->name
        ]);
        return redirect()->route('share.index')->with('success', 'Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Share::where([['id', $id], ['user_id', auth()->user()->id]])->first();
        $data->update([
            'status' => 'deactive'
        ]);
        return back()->with('success', 'Deleted Successfully');
    }
}
