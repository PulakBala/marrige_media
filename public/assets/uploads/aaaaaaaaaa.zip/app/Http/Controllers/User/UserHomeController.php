<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Due;
use App\Models\Invest;
use App\Models\User;
use Illuminate\Http\Request;

class UserHomeController extends Controller
{
    public function index()
    {
        $oldUser = User::orderBy('id', 'DESC')->skip(1)->first();

        $currentUser = User::where('id', auth()->user()->id)->first();
        if (!$currentUser->profile_id) {
            $currentUser->update([
                'profile_id' => $oldUser->profile_id + 1
            ]);
        }

        $totlaInvest = Invest::sum('amount');
        $totlaInvestProfit = Invest::sum('profit');
        $totalDue = Due::where('user_id', auth()->user()->id)->sum('amount');
        return view('users.index', compact('totlaInvest', 'totlaInvestProfit', 'totalDue'));
    }

    public function form() {
        return view('users.form');
    }

    public function update(Request $request) {
        $request->validate([
            'father_name' => 'required | string | max:255',
            'mother_name' => 'required | string | max:255',
            'phone_number' => 'required | string | max:255',
            'education_qualification' => 'required | string | max:255',
            'passport_or_nid_number' => 'required | string | max:255',
            'religion' => 'required | string | max:255',
            'date_of_birth' => 'required | date',
            'nationality' => 'required | string | max:255',
            'blood_group' => 'required | string | max:255',
            'occupation' => 'required | string | max:255',
            'village' => 'required | string | max:255',
            'word_no' => 'required | string | max:255',
            'post_office' => 'required | string | max:255',
            'thana' => 'required | string | max:255',
            'upzilla' => 'required | string | max:255',
            'district' => 'required | string | max:255',
        ]);
        $user = User::where('id', auth()->user()->id)->first();
        $user->update([
            'father_name' => $request->father_name,
            'mother_name' => $request->mother_name,
            'phone_number' => $request->phone_number,
            'education_qualification' => $request->education_qualification,
            'passport_or_nid_type' => $request->passport_or_nid_type,
            'passport_or_nid_number' => $request->passport_or_nid_number,
            'religion' => $request->religion,
            'date_of_birth' => $request->date_of_birth,
            'nationality' => $request->nationality,
            'blood_group' => $request->blood_group,
            'occupation' => $request->occupation,
            'village' => $request->village,
            'word_no' => $request->word_no,
            'post_office' => $request->post_office,
            'thana' => $request->thana,
            'upzilla' => $request->upzilla,
            'district' => $request->district,
        ]);
        return back()->with('success', 'Updated Successfully');
    }
}
