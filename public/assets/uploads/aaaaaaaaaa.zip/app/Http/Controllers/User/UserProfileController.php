<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserProfileController extends Controller
{
    public function index()
    {
        return view('users.profiles.index');
    }

    public function updateProfile(Request $request)
    {
        $request->validate([
            'name' => 'required | string | min:3 | max: 60',
            'profile' => 'image|mimes:jpeg,png,jpg|max:10000'
        ]);
        if ($request->hasFile('profile')) {
            $oldFile = explode('/', auth()->user()->profile);
            $img = end($oldFile);

            if ($img != 'profile-img.png') {
                unlink(auth()->user()->profile);
            }

            $file = $request->file('profile');
            $fileName = time().'-profile-image.'.$file->getClientOriginalExtension();
            $path = 'uploads/profile/';
            $request->profile->move($path, $fileName);
            User::where('id', auth()->user()->id)->update([
                'profile' => $path.$fileName
            ]);
        }

        User::where('id', auth()->user()->id)->update([
            'name' => $request->name
        ]);

        return back()->with('success', 'Updated Successfully');
    }

    public function updateEmail(Request $request)
    {
        $request->validate([
            'email' => 'required | email | unique:users'
        ]);
        User::where('id', auth()->id())->update([
            'email' => $request->email
        ]);
        return response()->json('done');
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'newpass' => 'required|min:8',
            'conpass' => 'required'
        ],[
            'newpass.required' => 'The new password field is required.',
            'newpass.min' => 'The new password must be 8 charecters.',
            'conpass.required' => 'The confirm password field is required.',
        ]);
        if($request->newpass == $request->conpass)
        {
            User::where('id', auth()->id())->update([
                'password' => Hash::make($request->newpass)
            ]);
            return response()->json('success');
        }
        else
        {
            return response()->json('error');
        }
    }
}
