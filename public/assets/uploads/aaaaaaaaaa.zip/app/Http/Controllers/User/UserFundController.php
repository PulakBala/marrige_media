<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\BankPaymentGetway;
use App\Models\Due;
use App\Models\Fund;
use App\Models\MobilePaymentGetway;
use App\Models\Share;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class UserFundController extends Controller
{
    public function index() {
        $mgetways = MobilePaymentGetway::select('id', 'account_name', 'logo')->get();
        $bgetways = BankPaymentGetway::select('id', 'bank_name', 'logo')->get();
        return view('users.fund.index', compact('mgetways', 'bgetways'));
    }

    public function create($name, $id, $type) {
        $id = Crypt::decrypt($id);
        $share = Share::where([['user_id', auth()->user()->id], ['status', 'accept']])->count();
        if ($share < 1) {
            return redirect()->route('share.create')->with('error', 'Please add a share');
        }
        if ($type == 'mobile-banking') {
            $getway = MobilePaymentGetway::where('id', $id)->first();
        }elseif($type == 'bank-details'){
            $getway = BankPaymentGetway::where('id', $id)->first();
        }
        return view('users.fund.create', compact('getway', 'type', 'share'));
    }

    public function store(Request $request) {
        $request->validate([
            'month' => 'required | string | max:255',
            'year' => 'required | string | max:255',
            'getway_id' => 'required | numeric',
            'type' => 'required',
            'share' => 'required | numeric',
            'sender_number' => 'required',
            'transaction_id' => 'required',
            'payment_status' => 'required'
        ]);
        $amount = $request->share * 2000;
        Fund::insert([
            'user_id' => auth()->user()->id,
            'getway_id' => $request->getway_id,
            'type' => $request->type,
            'sender_number' => $request->sender_number,
            'amount' => $amount,
            'trx_id' => $request->transaction_id,
            'month' => $request->month,
            'year' => $request->year,
            'payment_status' => $request->payment_status,
            'created_at' => Carbon::now()
        ]);
        return redirect()->route('user.fund.index')->with('success', 'Submited Successfully');
    }

    public function history() {
        $datas = Fund::where('user_id', auth()->user()->id)->orderBy('id', 'DESC')->get();
        return view('users.fund.history', compact('datas'));
    }

    public function due() {
        $datas = Due::where('user_id', auth()->user()->id)->get();
        return view('users.fund.due',compact('datas'));
    }
}
