<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Document;
use Illuminate\Http\Request;

class UserDocumentController extends Controller
{
    public function index() {
        $datas = Document::where('user_id', auth()->user()->id)->orderBy('id', 'DESC')->get();
        return view('users.document.index', compact('datas'));
    }
}
