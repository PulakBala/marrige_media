<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Due;
use App\Models\Fund;
use App\Models\Document;
use App\Models\Share;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Barryvdh\DomPDF\Facade\Pdf;
use App;

class AdminUserController extends Controller
{
    public function index()
    {
        $users = User::where('role', 'user')->get();
        return view('admins.users.index', compact('users'));
    }
    public function edit($id)
    {
        $user = User::where('id', $id)->first();
        return view('admins.users.edit', compact('user'));
    }
    public function create()
    {
        return view('admins.users.create');
    }

    public function store(Request $request) {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'email_verified_at' => Carbon::now(),
            'password' => 'required|string|min:8|confirmed',
            'created_at' => Carbon::now(),
        ]);

        if ($request->hasFile('avatar')) {
            $file = $request->file('avatar');
            $fileName = time().'-profile-image.'.$file->getClientOriginalExtension();
            $path = 'uploads/profile/';
            $request->avatar->move($path, $fileName);
        }
        $oldUser = User::orderBy('id', 'DESC')->first();

        User::insert([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'profile_id' => $oldUser->profile_id + 1,
            'profile' => $request->hasFile('avatar') ? $path.$fileName : 'uploads/profile/profile-img.png',
        ]);
        return back()->with('success', 'Created Successfully');
    }

    public function update(Request $request, $id) {
        $user = User::where('id', $id)->first();
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,'.$user->id.',id',
            'father_name' => 'required|string|max:255',
            'mother_name' => 'required|string|max:255',
            'phone_number' => 'required|max:15',
            'education_qualification' => 'required|string|max:255',
            'passport_or_nid_number' => 'required|string|max:255',
            'religion' => 'required|string|max:255',
            'date_of_birth' => 'required',
            'nationality' => 'required|string|max:255',
            'blood_group' => 'required|string|max:255',
            'occupation' => 'required|string|max:255',
            'village' => 'required|string|max:255',
            'word_no' => 'required|min:1',
            'post_office' => 'required|string|max:255',
            'thana' => 'required|string|max:255',
            'upzilla' => 'required|string|max:255',
            'district' => 'required|string|max:255',
            'password' => 'required|string|min:8|confirmed',
            'avatar' => 'image | mimes:jpg,png,jpeg'
        ]);

        if ($request->hasFile('avatar')) {
            $arr = explode('/', $user->profile);
            $oldImg = end($arr);
            if ($oldImg != 'profile-img.png') {
                unlink(base_path($user->profile));
            }
            $file = $request->file('avatar');
            $fileName = time().'-profile-image.'.$file->getClientOriginalExtension();
            $path = 'uploads/profile/';
            $request->profile->move($path, $fileName);

            $user->update([
                'profile' => $path.$fileName
            ]);
        }
        $oldUser = User::orderBy('id', 'DESC')->first();

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'father_name' => $request->father_name,
            'mother_name' => $request->mother_name,
            'phone_number' => $request->phone_number,
            'education_qualification' => $request->education_qualification,
            'passport_or_nid_number' => $request->passport_or_nid_number,
            'religion' => $request->religion,
            'date_of_birth' => $request->date_of_birth,
            'nationality' => $request->nationality,
            'blood_group' => $request->blood_group,
            'occupation' => $request->occupation,
            'village' => $request->village,
            'word_no' => $request->word_no,
            'post_office' => $request->post_office,
            'thana' => $request->thana,
            'upzilla' => $request->upzilla,
            'district' => $request->district,
            'password' => Hash::make($request->password),
            'profile_id' => $oldUser->profile_id + 1,
            'profile' => $request->hasFile('avatar') ? $path.$fileName : 'uploads/profile/profile-img.png',
        ]);


        return back()->with('success', 'Updated Successfully');
    }

    public function details($id) {
        $user = User::where('id', $id)->first();
        $datas = Fund::where('user_id', $user->id)->get();
        return view('admins.users.details', compact('user', 'datas'));
    }

    function addFund(Request $request, $id) {
        $request->validate([
            'amount' => 'required | numeric | min:1'
        ]);

        $user = User::where('id', $id)->first();
        $user->increment('total_fund', $request->amount);
        $user->decrement('total_due', $request->amount);
        return back()->with('success', 'Fund Added Successfully');
    }


    public function addDue(Request $request, $id) {
        $request->validate([
            'month' => 'required | string | max:255',
            'year' => 'required | string | max:255'
        ]);
        $dueExists = Due::where([['user_id', $id], ['month', $request->month], ['year', $request->year]])->exists();
        if ($dueExists) {
            return back()->with('error', 'Alerady added due list');
        }
        $user = User::where('id', $id)->first();
        $share = Share::where([['user_id', $id], ['status', 'accept']])->count();
        $amount = 2000 * $share;
        Due::insert([
            'user_id' => $id,
            'month' => $request->month,
            'year' => $request->year,
            'amount' => $amount,
            'created_at' => Carbon::now()
        ]);
        $user->increment('total_due', $amount);
        return back()->with('success', 'Added Successfully');
    }

    public function dueShow($id) {
        $datas = Due::where('user_id', $id)->get();
        return view('admins.users.due', compact('datas'));
    }

    public function delete($id){
       
        
        $due = Due::where('user_id', $id)->get();
         
         
         if ($due->isNotEmpty()) {
    foreach ($due as $item) {
        $item->delete();
    }
}
        
        $datas = Fund::where('user_id', $id)->get();
        
       if ($datas->isNotEmpty()) {
    foreach ($datas as $item1) {
        $item1->delete();
    }
}  
         
        $data = Document::where('user_id', $id)->get();
          
          if ($data->isNotEmpty()) {
    foreach ($data as $item14) {
        
         unlink(base_path($item14->file));
        $item14->delete();
    }
} 
        
        $share = Share::where('user_id', $id)->get();
        
        
         
          if ($share->isNotEmpty()) {
    foreach ($share as $item2) {
        $item2->delete();
    }
}  
         
        $user = User::where('id', $id)->first();
        $oldFile = explode('/', $user->profile);
        $img = end($oldFile);

        if ($img != 'profile-img.png') {
            unlink($user->profile);
        }
        
       
        $user->delete();
       
        return back()->with('success', 'Deleted Successfully');
    }

    public function deleteDue($id) {
        $data = Due::where('id', $id)->first();
        $user = User::where('id', $data->user_id)->first();
        $user->decrement('total_due', $data->amount);
        $data->delete();
        return back()->with('success', 'Deleted Successfully');
    }

    public function downloadDetails($id) {
        $user = User::where('id', $id)->first();
        $pdf = PDF::loadView('admins.users.download-details', [
            'data' => $user,
            'share' => Share::where('user_id', $user->id)->count()
        ])->setPaper('a4');
        return $pdf->download($user->name.'-user-details.pdf');
    }

    public function emailVerified($id) {
        $user = User::where('id', $id)->first();
        $user->update([
            'email_verified_at' => Carbon::now()
        ]);
        return back()->with('success', 'Verified Successfully');
    }
}
