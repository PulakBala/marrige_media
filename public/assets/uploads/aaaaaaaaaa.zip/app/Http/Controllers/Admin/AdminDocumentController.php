<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminDocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = Document::orderBy('id', 'DESC')->get();
        return view('admins.documents.index', compact('datas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::where('role', 'user')->select('id', 'name', 'profile_id')->get();
        return view('admins.documents.create', compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'user' => 'required',
            'title' => 'required | string | max:255',
            'file' => 'required'
        ]);

        $file = $request->file('file');
        $fileName = time().'-profile-image.'.$file->getClientOriginalExtension();
        $path = 'uploads/documents/';
        $request->file->move($path, $fileName);

        Document::insert([
            'user_id' => $request->user,
            'title' => $request->title,
            'file' => $path.$fileName,
            'created_at' => Carbon::now()
        ]);
        return redirect()->route('document.index')->with('success', 'Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return abort(404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return abort(404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Document::where('id', $id)->first();
        unlink(base_path($data->file));
        $data->delete();
        return back()->with('success', 'Deleted Successfully');
    }
}
