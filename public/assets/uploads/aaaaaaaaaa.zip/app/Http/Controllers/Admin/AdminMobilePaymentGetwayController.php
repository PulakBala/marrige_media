<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MobilePaymentGetway;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminMobilePaymentGetwayController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $getways = MobilePaymentGetway::all();
        return view('admins.mobile-getway.index', compact('getways'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admins.mobile-getway.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'account_name' => 'required | string | max:255 | unique:mobile_payment_getways',
            'account_number' => 'required | string | min:11 | max:11',
            'account_type' => 'required | string | max:255',
            'logo' => 'required | image | mimes:jpg,png,jpeg',
        ]);

        $file = $request->file('logo');
        $fileName = time().'-payment-getway.'.$file->getClientOriginalExtension();
        $path = 'uploads/payment-getway/';
        // $request->logo->move($path, $fileName);
        $request->logo->move(public_path($path), $fileName);


        MobilePaymentGetway::insert([
            'account_name' => $request->account_name,
            'account_number' => $request->account_number,
            'account_type' => $request->account_type,
            'logo' => $path.$fileName,
            'created_at' => Carbon::now()
        ]);
        return redirect()->route('mobile-payment-getway.index')->with('success', 'Created Successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $getway = MobilePaymentGetway::where('id', $id)->first();
        return view('admins.mobile-getway.edit', compact('getway'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $getway = MobilePaymentGetway::where('id', $id)->first();
        $request->validate([
            'account_name' => 'required | string | max:255 | unique:mobile_payment_getways,account_name,'.$getway->id.',id',
            'account_number' => 'required | string | min:11 | max:11',
            'account_type' => 'required | string | max:255',
            'logo' => 'image | mimes:jpg,png,jpeg',
        ]);
        if ($request->hasFile('logo')) {
            unlink(base_path($getway->logo));
            $file = $request->file('logo');
            $fileName = time().'-payment-getway.'.$file->getClientOriginalExtension();
            $path = 'uploads/payment-getway/';
            $request->logo->move(public_path($path), $fileName);
            $getway->update([
                'logo' => $path.$fileName,
            ]);
        }

        $getway->update([
            'account_name' => $request->account_name,
            'account_number' => $request->account_number,
            'account_type' => $request->account_type
        ]);
        return redirect()->route('mobile-payment-getway.index')->with('success', 'Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $getway = MobilePaymentGetway::where('id', $id)->first();
        unlink(base_path($getway->logo));
        $getway->delete();
        return back()->with('success', 'Deleted Successfully');
    }
}
