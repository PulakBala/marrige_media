<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\PaymentMail;
use App\Models\Document;
use App\Models\Due;
use App\Models\Fund;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Jobs\ProcessFundDocument;

class AdminFundController extends Controller
{
    public function pending() {
        $datas = Fund::where('status', 'pending')->orderBy('id', 'DESC')->get();
        return view('admins.fund.index', compact('datas'));
    }
    public function approved() {
        $datas = Fund::where('status', 'approved')->orderBy('id', 'DESC')->get();
        return view('admins.fund.index', compact('datas'));
    }
    public function rejected() {
        $datas = Fund::where('status', 'rejected')->orderBy('id', 'DESC')->get();
        return view('admins.fund.index', compact('datas'));
    }

    public function cashPayment() {
        $users = User::where('role', 'user')->get();
        return view('admins.fund.cash', compact('users'));
    }

    // public function cashPaymentStore(Request $request) {

    //     $request->validate([
    //         'user' => 'required | numeric',
    //         'amount' => 'required | numeric | min:2000',
    //         'payment_status' => 'required'
    //     ]);

    //     $data = Fund::insertGetId([
    //         'user_id' => $request->user,
    //         'getway_id' => 0,
    //         'amount' => $request->amount,
    //         'trx_id' => 'N/A',
    //         'type' => 'cash',
    //         'month' => $request->month,
    //         'year' => $request->year,
    //         'status' => 'approved',
    //         'payment_status' => $request->payment_status,
    //         'created_at' => Carbon::now()
    //     ]);
    //     $user = User::where('id', $request->user)->first();
    //     $name = $user->name;
    //     $amount = $request->amount;


    //     if ($request->payment_status == 'due') {
    //         $due = Due::where([['user_id', $user->id], ['month', $request->month], ['year', $request->year]])->first();
    //         $user->decrement('total_due', $amount);
    //         $due->delete();
    //     }

    //     $user->increment('total_fund', $amount);
    //     $path = '/uploads/documents/';

    //     $fileName = $user->id.rand(00000000,999999999).rand(00000000,999999999).'.pdf';
    //     // dd($fileName);

    //     // $pdf = PDF::loadView('admins.users.document', [
    //     //     'name' => $name,
    //     //     'amount' => $amount,
    //     // ])->save(base_path($path.$fileName));
    //     // dd($pdf);
    //     // // return $pdf->download($user->name.'-user-details.pdf');


    //     // Document::insert([
    //     //     'user_id' => $user->id,
    //     //     'title' => 'Fund Added',
    //     //     'file' => $path.$fileName,
    //     //     'created_at' => Carbon::now()
    //     // ]);
    //     // Mail::to($user->email)->send(new PaymentMail($name, $amount));
    //     // return back()->with('success', 'Updated Successfully');
    //     try {
    //         // Set PDF options to optimize performance
    //         $pdf = PDF::loadView('admins.users.document', [
    //             'name' => $name,
    //             'amount' => $amount,
    //         ])
    //         ->setPaper('a4')
    //         ->setWarnings(false);

    //         // Save PDF
    //         // dd($pdf);
    //         // $pdf->save(public_path($path.$fileName));

    //         Document::insert([
    //             'user_id' => $user->id,
    //             'title' => 'Fund Added',
    //             'file' => $path.$fileName,
    //             'created_at' => Carbon::now()
    //         ]);

    //         Mail::to($user->email)->send(new PaymentMail($name, $amount));
    //         return back()->with('success', 'Updated Successfully');
    //     } catch (\Exception $e) {
    //         return back()->with('error', 'Error generating document: ' . $e->getMessage());
    //     }

    //     return back()->with('success', 'Added Successfully');
    // }

    public function cashPaymentStore(Request $request) {
        $request->validate([
            'user' => 'required | numeric',
            'amount' => 'required | numeric | min:2000',
            'payment_status' => 'required'
        ]);

        $data = Fund::insertGetId([
            'user_id' => $request->user,
            'getway_id' => 0,
            'amount' => $request->amount,
            'trx_id' => 'N/A',
            'type' => 'cash',
            'month' => $request->month,
            'year' => $request->year,
            'status' => 'approved',
            'payment_status' => $request->payment_status,
            'created_at' => Carbon::now()
        ]);

        $user = User::where('id', $request->user)->first();
        $name = $user->name;
        $amount = $request->amount;
        $month  = $request->month;

        if ($request->payment_status == 'due') {
            $due = Due::where([['user_id', $user->id], ['month', $request->month], ['year', $request->year]])->first();
            $user->decrement('total_due', $amount);
            $due->delete();
        }

        $total_fund = $user->increment('total_fund', $amount);
        $updated_total_fund = $user->fresh()->total_fund;

        // dd($updated_total_fund);

        // Prepare file details
        $path = 'uploads/documents/';
        $fileName = $user->id.rand(00000000,999999999).rand(00000000,999999999).'.pdf';

        // Dispatch job to process document and send email
        ProcessFundDocument::dispatch(
            $name,
            $amount,
            $month,
            $updated_total_fund,
            $user->email,
            $user->id,
            $path,
            $fileName,
        );

        return back()->with('success', 'Fund added successfully. Document will be processed shortly.');
    }

    public function approvedStatus($id) {
        $data = Fund::where('id', $id)->first();
        $data->update([
            'status' => 'approved'
        ]);
        $user = User::where('id', $data->user_id)->first();
        $name = $user->name;
        $amount = $data->amount;
        $month = $user->month;
        if ($data->payment_status == 'due') {
            $due = Due::where([['user_id', $data->user_id], ['month', $data->month], ['year', $data->year]])->first();
            $user->decrement('total_due', $amount);
            $due->delete();
        }
        $user->increment('total_fund', $amount);
        $updated_total_fund = $user->fresh()->total_fund; // Updated total fund
        
        //  $path = 'uploads/documents/';
       
       
           // Correct Path for Public Folder
    $path = ('uploads/documents/');

    // Check if folder exists, otherwise create it
    // if (!file_exists($path)) {
    //     mkdir($path, 0777, true);
    // }
    
    
    
    
    
    
    
        $fileName = $user->id.rand(00000000,999999999).rand(00000000,999999999).'.pdf';

        $pdf = PDF::loadView('admins.users.document', [
            'name' => $name,
            'amount' => $amount,
            'month' => $month,
            'updated_total_fund' =>  $updated_total_fund,
        ])->save(base_path($path.$fileName));
        // return $pdf->download($user->name.'-user-details.pdf');


        Document::insert([
            'user_id' => $data->user_id,
            'title' => 'Fund Added',
            'file' => $path.$fileName,
            'created_at' => Carbon::now()
        ]);
        Mail::to($user->email)->send(new PaymentMail($name, $amount, $month, $updated_total_fund));
        return back()->with('success', 'Updated Successfully');
    }

    public function rejectedStatus($id) {
        $data = Fund::where('id', $id)->first();
        $data->update([
            'status' => 'rejected'
        ]);
        return back()->with('success', 'Updated Successfully');
    }


    public function deleteStatus($id) {
        $data = Fund::where('id', $id)->first();
        $data->delete();
        return back()->with('success', 'Deleted Successfully');
    }
}
