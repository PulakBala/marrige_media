<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Share;
use Illuminate\Http\Request;

class AdminShareController extends Controller
{
    public function index() {
        $datas = Share::orderBy('created_at', 'DESC')->where('status', 'pending')->get();
        return view('admins.share.index', compact('datas'));
    }

    public function acceptStatus($id) {
        $data = Share::where('id', $id)->first();
        $data->update([
            'status' => 'accept'
        ]);
        return back()->with('success', 'Accept Successfully');
    }

    public function rejectedStatus($id) {
        $data = Share::where('id', $id)->first();
        $data->update([
            'status' => 'rejected'
        ]);
        return back()->with('success', 'Rejected Successfully');
    }

    public function delete($id) {
        $data = Share::where('id', $id)->first();
        $data->delete();
        return back()->with('success', 'Deleted Successfully');
    }

    public function getShareAmount(Request $request) {
        $user_id = $request->userId;
        $amount = 2000 * getShare($user_id);
        return response()->json($amount);
    }
}
