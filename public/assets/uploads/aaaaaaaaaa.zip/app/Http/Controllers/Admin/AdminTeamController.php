<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Team;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminTeamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = Team::all();
        return view('admins.team.index', compact('datas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admins.team.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required | string | max:255',
            'title' => 'required | string | max:255',
            'image' => 'required | image | mimes:jpg,png,jpeg'
        ]);

        $file = $request->file('image');
        $filaName = time().'-image.'.$file->getClientOriginalExtension();
        $path = 'uploads/team/';
        $request->image->move($path, $filaName);

        Team::insert([
            'name' => $request->name,
            'title' => $request->title,
            'fb_link' => $request->facebook_url,
            'tw_link' => $request->twitter_url,
            'ins_link' => $request->instagram_url,
            'image' => $path.$filaName,
            'created_at' => Carbon::now()
        ]);
        return back()->with('success', 'Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Team::where('id', $id)->first();
        return view('admins.team.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required | string | max:255',
            'title' => 'required | string | max:255',
            'image' => 'image | mimes:jpg,png,jpeg'
        ]);
        $data = Team::where('id', $id)->first();
        if ($request->hasFile('image')) {
            unlink(base_path($data->image));
            $file = $request->file('image');
            $filaName = time().'-image.'.$file->getClientOriginalExtension();
            $path = 'uploads/team/';
            $request->image->move($path, $filaName);
            $data->update([
                'image' => $path.$filaName
            ]);
        }


        $data->update([
            'name' => $request->name,
            'title' => $request->title,
            'fb_link' => $request->facebook_url,
            'tw_link' => $request->twitter_url,
            'ins_link' => $request->instagram_url
        ]);
        return redirect()->route('team.index')->with('success', 'Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Team::where('id', $id)->first();
        unlink(base_path($data->image));
        $data->delete();
        return back()->with('success', 'Delete Successfully');
    }
}
