<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\About;
use App\Models\WelcomeArea;
use Illuminate\Http\Request;

class AdminAboutController extends Controller
{
    public function index() {
        $data = About::where('id', 1)->first();
        return view('admins.about.edit', compact('data'));
    }

    public function update(Request $request) {
        $request->validate([
            'heading' => 'required | string | max:255',
            'description' => 'required | string',
            'image' => 'image | mimes:jpg,png,jpeg'
        ]);
        $data = About::where('id', 1)->first();
        if ($request->hasFile('image')) {
            $oldFile = explode('/', $data->image);
            $img = end($oldFile);
            if ($img != 'left-image.png') {
                unlink(base_path($data->image));
            }
            $file = $request->file('image');
            $filaName = time().'-image.'.$file->getClientOriginalExtension();
            $path = 'uploads/about/';
            $request->image->move($path, $filaName);
            $data->update([
                'image' => $path.$filaName
            ]);
        }
        $data->update([
            'heading' => $request->heading,
            'description' => $request->description,
        ]);
        return back()->with('success', 'Updated Successfully');
    }

    public function welcome() {
        $data = WelcomeArea::where('id', 1)->first();
        return view('admins.welocme.index', compact('data'));
    }

    public function welcomeUpdate(Request $request) {
        $request->validate([
            'heading' => 'required | string | max:255',
            'link' => 'required'
        ]);
        $data = WelcomeArea::where('id', 1)->first();
        $data->update([
            'heading' => $request->heading,
            'link' => $request->link
        ]);
        return back()->with('success', 'Updated Successfully');
    }
}
