<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Due;
use App\Models\Fund;
use App\Models\Invest;
use App\Models\Share;
use App\Models\User;
use Illuminate\Http\Request;

class AdminHomeController extends Controller
{
    public function index()
    {
        $totalUsers = User::where('role', 'user')->count();
        $shareRequest = Share::where('status', 'pending')->count();
        $paymentRequest = Fund::where('status', 'pending')->count();
        $totalFund = User::sum('total_fund');
        $totalDue = Due::sum('amount');
        $totalInvest = Invest::sum('amount');
        $totalInvestProfit = Invest::sum('profit');
        return view('admins.index', compact('totalUsers', 'shareRequest', 'paymentRequest', 'totalFund', 'totalDue', 'totalInvest', 'totalInvestProfit'));
    }
}
