<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;

class AdminSettingController extends Controller
{
    public function index()
    {
        return view('admins.settings.index');
    }
    public function updateSetting(Request $request)
    {
        $request->validate([
            'title' => 'required | string | min:3 | max:200',
            'logo' => 'image|mimes:jpeg,png,jpg|max:15000',
            'favicon' => 'image|mimes:jpeg,png,jpg|max:15000'
        ]);
        if($request->hasFile('logo')){
            $oldLogo = explode('/', setting('logo'));
            $logo = end($oldLogo);
            if($logo != 'default-logo.png')
            {
                unlink(setting('logo'));
            }


            $file = $request->file('logo');
            $logoName = time().'-logo.'.$file->getClientOriginalExtension();
            $logoPath = 'uploads/default/';
            $request->logo->move($logoPath, $logoName);


            // $logoName = time().Str::random(5).'.'.$request->file('logo')->getClientOriginalExtension();
            // $logoPath = 'uploads/default/';
            // Image::make($request->file('logo'))->save($logoPath.$logoName);

            Setting::where('name', 'logo')->update([
                'value' => $logoPath.$logoName,
            ]);
        }

        if($request->hasFile('favicon')){

            $oldFav = explode('/', setting('favicon'));
            $fav = end($oldFav);

            if($fav != 'default-favicon.png')
            {
                unlink(setting('favicon'));
            }
            $file = $request->file('favicon');
            $favIconName = time().'-favicon.'.$file->getClientOriginalExtension();
            $favPath = 'uploads/default/';
            $request->favicon->move($favPath, $favIconName);


            Setting::where('name', 'favicon')->update([
                'value' => $favPath.$favIconName,
            ]);
        }
        Setting::where('name', 'title')->update([
            'value' => $request->title
        ]);
        return back()->with('success', 'Updated Successfully');
    }

    public function meta()
    {
        return view('admins.settings.meta');
    }

    public function updateMeta(Request $request)
    {
        $request->validate([
            '*' => 'required',
            'author_name' => 'required | string',
            'meta_keyword' => 'required | string',
            'meta_tags' => 'required | string',
            'meta_description' => 'required | string',
        ]);

        foreach ($request->metas as $key => $name) {
            Setting::where('name', $name)->update([
                'value' => $request->$name
            ]);
        }
        return back()->with('success', 'Updated Successfully');
    }

    public function socialite()
    {
        return view('admins.settings.socialite');
    }

    public function emailCredentials()
    {
        return view('admins.settings.email-credentials');
    }

    public function emailCredentialsUpdate(Request $request)
    {
        $request->validate([
            '*' => 'required',
            'mail_transport' => 'required',
            'mail_host' => 'required',
            'mail_port' => 'required | numeric',
            'mail_username' => 'required',
            'mail_password' => 'required',
            'mail_encryption' => 'required',
            'mail_from' => 'required | email',
            'mail_from_name' => 'required',
        ], [
            'mail_transport.required' => 'Mail transport field is required',
            'mail_host.required' => 'Mail host field is required',
            'mail_port.required' => 'Mail port field is required',
            'mail_port.numeric' => 'Mail port field is allowed only numeric value',
            'mail_username.required' => 'Mail username field is required',
            'mail_password.required' => 'Mail password field is required',
            'mail_encryption.required' => 'Mail encryption field is required',
            'mail_from.required' => 'Mail from field is required',
            'mail_from_name.required' => 'Mail from name field is required',
            'mail_from_name.email' => 'Mail from name is must be an email.',
        ]);

        $credentials =  $request->credentials;
        foreach ($credentials as $key => $name) {
            Setting::where('name', $name)->update([
                'value' => $request->$name
            ]);
        }
        // Artisan::call('cache:clear');
        // Artisan::call('view:clear');
        // Artisan::call('route:clear');
        // Artisan::call('config:cache');
        // Artisan::call('view:cache');
        return back()->with('success', 'Updated Successfully');
    }
}
