<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BankPaymentGetway;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminBankPaymentGetwayController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $getways = BankPaymentGetway::all();
        return view('admins.bank-getway.index', compact('getways'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admins.bank-getway.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'bank_name' => 'required | string | max:255',
            'account_name' => 'required | string | max:255',
            'account_number' => 'required | string',
            'branch_name' => 'required | string | max:255',
            'logo' => 'required | image | mimes:jpg,png,jpeg',
        ]);

        $file = $request->file('logo');
        $fileName = time().'-payment-getway.'.$file->getClientOriginalExtension();
        $path = 'uploads/payment-getway/';
        $request->logo->move($path, $fileName);

        BankPaymentGetway::insert([
            'account_name' => $request->account_name,
            'bank_name' => $request->bank_name,
            'account_number' => $request->account_number,
            'branch_name' => $request->branch_name,
            'logo' => $path.$fileName,
            'created_at' => Carbon::now()
        ]);
        return redirect()->route('bank-payment-getway.index')->with('success', 'Created Successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $getway = BankPaymentGetway::where('id', $id)->first();
        return view('admins.bank-getway.edit', compact('getway'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $getway = BankPaymentGetway::where('id', $id)->first();
        $request->validate([
            'bank_name' => 'required | string | max:255',
            'account_name' => 'required | string | max:255',
            'account_number' => 'required | string',
            'branch_name' => 'required | string | | max:255',
            'logo' => 'image | mimes:jpg,png,jpeg',
        ]);
        if ($request->hasFile('logo')) {
            unlink(base_path($getway->logo));
            $file = $request->file('logo');
            $fileName = time().'-payment-getway.'.$file->getClientOriginalExtension();
            $path = 'uploads/payment-getway/';
            $request->logo->move($path, $fileName);
            $getway->update([
                'logo' => $path.$fileName,
            ]);
        }

        $getway->update([
            'account_name' => $request->account_name,
            'bank_name' => $request->bank_name,
            'account_number' => $request->account_number,
            'branch_name' => $request->branch_name,

        ]);
        return redirect()->route('bank-payment-getway.index')->with('success', 'Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $getway = BankPaymentGetway::where('id', $id)->first();
        unlink(base_path($getway->logo));
        $getway->delete();
        return back()->with('success', 'Deleted Successfully');
    }
}
