<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FeaturedArea;
use Illuminate\Http\Request;

class AdminFeaturedAreaController extends Controller
{
    function index() {
        $datas = FeaturedArea::all();
        return view('admins.featured.index', compact('datas'));
    }

    public function edit($id) {
        $data = FeaturedArea::where('id', $id)->first();
        return view('admins.featured.edit', compact('data'));
    }

    public function update(Request $request, $id) {
        $data = FeaturedArea::where('id', $id)->first();
        $request->validate([
            'title' => 'required | string | max:255',
            'icon' => 'image | mimes:jpg,png,jpeg'
        ]);
        if ($request->hasFile('icon')) {
            $oldFile = explode('/', $data->icon);
            $img = end($oldFile);

            if ($img != 'featured-item-01.png') {
                unlink($data->icon);
            }
            $file = $request->file('icon');
            $fileName = time().'-profile-image.'.$file->getClientOriginalExtension();
            $path = 'uploads/icon/';
            $request->icon->move($path, $fileName);
            $data->update([
                'icon' => $path.$fileName
            ]);
        }
        $data->update([
            'title' => $request->title
        ]);
        return redirect()->route('admin.feature.index')->with('success', 'Updated Successfully');
    }
}
