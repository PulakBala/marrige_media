<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InvestProfitHistory extends Model
{
    protected $fillable = ['invest_id', 'monthly_profit', 'profit_date'];

    public function invest()
    {
        return $this->belongsTo(Invest::class);
    }
}
