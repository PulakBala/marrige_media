<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fund extends Model
{
    use HasFactory;
    protected $fillable = [
        'status',
        'payment_status',
    ];

    public function mobileGetwayWithFundRelation() {
        return $this->hasOne(MobilePaymentGetway::class, 'id', 'getway_id');
    }

    public function bankGetwayWithFundRelation() {
        return $this->hasOne(BankPaymentGetway::class, 'id', 'getway_id');
    }

    public function fundWithUserRelation() {
        return $this->hasOne(User::class, 'id', 'user_id');
    }
}
