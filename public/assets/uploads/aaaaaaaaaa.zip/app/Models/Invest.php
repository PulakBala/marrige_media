<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invest extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'amount',
        'profit',
        'monthly_profit'
    ];
    
     //add this new relationship method
    public function profitHistories()
    {
        return $this->hasMany(InvestProfitHistory::class);
    }
}
