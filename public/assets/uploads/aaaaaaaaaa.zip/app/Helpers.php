<?php

use App\Models\Fund;
use App\Models\Setting;
use App\Models\Share;
use Carbon\Carbon;

if (!function_exists('setting')) {
    function setting($value)
    {
        $setting = Setting::where('name',$value)->first();
        if( $setting ){
            return $setting->value;
        }else{
        return false;
        }
    }
}


if (!function_exists('getShare')) {
    function getShare($id)
    {
        $share = Share::where([['user_id', $id], ['status', 'accept']])->count();
        if( $share ){
            return $share;
        }else{
        return 0;
        }
    }
}


if (!function_exists('getMonth')) {
    function getMonth($m)
    {
        $d1 = new DateTime("2024-01-01");
        $d2 = new DateTime("2024-05-24");
        // return $d1->diff($d2)->m. " Months";

        $now = Carbon::now();
        $monthStart = $now->startOfMonth()->format('F');
        return $monthStart;

        // $month = Fund::where([['user_id', auth()->user()->id], ['month', $m], ['year', Carbon::now()->format('Y')]])->exists();
        // if( $month ){
        //     return $month;
        // }else{
        // return 0;
        // }
    }
}
